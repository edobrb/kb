---
source_id: "confluence:confluence-cto-cto-594313417-onboarding-flow"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/594313417/Onboarding+Flow"
title: Onboarding Flow
authority: descriptive
version_hash: "sha256:fab4831d64f62a7fe9ad1b6e0dd9ed3191428f9134451eef80af1a4f0fb3d337"
body_hash: "sha256:319cadc438efe7026557cec32cb45e462dd6309d2c3952652987a466830bf51c"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/CTO/cto-594313417-onboarding-flow.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---
# Onboarding Flow

This document describes the high-level flow that the Enablement team follows when initiating a new onboarding session.

# First Blood

In this phase the *Enablement Team* provides a first overview and as much offline material that the ***Onboarding Team*** **has the responsibility to consume** in order to maximize time efficiency.

1. 🧐 Survey
2. **👩‍💻 Enablement>** First Blood meeting

   1. present enablement team
   2. present the onboarding material
   3. platform vision
   4. processes
   5. core services walkthrough

      1. Company Registry
      2. Workspace
      3. 📽️ Connection Service
      4. IAM TeamSystemID
      5. IAM Policy Manager
      6. NCS
      7. IntegrationHUB
      8. Hermes
      9. API Gateway
   6. platform team structure
3. **👩‍💻 Team>** consume existing async materials
4. 🧐 Survey

# Proactive Phase

In this phase the *Enablement Team* is responsible to provide architectural and platform solutions to the *Product Team*.

1. **👩‍💻 Enablement>** Live Q&A session

   1. collect new questions to expand the async materials
   2. provide ad-hoc answers tailored to the team’s needs
2. **🍽️ Workshop>** Case study presentation & analysis
3. **👩‍💻 Enablement>** Internal review

   1. share case study with platform teams
   2. devise a tailored onboarding / training proposal
   3. devise a first POC to propose to the team
4. **Team>** Work on POC
5. 🧐 Survey

Legenda:

- **👩‍💻** remote meeting via Teams, usually recorded
- **🍽️** live meeting - may require traveling

# Reactive Phase

The *Enablement Team* keeps planned touch-points with the *Onboarding Team* so to make sure there is time for questions and issues management.

In this phase, the *Onboarding Team* is responsible to dive the conversation.
