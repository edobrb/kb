---
source_id: "confluence:confluence-mpdd-mpdd-1590362117-2-3-guida-per-go-to-market"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1590362117/2.3+-+Guida+per+Go+To+Market"
title: 2.3 - Guida per Go To Market
authority: descriptive
version_hash: "sha256:ab178435378c2348ad930087f2598a80563c6845eaf8b82d0282473583f01c1a"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1590362117-2-3-guida-per-go-to-market.md", version_hash: "sha256:ab178435378c2348ad930087f2598a80563c6845eaf8b82d0282473583f01c1a"}
body_hash: sha256:f58af9ad1861b2cafbe446fb45e82dc741a680345e5a9b954d61adb3b71ae290
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1590362117-2-3-guida-per-go-to-market.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# 2.3 - Guide for Go To Market

**Your responsibilities**

1. **Define the price list and the items**

On BBS for the traditional channels, on the FIC Store for the external channels

2. **Make sure the items have the Metering flag**

No longer APIOK/APIX

3. **Collect the mandatory email**

Both in the CRM and in the Store: without an email, provisioning blocks at the POST Company

4. **Train the sales people**

They must know which codes to use, how upgrade/downgrade work, when to propose an add-on

5. **Coordinate the launch**

The commercial timing must be aligned with the technical configuration

**The base rules you must know**

|  |  |
| --- | --- |
| **Rule** | **Why** |
| 1 offer = 1 Family = N items (with  different prices for the same content) | Metering currently reasons by Family in order to communicate with BBS.  BBS/Store reasons by items. The relationship is: N items → 1 Family, if the content is the same and only the price/quantity changes |
| The flow flag cannot be changed on  existing items | If a product is already active in BBS with the APIOK flow, new  item codes are needed to move to Metering (recoding) |
| The email is mandatory and blocking | Without an email in the POST Company, provisioning blocks. It must be validated  before sending the order to BBS |
| Upgrade is immediate, downgrade is planned | The upgrade immediately replaces the old package. The downgrade is  scheduled and applied at expiry |
