---
source_id: "confluence:confluence-cto-cto-657950007-business-capabilities-manifesto"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/657950007/Business+Capabilities+Manifesto"
title: Business Capabilities Manifesto
authority: descriptive
version_hash: "sha256:f8d6f40afb80d85de0730dc60d89ef8ef7eb916cb36178db0dfa71a0124757c1"
body_hash: "sha256:9e3c3a02a3a84d4b674d6731487dc68003a0320d52ad4539680a3efee87c90ab"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/CTO/cto-657950007-business-capabilities-manifesto.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---
# Business Capabilities Manifesto

# Business Capabilities Manifesto

## Table of Contents

- [Business Capabilities Manifesto](#business-capabilities-manifesto)
- [Table of Contents](#table-of-contents)
- [Definition of Capability](#definition-of-capability)

  - [Common Characteristics of Capabilities](#common-characteristics-of-capabilities)
  - [Use Cases in Capability Realization](#use-cases-in-capability-realization)
  - [1. New Capability Built from Scratch](#1-new-capability-built-from-scratch)
  - [2. Integration of an Existing Product ("Low Effort Integration")](#2-integration-of-an-existing-product-low-effort-integration)
  - [3. "Lift \& Split" of an Existing Product](#3-lift--split-of-an-existing-product)
- [Tenancy](#tenancy)

  - [**Strict Isolation of Data Contexts**](#strict-isolation-of-data-contexts)
  - [**Representation of Organizational Scenarios**](#representation-of-organizational-scenarios)
  - [**Access Control Based on Ownership**](#access-control-based-on-ownership)
  - [**Traceability and Coherence**](#traceability-and-coherence)
  - [**Specialization**](#specialization)
  - [**Responsible External Interoperability**](#responsible-external-interoperability)
- [Users](#users)

  - [**Unique and Centralized User Identity**](#unique-and-centralized-user-identity)
  - [**Targeted and Contextual Authorizations**](#targeted-and-contextual-authorizations)
- [Security](#security)

  - [**Intrinsic Security of Business Functionalities**](#intrinsic-security-of-business-functionalities)
  - [**Explicit Verification and Zero Trust in Service Interactions**](#explicit-verification-and-zero-trust-in-service-interactions)
  - [**Clear Ownership for Granting Access**](#clear-ownership-for-granting-access)
  - [**Authorizations and Application Context**](#authorizations-and-application-context)
  - [**Alignment of Existing Systems with Central Security Principles**](#alignment-of-existing-systems-with-central-security-principles)
- [Core Principles for Data Governance and Integration](#core-principles-for-data-governance-and-integration)

  - [**Single Source of Truth**](#single-source-of-truth)
  - [**Explicit Responsibility**](#explicit-responsibility)
  - [**Distributed Coherence, Not Central Dependency**](#distributed-coherence-not-central-dependency)
  - [**Flexible Integration**](#flexible-integration)
  - [**Value in Data Quality**](#value-in-data-quality)
- [Activation and Consumption Tracking](#activation-and-consumption-tracking)

  - [**Our Core Vision for Consumption Tracking**](#our-core-vision-for-consumption-tracking)
  - [**Enabling and Not Just Passive Measurement**](#enabling-and-not-just-passive-measurement)
  - [**Multidimensional and Contextual**](#multidimensional-and-contextual)
  - [**Integrated into the Capability Lifecycle**](#integrated-into-the-capability-lifecycle)
  - [**Flexible and Configurable**](#flexible-and-configurable)
  - [**Orchestrable and Automatable**](#orchestrable-and-automatable)
  - [**Transparent**](#transparent)
  - [**Auditable and Compliant**](#auditable-and-compliant)

---

## Definition of Capability

A **Business Capability** is a software aggregate that implements a specific domain functional competency, with meaning and value from a managerial perspective (e.g., MES, invoicing, timesheet, accounting). It is designed as an autonomous, cohesive, and reusable unit, consumable via different application orchestration modes.

A common foundation is necessary to support the operation and coordination of processes that span different areas. For this reason, alongside Business Capabilities, **Platform Capabilities** are identified as infrastructural components that, although not having a direct commercial purpose, provide the fundamental services and processes on which Business Capabilities are built and integrated.

One or more Business Capabilities are combined with Platform Capabilities to build a **Commercial Offering**: that is, a set of functionalities organized and proposed to meet specific market or customer needs. The commercial offering is therefore based on the aggregation of autonomous capabilities, ensuring flexibility and reusability.

### Common Characteristics of Capabilities

A Business Capability must be designed to be "**ready to sell**," meaning immediately marketable without requiring additional system delivery activities.

To be "**ready to use**," however, it might require application configuration activities, to be performed by the client's organization.

Each Capability can consist of three distinctive elements:

- **UX (User Experience):** interfaces and presentation logic, where applicable.
- **Algorithms:** calculation logic and domain rules.
- **Data:** information structures and models.

The UX presentation modes can be:

- Complete and autonomous, providing its own independent user interface.
- Composed of reusable components, integrable into other Business Capabilities.
- Absent, in cases where the capability is intended for integration via API, without direct exposure to the end-user.

Business Capabilities must not have direct dependencies on other Business Capabilities. The only allowed dependencies are towards Platform Capabilities (e.g., integration, identity, data services). Similarly, Platform Capabilities must not have direct dependencies on Business Capabilities.

Any interaction needs between capabilities (e.g., data exchange, orchestration of algorithms or processes) must be mediated by the platform's integration components.

Specifically, by integration area, we mean: Hermes pub/sub message brokering, point-to-point integrations with mapping (iHub, HoReCa, Mesh, etc.), and an internal ServiceRegistry/NamingService.

When a Business Capability has dependencies on other domains for algorithms and/or UX-blocking processes, it is the Business Capability's responsibility to manage solution resilience and failover (Platform Capabilities are structured to offer a reliability profile that is different from that required of Business Capabilities).

Data managed by a Business Capability can be:

- **Private**, when strictly linked to the internal functional domain of the capability.
- **Shared**, when relevant to other domains or capabilities.

In any case, it is the Business Capability's responsibility to:

- Identify **business events**: application moments of particular relevance that must be notified to potential consumers through the pub/sub messaging broker (Hermes).

### Use Cases in Capability Realization

In the realization of a Business Capability, three main intervention areas can arise:

#### 1. New Capability Built from Scratch

- Description: de novo development of a platform-native capability.
- Characteristics:

  - Full adoption of the platform's architectural principles, both at the technological and data modeling levels.
  - Full autonomy in defining the user experience, operational processes, and information models, with the aim of developing a capability designed to be an integral part of a broader value offering, not an isolated product.

#### 2. Integration of an Existing Product ("Low Effort Integration")

- Description: integration of an existing system or product with minimal adaptation effort.
- Characteristics:

  - The original data and process model is adapted without distorting it, respecting the initial design.
  - The integration must at least involve the use of the platform's mandatory services, such as:

    - TSID
    - Workspace / Registry
    - 1Front
    - Hermes
    - Metering
    - Policy Manager
  - It is possible to accept compromises on the UX to avoid invasive interventions on the application system.

#### 3. "Lift & Split" of an Existing Product

- Description: significant refactoring of a pre-existing product or a portion of it, splitting it into multiple Business Capabilities.
- Characteristics:

  - Substantial review of the UX, processes, and data model.
  - Redesign to adhere to Business Capability standards and domain separation rules.
  - Objective of obtaining modular, independent components aligned with the platform's resilience and scalability principles.

Following are the definitions of the core concepts underlying the realization of a Business Capability.

## Tenancy

### **Strict Isolation of Data Contexts**

- **Purpose:** To ensure the absolute protection and intrinsic confidentiality of data within each defined context.
- **Manifestation:** Each Data Context is a sealed logical area, whose data is accessible exclusively to the owner of that specific Data Context. A rigorous and inviolable separation is maintained between distinct Data Contexts; such contexts remain non-interoperable except through explicitly authorized mechanisms compliant with ownership principles.

### **Representation of Organizational Scenarios**

- **Purpose:** To ensure that the data management model can flexibly and accurately represent the diversity of organizational and ownership scenarios.
- **Manifestation:** The system natively supports both cases where the data owner and the entity to which the data refers coincide (e.g., an organization managing its own data), and those where these figures are distinct (e.g., an intermediary managing data on behalf of third parties). In every configuration, the definition of ownership and the responsibilities associated with the Data Context are always explicit and transparent.

### **Access Control Based on Ownership**

- **Purpose:** To implement a data access control system that is rigorous, coherent, and strictly aligned with the ownership principle of each Data Context.
- **Manifestation:** Access rules and data visibility authorizations are defined and applied in strict compliance with the ownership model associated with each Data Context. Only explicitly authorized subjects, by virtue of their relationship with a specific Data Context, can interact with the information contained therein, ensuring its integrity and confidentiality.

### **Traceability and Coherence**

- **Purpose:** To ensure that all data and interactions are always traceable to their original Data Context, ensuring coherence and traceability throughout the entire ecosystem.
- **Manifestation:** Every piece of information and every data operation are structured to maintain a unique and persistent link with their respective Data Context. This traceability principle is rigorously applied also in the dialogue between different capabilities.

### **Specialization**

- **Purpose:** To allow for the variation of the Data Context perimeter for advanced functional needs, while preserving structural coherence in dialogue with other capabilities.
- **Manifestation:** The system allows the use of additional references and attributes (e.g., sub-entities, functional classifications) beyond the primary identification of the Data Context, to address specific operational needs. Such flexibility is conditional upon maintaining a structured and coherent relationship with the parent Data Context, ensuring that every extension is formally registered and managed within the perimeter of the context itself.

### **Responsible External Interoperability**

- **Purpose:** To facilitate interaction and data exchange with external entities and systems, ensuring full adherence to the principles of data responsibility and traceability.
- **Manifestation:** For interaction with third parties (e.g., government agencies, external partners), the system supports the use of alternative identifiers or data formats, as required by specific interoperability protocols. In all circumstances, it is guaranteed that such external representations are always uniquely traceable to the original Data Context and its owner, ensuring regulatory alignment, complete information traceability, and clear attribution of responsibilities.

## Users

### **Unique and Centralized User Identity**

- **Purpose:** To ensure that every user interacting with the platform is identified uniquely, verified, and consistently through a central reference system.
- **Manifestation:** The management of digital identities and access credentials is entrusted to a single recognized authoritative source. This central system ensures the unique and consistent recognition of the user in every interaction within the platform ecosystem.

### **Targeted and Contextual Authorizations**

- **Purpose:** To ensure that each user has exclusively the necessary permissions for their activities, with an assignment model that dynamically adapts to the business functionality and operational context.
- **Manifestation:** The authorization model is based on two complementary mechanisms. For standard user roles with predictable access needs, permission profiles are predefined and centrally assigned via dedicated tools, ensuring consistency and simplified management external to individual functionalities. For scenarios where permissions are intrinsically linked to specific data or dynamic contexts emerging during use (e.g., access to specific documents or projects), detailed configuration is delegated to the competent business functionality. The latter autonomously manages such granular authorizations, providing dedicated interfaces and interacting with central permission management systems, to ensure fine-grained and contextually relevant access control.

## Security

### **Intrinsic Security of Business Functionalities**

- **Purpose:** To ensure that every business functionality is intrinsically secure, guaranteeing that interaction with resources is permitted exclusively to authorized subjects.
- **Manifestation:** Access to every business functionality is subject to rigorous identification of the requester and a precise verification of their authorizations. Such control mechanisms are managed centrally and coherently to ensure uniformity and protective effectiveness across the entire platform.

### **Explicit Verification and Zero Trust in Service Interactions**

- **Purpose:** To apply the "zero trust" principle to all interactions between services, whether internal or external, requiring explicit validation of identity and permissions before allowing any exchange.
- **Manifestation:** Any interaction between services, regardless of their nature or origin (end-user or automated process), mandates confirmation of the requesting service's identity and rigorous verification of its specific authorizations for the requested action. The responsibility for granting access to specific functionalities or data lies with the resource owner, who assesses the necessity and appropriateness of the request.

### **Clear Ownership for Granting Access**

- **Purpose:** To establish clear and unequivocal responsibility for granting access to business functionalities, promoting awareness and accountability in permission management.
- **Manifestation:** The owner of each business capability has the formal task of defining and approving which services are authorized to access it and in what manner. Each inter-service access request is subject to individual assessment, without presumptions of generalized authorization. Business capability owners are also tasked with ensuring the secure evolution of their functionalities to handle new interaction needs.

### **Authorizations and Application Context**

- **Purpose:** To ensure that access permissions are defined based on the specific context of the interaction, whether initiated by an end-user or an application system.
- **Manifestation:** Authorization policies are implemented through a clear distinction of definition mechanisms: configurations managed by the end-user for specific contexts (e.g., via dedicated interfaces) and rules established by the business capability owner for interactions between application systems. This ensures that all access is always appropriate to the specific operational context.

### **Alignment of Existing Systems with Central Security Principles**

- **Purpose:** To ensure that existing products, both during integration and their evolution (e.g., refactoring or splitting), are aligned with the platform's centralized security principles to guarantee a uniform level of protection.
- **Manifestation:** The security mechanisms of existing applications are subject to review and modernization. Legacy protection logics are identified and migrated to centralized reference systems for identity and access management. Application permission configuration and verification methods are updated and standardized according to the platform's approach.

## Core Principles for Data Governance and Integration

### **Single Source of Truth**

- **Purpose:** To ensure that all master data shared on the platform is reliable, up-to-date, and consistent, through an authoritative source recognized by all business capabilities.
- **Manifestation:** A central core of fundamental data exists, representing the shared source of truth. This system is the sole authorized point for managing and publishing common master data. Other capabilities synchronize with this center through asynchronous mechanisms, thereby maintaining visibility and alignment without compromising operational autonomy.

### **Explicit Responsibility**

- **Purpose:** To ensure that all data is governed by a well-defined capability, which holds responsibility for it and guarantees its quality, integrity, and updates, respecting the principle of ownership.
- **Manifestation:** Each capability can read shared master data locally but can only modify data for which it is formally responsible. Otherwise, it must delegate the update to the competent capability. Similarly, each capability autonomously manages its own set of specialized data, building views and logic suited to its needs upon the common data, while respecting responsibility boundaries.

### **Distributed Coherence, Not Central Dependency**

- **Purpose:** To promote a modular ecosystem where data consistency does not depend on the synchronicity of operations, but on a robust model of distributed alignment.
- **Manifestation:** Data synchronization between the center and periphery occurs asynchronously. This allows capabilities to operate even in conditions of temporary isolation, preserving scalability, resilience, and the ability to evolve independently, while maintaining coherence through well-governed update models.

### **Flexible Integration**

- **Purpose:** To enable capabilities to collaborate and exchange data using the most effective model for their needs, valuing the diversity of contexts and minimizing architectural constraints.
- **Manifestation:** The platform supports various integration models – from synchronous APIs to asynchronous messages, from file sharing to event-driven logic – offering common tools and standards. Each integration is designed to reflect the desired level of coupling, performance priorities, and consistency needs, within a flexible yet harmonious architectural framework.

### **Value in Data Quality**

- **Purpose:** To elevate data quality to a shared responsibility among all capabilities, recognizing it as a strategic asset for the entire organization.
- **Manifestation:** Central master data is subject to automatic and traceable validation, versioning, and quality control rules. Capabilities that use it must contribute to continuously strengthening its reliability collaboratively.

## Activation and Consumption Tracking

### **Our Core Vision for Consumption Tracking**

- **Purpose:** To integrate a cross-cutting capability for the complete tracking and detailed measurement of capability consumption across the entire platform. This aims to enable evolutionary and flexible consumption models, automate adoption and provisioning processes, support data-driven operational and economic governance, and actively promote the generation of measurable value through consumption tracking.
- **Manifestation:** The platform achieves this by enabling the systematic detection, tracking, and recording of business capability consumption data by all diverse actors interacting with it. This data-driven approach allows the platform to:

  - Facilitate flexible consumption models tailored to various needs.
  - Automate critical processes such as provisioning and onboarding.
  - Provide robust support for both operational and economic governance.

### **Enabling and Not Just Passive Measurement**

- **Purpose:** To actively manage and control capability consumption based on defined parameters, going beyond simple measurement to enforce business and contractual rules.
- **Manifestation:** The system does not merely measure consumption; it actively enables or inhibits the use of capabilities based on predefined rules, consumption limits, or specific contractual conditions, thus becoming an active agent in consumption governance.

### **Multidimensional and Contextual**

- **Purpose:** To provide a rich, detailed, and contextualized measurement of how capabilities are consumed on the platform by various actors and under different circumstances.
- **Manifestation:** Consumption detection and recording occur along multiple relevant dimensions, including (but not limited to) the specific capability consumed, the timing and duration of consumption, and the volume or intensity of consumption. This allows for a complete and contextualized measurement of consumption patterns and supports the enforcement of limits.

### **Integrated into the Capability Lifecycle**

- **Purpose:** To ensure that consumption tracking, understood as a measurement capability, is an integral and intrinsic part of a capability's entire existence, from its inception to its ongoing operation and potential decommissioning.
- **Manifestation:** This consumption tracking capability is strictly and intrinsically linked to the entire lifecycle of all capabilities. This integration spans from the point of acquisition or onboarding (where it can trigger relevant processes) through to continuous monitoring of consumption data during active use.

### **Flexible and Configurable**

- **Purpose:** To adapt to a wide range of business models and consumption patterns, offering extensive control to define and manage how consumption is tracked, measured, reported, and acted upon.
- **Manifestation:** The system robustly supports a variety of consumption models (such as freemium, trial periods, pay-per-use, and subscription-based access). It offers extensive configurability of tracking metrics, consumption thresholds, automated alerts, and detailed reporting on consumption data to meet specific needs.

### **Orchestrable and Automatable**

- **Purpose:** To enable dynamic, automated responses and workflows triggered by consumption events and data, by integrating with other essential platform services.
- **Manifestation:** This capability is designed to interact with other core platform components—including provisioning systems and billing engines—to activate and orchestrate automated workflows based on detected consumption data and predefined rules.

### **Transparent**

- **Purpose:** To promote a culture of awareness and shared responsibility among all platform stakeholders by providing clear and accessible visibility into capability consumption data.
- **Manifestation:** Consumption data, along with relevant metrics and reports, is exposed clearly and appropriately to various stakeholders. This includes end-users (regarding their own consumption), capability owners (regarding the consumption data of their capabilities), and platform operators (for overall governance and optimization).

### **Auditable and Compliant**

- **Purpose:** To ensure the complete integrity, traceability, and security of all consumption data, and to guarantee adherence to all relevant internal policies, contractual obligations, and external regulations.
- **Manifestation:** The system guarantees historical traceability of all consumption events, maintains robust security for this sensitive data, and ensures strict adherence to and compliance with all applicable policies.
