---
source_id: "confluence:confluence-mpdd-mpdd-1590886422-5-3-come-fare-una-richiesta-al-team-metering"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1590886422/5.3+-+Come+fare+una+richiesta+al+team+metering"
title: 5.3 - Come fare una richiesta al team metering
authority: descriptive
version_hash: "sha256:c1e7e27c1efcdcaa255ea23a9849dc341cc5393e00856d6157fbb012d18b8b48"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1590886422-5-3-come-fare-una-richiesta-al-team-metering.md", version_hash: "sha256:c1e7e27c1efcdcaa255ea23a9849dc341cc5393e00856d6157fbb012d18b8b48"}
body_hash: sha256:7aaa06d8bd3e33b33dc1cc2a454f9c31b932f2d092a17254bddcaff62c571c0a
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1590886422-5-3-come-fare-una-richiesta-al-team-metering.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# 5.3 - How to make a request to the metering team

Once the necessary information has been gathered, open a ticket on **Service Desk → Monetization Enablement / Metering** <https://teamsystem.atlassian.net/servicedesk/customer/portal/1327> choosing the correct type:

**🎧 Questions / General support** You have a doubt, a problem or you need clarification on how Metering works. Before opening the ticket, consult the documentation: you often already find the answer there. An agent of the team will reply to you directly in the ticket.

**🔧 Change to the integration with Metering** You want to modify an already existing Family. Indicate in the ticket the exact name of the Family, what you want to change (new plan, new service, constraint change) and the expected impact on customers already active.

**✚ New integration with Metering** You want to create a new Family from scratch. Before opening the ticket, follow the dedicated Quick Guide to gather all the necessary information: a complete request reduces processing times and clarification rounds.

> If you have several needs at the same time — for example you want to modify an existing Family and create a new one — open a separate ticket for each request. This allows the team to handle each piece of work independently and to give you precise updates on each.
