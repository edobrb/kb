---
source_id: "confluence:confluence-mpdd-mpdd-1588822184-2-1-guida-per-product-owner"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1588822184/2.1+-+Guida+per+Product+Owner"
title: 2.1 - Guida per Product Owner
authority: descriptive
version_hash: "sha256:009f688b85dfbeb355d8c3150b20416c5aed546032a10d79b94ff12064899f6d"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1588822184-2-1-guida-per-product-owner.md", version_hash: "sha256:009f688b85dfbeb355d8c3150b20416c5aed546032a10d79b94ff12064899f6d"}
body_hash: sha256:3346a222e6faf7df0f015bf888ceb131f4ebb0326066b86dc5df415a5b9f44fe
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1588822184-2-1-guida-per-product-owner.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# 2.1 - Product Owner Guide

## **Your responsibilities**

1. **Define the features of your capability**

   - What each feature does, which actions the user can perform, what can be measured/counted
2. **Decide the composition of the offers**

   - Which features go into which tier ( e.g., BASE, PRO, ENT..)
3. **Define the constraints**

   - How many operations, which threshold, what happens when it is reached (block? readonly? overage?)
4. **Decide the activation model**

   - Per company (Company Flow) or per workspace (Workspace Flow)
5. **Validate the lifecycle of the feature in the Capability Catalog**

   - init → configured → published

## **The questions you must ask yourself before starting**

- Are my features granular enough? Every feature must correspond to something that can be switched on/off independently.
- Do I have features shared between different offers? If so, is the multi-license managed correctly on the code side?
- Does my offer have a **constraint** (volume-based consumption) or is it **flat** (fixed fee without limits)?
- Is a **trial** needed? If so, a separate Trial Family must be defined.
- Is an **add-on** needed? If so, a Family with a Parent Family must be defined.

## **Your path to bringing a capability to market**

## **Phase 1 — Define the Business Capability and its features**

| **#** | **Activity** | **Who** | **Output** |
| --- | --- | --- | --- |
| 1 | Define the functional domain of the BC | PO + Tech Lead | BC name, description, perimeter |
| 2 | Break the BC down into granular features | PO + Tech Lead | Feature list with: name, description, what  to count |
| 3 | Assign a serviceId to every feature | Tech Lead | Convention: Uppercase, feature-name (globally unique) |
| 4 | Choose the flow for every feature | Tech Lead + PO | Company Flow (itemId) or Workspace Flow  (workspaceId) — definitive choice |
| 5 | Implement the webhook for every feature | Engineering | Endpoint that handles the 4 actions,  idempotent, responds HTTP 200 |
| 6 | Test the webhook with curl (all 4 actions) | Engineering | Test passed for every feature |
| 7 | Enroll the BC and the features in the Capabilities Feature Catalog | PO + EM | Features registered with status, contacts, technical details |

## **Phase 2 — Build the commercial offer (Family)**

| # | Activity | Who | Output |
| --- | --- | --- | --- |
| 1 | Decide how many offers/tiers are needed | PO + GTM | E.g.: Base, PRO, MAX |
| 2 | For every offer, decide which features to include | PO + GTM | tier × feature matrix |
| 3 | Define the constraints for every offer (if any) | PO + GTM | What is measured, limits, behaviour at the threshold |
| 4 | Define the relations between offers | PO + GTM | Upgrade/downgrade, parent/child, trial, add-on |
| 5 | Create the articles on BBS (or Store FIC) with the Metering flag | GTM + BBS/FIC | Articles configured in the CRM and in the Store |
| 6 | Communicate to the Metering team: Family, features, constraints, webhook URL, appId (BC name), service description | PO + Tech Lead | Family configured in Metering |
| 7 | The Metering team creates the Family, associates the features, configures the constraints | Metering Team | Everything ready for the test |

## **Phase 3 — End-to-end test and go-live**

| **#** | **Activity** | **Who** |
| --- | --- | --- |
| 1 | The Metering team sends test payloads in the staging environments | Metering Team |
| 2 | The BC verifies the correct activation/deactivation for every feature | Engineering |
| 3 | BBS/Store FIC creates a test order and verifies the complete flow | GTM + Metering Team |
| 4 | Final validation | PO + everyone |
|  | 5 Go-live | Coordinated |

## **Who to turn to**

| **Topic** | **Contact** |
| --- | --- |
| Commercial offer definition, articles, price list | BBS — Luca Faccone (or Store FIC contact person) |
| Family, Service, Constraint configuration in Metering | Metering Team — Giorgio Ratti |
| OnePlatform prerequisites (TsID, Workspace, Registry) | OnePlatform Team — Giovanni Colasurdo |
