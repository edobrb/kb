---
source_id: "confluence:confluence-mpdd-mpdd-1582072020-monetization-home-documentation"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1582072020/Monetization+Home+-+Documentation"
title: Monetization — Home - Documentation
authority: descriptive
version_hash: "sha256:393043679e96045b8e40dc86e8418fd8ee5461767e4faa475e948ee80364a6c4"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1582072020-monetization-home-documentation.md", version_hash: "sha256:393043679e96045b8e40dc86e8418fd8ee5461767e4faa475e948ee80364a6c4"}
body_hash: sha256:3d5de64bbfd77b4ce866fc043c4fac84b0298cac6cd0fa11badc9a151e69d511
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1582072020-monetization-home-documentation.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# Monetization — Home - Documentation

**Welcome to the Monetization wiki — OnePlatform**

This wiki is the reference point for all teams that want to integrate their own products and services with the OnePlatform monetization system. Whether you are a Product Owner, a Tech Lead or part of Go To Market, here you will find what you need.

Before exploring the sections, read **How to find your way around this wiki**: it helps you identify straight away which page to read according to your role and to what you have to do, without getting lost in the full documentation.
