---
source_id: "confluence:confluence-mpdd-mpdd-1580728608-come-orientarsi-in-questa-wiki"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1580728608/Come+orientarsi+in+questa+wiki"
title: Come orientarsi in questa wiki
authority: descriptive
version_hash: "sha256:ce6cca1726b6042f18b2b575797effab58df16ed90fb934887827eff93ad7b67"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1580728608-come-orientarsi-in-questa-wiki.md", version_hash: "sha256:ce6cca1726b6042f18b2b575797effab58df16ed90fb934887827eff93ad7b67"}
body_hash: sha256:62bcd60388b61c9fdca11cecf6ccb20ab46cb273d36b0ec36c717d35874f1d34
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1580728608-come-orientarsi-in-questa-wiki.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# How to find your way around this wiki

# How the Monetization Domain Documentation is organized

The wiki is organized on two levels: a **complete documentation** with all the concepts and any deeper dives, and **operational Quick Guides** that guide you step by step through gathering the information needed to open a clear and complete request to the Monetization team through Service Desk.5.3 - How to make a request to the metering team

If you have a request to make, choose your case:

**→ I want to create a new product family:** Follow the Quick GuideQuick Guide - Creating a New Commercial Offer / Family

**→ I want to modify an existing family:** Follow the Quick Guide Quick Guides - Change Requests on existing configurations

**→ I do not know where to start:** Read the Quick Guide to the activation and management of Metering for products and services section or consult the [complete documentation](https://teamsystem.atlassian.net/wiki/spaces/MPDD/folder/1581351114?atlOrigin=eyJpIjoiNzJhMDdlMzUyZTRjNGFkY2IzZGJiMTU0NjMyZDQzMmMiLCJwIjoiYyJ9) for all the concepts and deeper dives.

---

## **Two levels of documentation**

|  |  |
| --- | --- |
| **📚  Complete wiki (deep dive)** | **⚡  Quick Guide (operational)** |
| **For whom:** those who want to understand the system **Contains:** basic concepts, flows, tokens, M1 vs M3, guides by role, technical reference **Where:** sections/folders 1→5 in the left-hand menu | **For whom:** those who have to make a request or open a ticket **Contains:** operational steps, fields to fill in, checklist **Where:** the Quick Guide pages in the left-hand menu |

## **Which situation are you in?**

|  |
| --- |
| **✦  I already know Metering — I have to create a new Family or integrate a new product**  You already have active Families or you have already worked with Metering. You want to add a new commercial offer.  **→**Quick Guide - Creating a New Commercial Offer / Family  **→** Follow the indicated steps and then open the ticket: 5.3 - How to make a request to the metering team |

|  |
| --- |
| **✦  I already know Metering — I have to modify an existing configuration**  You already have active Families, serviceIds and packages. You want to rename, add a constraint, change a webhook or something else.  **→** Quick Guides - Change Requests on existing configurations  **→** Choose the type of change and read only that section, then open the ticket:5.3 - How to make a request to the metering team |

|  |
| --- |
| **✦  I am new — I do not yet know how Metering works** You have never worked with OnePlatform's monetization system. Start here.   1. Read the Quick Guide to the activation and management of Metering for products and services (basic concepts, flows, tokens) 2. Then dig deeper into the section best suited to your role:     - 2.1 — Guide for Product Owner    - 2.2 — Guide for Tech Lead and Dev    - 2.3 — Guide for Go To Market 3. When you are ready, use the Quick Guide - Creating a New Commercial Offer / Family to open the ticket 5.3 - How to make a request to the metering team |

## **Complete map of the wiki**

|  |  |
| --- | --- |
| **Section** | **What you find** |
| Quick Guide — Activation and management | Basic concepts, flows, tokens, M1 vs M3 |
| Quick Guide — New integration | 4 steps to create a new Family or a first integration |
| Quick Guides - Change Requests on existing configurations | Rename, constraint, webhook, flow change |
| 1. [The Model](https://teamsystem.atlassian.net/wiki/spaces/MPDD/folder/1581351114?atlOrigin=eyJpIjoiNzI5MmMyYjQ4YjhhNDRkODk2N2IxNmE1MTljMWMwMzAiLCJwIjoiYyJ9) | What a Family is, the lifecycle of a monetized product, plans, constraints, dimensions and consumption metrics |
| 2. [Guide by Role](https://teamsystem.atlassian.net/wiki/spaces/MPDD/folder/1589444621?atlOrigin=eyJpIjoiZWFmNzExOTRlZTcyNGNhZDk1MzZjYzk1MGQ1MDIzZjgiLCJwIjoiYyJ9) | What you need to know and do according to your role: Product Owner, Tech Lead/Dev, Go To Market |
| 3. [Integrating with Metering](https://teamsystem.atlassian.net/wiki/spaces/MPDD/folder/1589739523?atlOrigin=eyJpIjoiZjc5YzVlODkyYWVmNGU2NzkyMTJlYjljY2NiZTZjOTgiLCJwIjoiYyJ9) | Technical configuration, M2M tokens, webhooks, activation and consumption flows, M1/M3 differences |
| 4. [Technical reference](https://teamsystem.atlassian.net/wiki/spaces/MPDD/folder/1589870597?atlOrigin=eyJpIjoiNWRlNTdiYWRkZjRiNDdlYWJhMzhjZmM3NjIzMjQ2YjYiLCJwIjoiYyJ9) | Schemas, payloads, API specifications, configuration examples, events and formats |
| 5. [Resources](https://teamsystem.atlassian.net/wiki/spaces/MPDD/folder/1588822182?atlOrigin=eyJpIjoiMGZlMTA2YTRmNGMzNDI4ZjhmN2U0NDY1NDIwNWUxYTYiLCJwIjoiYyJ9) | Glossary, FAQ, How to make a request to metering |
| 6. [Quick Guides](https://teamsystem.atlassian.net/wiki/spaces/MPDD/folder/1631420426?atlOrigin=eyJpIjoiMDNjY2YzZDFkZmNkNDk4Mjk5MTU5YjdjNjIyMDEwMTUiLCJwIjoiYyJ9) | The three operational guides: Activation and management, New integration, Existing changes |

# **How to open the ticket to make requests**

Once the necessary information has been gathered, open a ticket on: <https://teamsystem.atlassian.net/servicedesk/customer/portal/1327> For how to fill in the request refer to 5.3 - How to make a request to the metering team

# **Contacts and requests**

|  |  |
| --- | --- |
| **Area** | **Reference** |
| OnePlatform Onboarding prerequisites (TsID, Workspace, Registry, Metering, Integration Questionnaire) | OnePlatform Team — Giovanni Colasurdo |
| Commercial offer, articles, price list (traditional channels) | BBS — Luca Faccone, Aurelio Lavolpe |
| Commercial offer (external channels/FIC) | FIC Store contact |
| Family, Service, Constraint configuration in the Metering | Metering Team — Giorgio Ratti (PO) and Alberto Zitti (Eng Man) |
| **Service Desk Monetization (Opening a ticket for requests)** | Service Desk: Monetization Enablement / Metering |

# **Technical documentation of the metering**

<https://development.teamsystem.com/docs/default/component/m3/>
