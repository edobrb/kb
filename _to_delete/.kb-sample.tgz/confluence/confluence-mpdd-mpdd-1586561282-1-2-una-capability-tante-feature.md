---
source_id: "confluence:confluence-mpdd-mpdd-1586561282-1-2-una-capability-tante-feature"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1586561282/1.2+-+Una+capability+tante+feature"
title: "1.2 - Una capability, tante feature"
authority: descriptive
version_hash: "sha256:f8112b9087fd2e7ed4aee8e7bee5c519e3bb4d2e5b550f12af421b6cf91b8601"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1586561282-1-2-una-capability-tante-feature.md", version_hash: "sha256:f8112b9087fd2e7ed4aee8e7bee5c519e3bb4d2e5b550f12af421b6cf91b8601"}
body_hash: sha256:619079392cbc5c448a4b0a015cbfa281faa3ea748c45387d86689cc14bf857ef
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1586561282-1-2-una-capability-tante-feature.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# 1.2 - One capability, many features

## **What a Business Capability is**

**A Business Capability (BC)** is the functional domain of a product: everything that product knows how to do. For example, the "Electronic Invoicing" BC knows how to issue outgoing invoices, receive incoming invoices, archive documents.

The BC is **autonomous and free of commercial logic**: it does not decide what to activate, it does not know limits or prices. It confines itself to declaring what it knows how to do and to communicating what happens inside it. It is the commercial offer (Family) and BBS that decide what to switch on, with which limits and at what price

> Every capability is a **template** described by:
>
> 1. **Feature** — The individual functionalities that can be independently enabled/disabled. For example, the "Electronic Invoicing" capability exposes "Outgoing invoice", "Incoming invoice", "Bulk invoicing" and "Self-billing invoice". It will be the commercial offer that decides which ones to switch on for each tier.
> 2. **Limitable dimensions** — The metrics that the capability *is able to limit* (e.g. "documents per month", "storage space"), declaring only the metric and the unit of measure, **without assigning any value**. The capability says *"I am able to block once the number of documents is reached"*; it is the Commercial Offer that establishes whether the limit is 100, 400 or unlimited.
> 3. **Usage Event** — The measurable actions that the capability communicates to the metering system. The capability does not decide whether an action is a consumption: it confines itself to communicating "this happened". It will be Metering that decides whether that event counts, based on the offer subscribed to by the client.

>  🔭 **M3 Direction**
>
> Today the BCs do not have a centralized catalog , they are registered informally. In M3 there is the **Capability Catalog**: every BC has an identity card with features, limitable dimensions and usage events. Only capabilities with status `published` and `monetization_ready: true` can enter the commercial offers. The enrollment process becomes formal and governed.

**Practical implications for Metering**

|  |  |  |
| --- | --- | --- |
| **Aspect** | **One capability, many features** | **Many capabilities, few features** |
| **Webhook management** | A single team manages all the webhooks. Routing by serviceId. | Every capability has its own team and its own webhook. |
| **Commercial flexibility** | Features combine into different Families — maximum flexibility. | Composing an offer requires features from different capabilities — more coordination. |
| **Deprecation** | Deprecating a feature impacts all the Families that include it. | Deprecating a capability does not impact the others. |
| **Constraint** | Constraints can be shared or separate per feature. | Every capability has its own independent constraints. |

> **The practical rule**
>
> When in doubt, keep fewer capabilities with more features. It is always possible to extract a feature and promote it to a separate capability in the future. The opposite (merging two capabilities) is much more painful: it impacts Metering, BBS, the existing commercial offers and potentially the clients' active subscriptions

1.1 - The three actors BC - Family - BBS | 1.3 - The two channels: BBS and Store FIC
