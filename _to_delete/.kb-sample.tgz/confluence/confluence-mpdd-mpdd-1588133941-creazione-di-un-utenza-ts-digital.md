---
source_id: "confluence:confluence-mpdd-mpdd-1588133941-creazione-di-un-utenza-ts-digital"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1588133941/Creazione+di+un+utenza+TS+DIGITAL"
title: Creazione di un utenza (TS DIGITAL)
authority: descriptive
version_hash: "sha256:fddf6b489412c833dd988616d8c1dc72b2894f80f26f6836f2abd76ab1fdc373"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T23:28:46Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1588133941-creazione-di-un-utenza-ts-digital.md", version_hash: "sha256:fddf6b489412c833dd988616d8c1dc72b2894f80f26f6836f2abd76ab1fdc373"}
body_hash: sha256:6ac857b55526bedd307baef19fe0e7c7e4baa7c7df0f4052c3094479b3d357a1
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1588133941-creazione-di-un-utenza-ts-digital.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# Creation of a user account (TS DIGITAL)

Access the TSDigital portal

![image-20260113-144857.png](assets/image-20260113-144857.png)

Click on “Continue”

![image-20260113-145044.png](assets/image-20260113-145044.png)

Fill in the fields with the requested data and click on “Continue”

![image-20260113-145145.png](assets/image-20260113-145145.png)

Check that you have received the email to activate the account

![image-20260113-145322.png](assets/image-20260113-145322.png)

Click on “Activate account”

![image-20260113-150728.png](assets/image-20260113-150728.png)

Click on “Next”

![image-20260113-150753.png](assets/image-20260113-150753.png)

Select the type of organization: Studio/Company and then click “Next”

![image-20260113-150850.png](assets/image-20260113-150850.png)

Enter the VAT number or the CF

![image-20260113-150938.png](assets/image-20260113-150938.png)

Click on “Enter the data manually”

![image-20260113-151037.png](assets/image-20260113-151037.png)

Enter the registry data and click on “Save”

![image-20260113-151116.png](assets/image-20260113-151116.png)

You are then redirected to the dashboard

![image-20260113-151214.png](assets/image-20260113-151214.png)

Click on “I HAVE READ AND I PROCEED”

![image-20260113-151247.png](assets/image-20260113-151247.png)

Click “OK”

![image-20260113-151330.png](assets/image-20260113-151330.png)

Click “OK/Deny”

![image-20260113-151351.png](assets/image-20260113-151351.png)

Click “OK/Deny”

![image-20260113-151426.png](assets/image-20260113-151426.png)

User account and related Company/Studio created correct
