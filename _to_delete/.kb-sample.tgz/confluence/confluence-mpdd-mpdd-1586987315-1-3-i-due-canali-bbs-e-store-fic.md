---
source_id: "confluence:confluence-mpdd-mpdd-1586987315-1-3-i-due-canali-bbs-e-store-fic"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1586987315/1.3+-+I+due+canali+BBS+e+Store+FIC"
title: "1.3 - I due canali: BBS e Store FIC"
authority: descriptive
version_hash: "sha256:ca7c3b20fd952df77af2c4c918a65fbc29f4e3510a4715bc5bcea0504e9a3fdc"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1586987315-1-3-i-due-canali-bbs-e-store-fic.md", version_hash: "sha256:ca7c3b20fd952df77af2c4c918a65fbc29f4e3510a4715bc5bcea0504e9a3fdc"}
body_hash: sha256:40d4ac0b0a3f8d7472bb3e694501eb9b1c255da4d86c3941fa902adbfd14eda1
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1586987315-1-3-i-due-canali-bbs-e-store-fic.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# 1.3 - The two channels: BBS and FIC Store

A TeamSystem product can be sold through two channels. The channel determines **how the package is created in the Metering**, but from the point of view of the Business Capability the result is identical: a webhook with the same payload always arrives.

|  |
| --- |
| ✓  The sales channel is transparent for the Business Capability: the webhook receives exactly the same payload from BBS as from FIC. |

**Channel 1 — BBS (sales reps, CRM, TeamSystem Store)**

BBS is the commercial system for traditional selling. It collects orders from two sources:

- **TeamSystem Store** — the client buys directly online (self-service)

- **CRM** — a sales rep enters the order manually on behalf of the client

In both cases the flow towards the Metering is identical.

![03-flusso-crm-bbs-metering.png](assets/03-flusso-crm-bbs-metering.png)

**Step-by-step of the BBS flow**

|  |  |  |
| --- | --- | --- |
| **#** | **Who** | **What they do** |
| 1 | **Client / Sales rep** | Buys from the TeamSystem Store (self-service), or the sales rep enters the order in the CRM. |
| 2 | **BBS** | Receives the order, checks the license, prepares the provisioning. |
| 3 | **BBS → Metering** | **POST Company**: sends company data (CF/VAT number) + user email. Metering returns the Company Registry ID.  *⚠  The email is mandatory and blocking — without an email the provisioning stops.* |
| 4 | **BBS → Metering** | **POST Package**: sends Company Registry ID + Family name + constraint + expiry dates.  *The Family name must correspond exactly to the one configured in the Metering.* |
| 5 | **Metering** | Reads the Family, finds all the registered serviceIds. For each one it prepares a webhook call. |
| 6 | **Metering → Product** | For each serviceId: HTTP POST to the webhook with action ENABLE\_SUBSCRIPTION, passing ownerId, workspaceId (or itemId), serviceId, details. |
| 7 | **Product** | Receives the webhook, activates the feature for that client/workspace, responds HTTP 200. |

**Channel 2 — FIC Store / external applications**

For products sold through external channels (e.g. FIC), the flow **bypasses BBS**: the subscription is created directly through the Wrapper (agyo-subscription-api), without the two standard POST Company / POST Package calls.

![04-flusso-store-fic-wrapper.png](assets/04-flusso-store-fic-wrapper.png)

|  |  |  |
| --- | --- | --- |
| **#** | **Who** | **What they do** |
| **1** | **Client** | Buys from the FIC Store. |
| **2** | **Wrapper** | Calls agyo-subscription-api with Family, ownerId, itemId/workspaceId.  *Warning: the name field must not contain underscores. E.g.: FIC\_COMPLETE → name: FICCOMPLETE* |
| **3** | **Metering** | Creates the package directly, without going through BBS. Finds the serviceIds of the Family and prepares the webhook calls. |
| **4** | **Metering → Product** | For each serviceId: HTTP POST to the webhook — exactly the same payload as the BBS channel. |
| **5** | **Product** | Receives the webhook, activates the feature, responds HTTP 200. It does not know — and must not know — which channel it comes from. |

|  |
| --- |
| ⚠️  The Wrapper is a mode targeted for elimination — it is not the path to aim for in the long term. It requires an in-depth case-by-case evaluation with the Metering team before proceeding. |

**Comparison between the two channels**

|  |  |  |
| --- | --- | --- |
| **Aspect** | **BBS channel** | **FIC / Store channel** |
| **Entry point** | TeamSystem Store (self-service) or CRM (sales rep) | FIC Store or external application |
| **Who creates the package** | BBS via metering-service | Wrapper via metering-package-write |
| **API Company Flow** | POST Company + POST Package | Subscription V2 |
| **API Workspace Flow** | POST Company + POST Package | Subscription V3 |
| **Identifiers** | Uses bbs-id (then mapped internally) | Uses UUID directly (ownerId, itemId) |
| **name field** | — | Without underscores. E.g.: FIC\_COMPLETE → name: FICCOMPLETE |
| **Webhook payload** | **Identical** — same structure, same fields | **Identical** — same structure, same fields |

> **Channel transparency**
>
> From the point of view of the Business Capability, the sales channel is transparent: the webhook receives exactly the same payload whether it comes from BBS or FIC. Wherever it says "BBS must do X", for the FIC channel the same responsibility falls on whoever manages the FIC Store and its Wrapper.
