---
source_id: "confluence:confluence-cto-cto-918487120-release-management"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/918487120/Release+Management"
title: Release Management
authority: descriptive
version_hash: "sha256:0d40a38d4c7d4fbb4d3e45b0a47d856207fd1ba0d6ab2ebd9b1ba7d910aeaf69"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/CTO/cto-918487120-release-management.md", version_hash: "sha256:0d40a38d4c7d4fbb4d3e45b0a47d856207fd1ba0d6ab2ebd9b1ba7d910aeaf69"}
body_hash: sha256:c5bf332838d593689f27b234b5407e3b93cf6911076d2f11e856dbfffc381c97
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/CTO/cto-918487120-release-management.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# Release Management

The following proposal is structured in three parts:

1. **Functional proposal**
2. **Technical-operational proposal**
3. **End-to-end journey of the release** (with the 3 cases: core service, Business Capability, commercial offer + the specific “Planner” case)

---

# 1. FUNCTIONAL RELEASE MANAGEMENT PROPOSAL

The platform manages **three distinct entities with different release cycles**:

1. **Core services**
2. **Business Capability (BC)**
3. **Commercial offers**

This distinction is fundamental in order to guarantee:

- Functional consistency
- Reduction of operational complexity
- Speed and flexibility of release
- Structured governance of the releases
- Alignment with the market offers

Business scenarios examined:

- a new core feature must be opened to a particular commercial offer
- Within the commercial offer, the BCs must have “frozen” versions, compatible and consistent with each other
- A new version of a BC must be enabled on a single commercial offer, while all the others postpone the opening further into the future

![image-20251217-090710.png](assets/image-20251217-090710.png)

## 1.1 Core Services

**Release model**:  
✅ **Mandatory Rolling Release**

**Key principles:**

- Backward compatibility guaranteed through API versioning ( a single codebase, a single running service, several implementations )
- Deprecated APIs kept until a certain date
- Versioned release notes
- The new features can be managed with **feature flag / feature toggle**

  - openfeature standard, product to be adopted/evaluated
  - used **ALSO** to do A/B testing or to enable features for blocks of users
  - toggle naming convention defined and homogeneous - clear and applied in all the BCs or wherever it is needed
- There are no multiple deploys in parallel

**Case #1 – Developer releases a new Core Service feature (e.g. workspace historization, new Planner version of the Assistants)**

![Screenshot 2025-12-17 alle 10.12.18.png](assets/Screenshot 2025-12-17 alle 10.12.18.png)

```
    Servizio core che fornisce funzionalità di gestione del workspace
    condiviso e strumenti di collaborazione per le BC.
  owner: "Platform Engineering"
  lifecycle: "active"   # active | deprecated | sunset

# componenti tecniche incluse nel servizio
components:
  - id: "workspace-api"
    type: "rest"
  - id: "workspace-sdk"
    type: "package"
    languages:
      - java
      - node
      - python

# dipendenze da un altro servizio di piattaforma
platformDependencies:
  - name: "identity-platform"
    urn: "urn:ts:platform:identity:1.4.0"
    minVersion: "1.4.0"
    compatibility:
      testedWith:
        - "1.4.x"
        - "1.5.x"

domainReleaseNotes:
  version: 2.1.0
  date: 2025-03-02
  changes:
    - list of all changes
  breakingChanges: false

# policy di deprecazione
deprecationPolicy:
  noticePeriod: "12 months"
  replacement:
    urn: "urn:ts:core:workspace:3.0.0"
    status: "planned"

featureFlags:
provider: OpenFeature
managedFlags:
  - name: new-feature-A
    default: false
  - name: new-feature-B
    default: false
]]>
```

> _Translation note:_ the Italian inside the block above reads — description: “Core service that provides shared workspace management features and collaboration tools for the BCs”; comments: “technical components included in the service”, “dependencies on another platform service”, “deprecation policy”.

**Objective:**  
Avoid fragmentation and multiplication of the versions at infrastructural level.

> The core services evolve continuously and are used both by the BCs and by the offers.

---

## 1.2 Business Capability (BC)

**Release model:**

✅ **Rolling Release**   
⚠️ One **Stable** version  
⚠️ One **Release Candidate (RC)** version

The BC can be:

- In **rolling release (default and strongly recommended)**
- In a **“frozen” version only as a controlled exception, and exclusively within the application perimeter** (the platform will not provide any support for possible data migrations and will not guarantee consistency in the case in which this migration has cross-capability repercussions)

**Every BC has:**

- Domain release notes

  - adoption of a standard / open tool
- A manifest (YAML)
- A declared contract.
- A URN that represents the capability and its version

The BCs declare:

- The core services used
- Minimum required versions
- Compatibility
- Deprecation policy

**Case #2 – Developer releases a new major version of a Business Capability, to be tested in a new commercial offer (Release Candidate)**

![Screenshot 2025-12-17 alle 10.15.40.png](assets/Screenshot 2025-12-17 alle 10.15.40.png)

Example of BC yaml:

```
    Business Capability responsabile della gestione contabile completa
    (prima nota, piano dei conti, registrazioni, liquidazioni IVA, scritture di assestamento).

  owner: Accounting Platform Team
  steward: 

  urn: urn:teamsystem:bc:contabilita:3.4.0
  lifecycle: stable
  createdAt: 2025-01-15
  updatedAt: 2025-03-02

domainReleaseNotes:
  version: 3.4.0
  date: 2025-03-02
  changes:
    - Aggiunto supporto multi-regime IVA
    - Migliorata gestione competenze e ratei
    - Ottimizzazione performance su registrazioni massive
  breakingChanges: false

coreServicesUsed:
  - service: workspace
    versionRequired: ">=2.1"
    versionInUse: "2.1"
  - service: authorizer
    versionRequired: ">=3.0"
    versionInUse: "3.0"

compatibility:
  backwardCompatible: true
  forwardCompatible: limited
  testedWith:
    - workspace: "2.1"
    - authorizer: "3.0"
  unsupported:
    - workspace: "<2.1"
  notes: >
    Questa BC non può essere eseguita se la versione del Workspace
    è inferiore alla 2.1. Alcune funzionalità avanzate richiedono
    authorizer >= 3.0

deprecationPolicy:
  announcesBefore: "90 days"
  previousVersionSupported: "2.9.x"

contracts:
  pact:
    provider: contabilita-service
    consumer: offers-composition-engine
    url: https://pactflow.io/contracts/contabilita
  openapi:
    url: https://api.teamsystem.com/contracts/contabilita/openapi.yaml
  jsonSchema:
    url: https://api.teamsystem.com/contracts/contabilita/schema.json

endpoints:
  baseUrl: https://api.teamsystem.com/contabilita
  environments:
    - dev
    - test
    - prod

featureFlags:
  provider: OpenFeature
  managedFlags:
    - name: new-vat-engine
      default: false
    - name: smart-reconciliation
      default: false
]]>
```

> _Translation note:_ the Italian inside the block above reads — description: “Business Capability responsible for complete accounting management (day book, chart of accounts, entries, VAT settlements, adjusting entries)”; changes: “Added multi-regime VAT support”, “Improved management of accruals and deferrals”, “Performance optimization on mass entries”; notes: “This BC cannot be executed if the Workspace version is lower than 2.1. Some advanced features require authorizer >= 3.0”.

> **Versioning of the BCs is discouraged**: the preferred mode is the rolling release.  
> Stable / RC serve only as a control point towards the commercial offers.

Admitting the versioning of the stables, we should also hypothesize a governance policy.

---

## 1.3 Commercial Offers

**The commercial offers are IMMUTABLE.**

If something changes:  
➡️ **a new offer** is created, the existing one is not modified. And consequently the “license” is upgraded on the clients to whom we want to give the new feature (or take it away)

Every offer is defined by:

- A **YAML manifest**
- The list of the BCs (through URN)
- The commercial configuration (e.g. COMIC2025, COMIC2026) to drive the provisioning logics on the platform

**Case #3 – Release of a new Commercial Offer (COMIC2026)**

![Screenshot 2025-12-17 alle 10.17.21.png](assets/Screenshot 2025-12-17 alle 10.17.21.png)

Example:

```
    Offerta commerciale COMIC2026 che include le Business Capability
    di Contabilità e F24, con configurazione a pacchetti commerciali.

  status: live
  immutable: true

  validFrom: 2026-01-01
  validTo: 2026-12-31

  owner: Product Management Accounting
  approvedBy: Business Owner SME Solutions

  createdAt: 2025-09-15

businessCapabilities:

  - name: contabilita
    urn: urn:teamsystem:bc:contabilita:3.4.0
    mandatory: true

  - name: f24
    urn: urn:teamsystem:bc:f24:2.1.0
    mandatory: true

commercialPackages:
  - packageCode: BASIC
    displayName: COMIC Base
    features:
      - prima-nota
      - piano-dei-conti-base
      - registri-iva
      - compilazione-manuale
      - pagamento-f24

  - packageCode: PRO
    displayName: COMIC PRO
    features:
      - cespiti
      - ratei-risconti
      - liquidazioni-periodiche
      - compilazione-automatica
      - pagamento-f24
      - storico-pagamenti
      - ravvedimento-operoso

  - packageCode: ENTERPRISE
    displayName: COMIC Enterprise
    features:
      - tutte-le-funzionalita
      - multi-azienda-illimitato
      - reportistica-avanzata
      - automazione-completa
      - multi-cooperative
      - integrazione-esterna
      - gestione-massiva

composition:
  engine: CompositionEngine
  version: 1.0
  registry: VersionRegistry
  bcResolutionMode: via-URN

distribution:
  channels:
    - launchpad
    - metering
    - crm
  activation:
    method: metering-driven
    provisioning: automatic

governance:
  changePolicy: "immutable"
  modifications:
    allowed: false
  replacementStrategy: "new-offer-only"
  nextVersionTemplate: COMIC2027

audit:
  certifiedBy: QA Platform Team
  certificationDate: 2025-10-10
  contractTests: passed
  integrationTests: passed
  securityScan: passed]]>
```

> _Translation note:_ the Italian description inside the block above reads: “COMIC2026 commercial offer that includes the Accounting and F24 Business Capabilities, with a commercial-package configuration”.

The URN is converted into a URL through a **Registry**.

The offer is deployed on:

- **Metering** → to drive the activations
- **Launchpad** → for display to the user
- store/stargate and the product interface for AI agents also to be evaluated

This guarantees:  
✅ Functional consistency of the offer  
✅ Commercial consistency  
✅ Governance of the activations

---

# 2. TECHNICAL-OPERATIONAL PROPOSAL

## 2.1 Version Registry (heart of the model)

The **Version Registry** is a central archive in which are registered

For every **Core Service**:

- Version
- Breaking changes
- Compatibility notes
- URL
- Creation / update date

For every **Business Capability**:

- Version
- Breaking changes
- Compatibility notes
- URN
- URL
- Creation / update date

For every **Commercial offer**:

- BCs to be included and their version
- Status (candidate / live / deprecated)

All the contracts and manifests must be registered in the Version Registry.

---

## 2.2 Capability Contract

Every capability must expose a **contract** that defines:

- API interfaces (OpenAPI) **and Events/DataProduct**
- Available fields (JSON Schema)
- Guaranteed behaviors
- Minimum version of the core services
- Deprecation policy

Technologies:

- Versioned OpenAPI/DataProduct
- Pact Contract Testing
- Versioned JSON Schemas
- Versioning of the events (if event-driven)

---

## 2.3 Composition Engine

A component is needed that:

- Reads the BCs from the Version Registry
- Checks compatibility
- Calculates the snapshot of the offer
- Generates the **candidate version** of the offer
- Allows manual approval
- Signs the version after having approved it

This generates the manifest, of which we report here a simplified version of the yaml indicated in the Commercial Offer section:

```
" },
    { "artifactId": "contabilita",   "URN": "" },
    { "artifactId": "f24",           "URN": "" },
    { "artifactId": "bilancio",      "URN": "" },
    { "artifactId": "digital-invoice","URN": "" }
  ]
}
]]>
```

2.4 Health Monitoring

I would add a Health service for the BC and its endpoints, and its monitoring/alerting.  
Like the health of K8S or other mechanisms but brought to BC level.

---

## 2.4 Mandatory prerequisites

The model requires:

✅ Mechanism for **domain release notes**  
✅ System for **certification of the release**  
✅ Version Dashboard for Product Owners  
✅ Feature Flags + Monitoring  
✅ Compatibility rules (e.g. *auth >7* does not go to prod if auth prod <7\*)

It is declared during the process for example:

> *identity-v3*

---

# 3. END-TO-END JOURNEY OF THE RELEASE

## 3.1 Case 1 – Developer releases a Core Service

1. The developer publishes a new version of the core service
2. The new feature is:

   - disabled by default
   - managed by a **feature flag**
3. **Backward compatibility** is guaranteed
4. There are no multiple versions in parallel
5. The service is immediately made available to the BCs

👉 No action on the offers.  
👉 No modification on the BCs, except in the case of new optional features.

## specific case example: new version of the Planner

Two models compared:

### A. Versioning via DevOps (routes towards several versions)

- Intelligent routing between versions
- In case of a hotfix → backporting on all the versions
- High overhead and complexity, replicated infrastructure

### B. Versioning via feature toggling (preferred option)

- A single Planner
- Feature toggle for progressive release
- No backport
- No multi-version routing

✅ Recommendation: **feature toggling**, consistent with the model of the core services.

---

## 3.2 Case 2 – Developer releases a Business Capability

1. The team updates the BC with major changes
2. There is published a:

   - **Release Candidate**
   - with a new contract and YAML manifest
3. The BC registers itself in the **Version Registry**
4. The event is notified:

   - version
   - breaking / compatibility
5. The BC is available for the Composition Engine

When validated:  
➡️ It is promoted to **Stable**

> Default: rolling release  
> Exception: stable / RC with separate URNs and separate pods (not separate DBs)

---

## 3.3 Case 3 – Release of a new Commercial Offer (COMIC2026)

1. The Person in charge of a Commercial Offer uses the **Version Dashboard**
2. The **Composition Engine** suggests a compatible snapshot
3. The YAML manifest is generated:

   - with the URNs of the BCs
4. CI/CD starts the tests:

   - contract test
   - end-to-end
   - integration
5. The offer manager approves
6. The offer is:

   - deployed on **Metering**
   - visible on **Launchpad**
   - store/stargate and the product interface for AI agents also to be evaluated
7. The offer becomes **immutable**
8. *when does the offer go to the store ? is it an automatic process ?*

Thus is born:

- COMIC2025 → remains unchanged
- COMIC2026 → new version with new URNs

![Screenshot 2025-12-03 alle 15.20.34.png](assets/Screenshot 2025-12-03 alle 15.20.34.png)

---

# KEY CONCLUSIONS

✅ Core services → **Rolling + Feature Toggle**  
✅ Business Capability → **RC / Stable + rolling recommended**  
✅ Commercial offers → **immutable + YAML + URN**  
✅ Version Registry → heart of the governance  
✅ Product Owner → owner of the release of the offer  
✅ Consistency at offer level always guaranteed

This model guarantees:

- Technical consistency
- Control over the market
- Organizational scalability
- Reduction of complexity


## Attachments & figures

![Screenshot 2025-12-03 alle 15.20.34.png](assets/Screenshot 2025-12-03 alle 15.20.34.png)
<!-- transcribe: assets/Screenshot 2025-12-03 alle 15.20.34.png -->

![Screenshot 2025-12-17 alle 10.12.18.png](assets/Screenshot 2025-12-17 alle 10.12.18.png)
<!-- transcribe: assets/Screenshot 2025-12-17 alle 10.12.18.png -->

![Screenshot 2025-12-17 alle 10.17.21.png](assets/Screenshot 2025-12-17 alle 10.17.21.png)
<!-- transcribe: assets/Screenshot 2025-12-17 alle 10.17.21.png -->

![Screenshot 2025-12-17 alle 10.11.31.png](assets/Screenshot 2025-12-17 alle 10.11.31.png)
<!-- transcribe: assets/Screenshot 2025-12-17 alle 10.11.31.png -->

![Screenshot 2025-12-17 alle 10.15.40.png](assets/Screenshot 2025-12-17 alle 10.15.40.png)
<!-- transcribe: assets/Screenshot 2025-12-17 alle 10.15.40.png -->
