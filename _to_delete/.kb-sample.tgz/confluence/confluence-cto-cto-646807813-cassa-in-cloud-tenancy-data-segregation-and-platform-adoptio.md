---
source_id: "confluence:confluence-cto-cto-646807813-cassa-in-cloud-tenancy-data-segregation-and-platform-adoptio"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/646807813/Cassa+in+Cloud+-+Tenancy+data+segregation+and+platform+adoption"
title: "Cassa in Cloud - Tenancy, data segregation and platform adoption"
authority: descriptive
version_hash: "sha256:11dea97bbda54d75632eeb4d39070046d177cc44ffe86016880c26ab13f54a05"
body_hash: "sha256:6d16ebd2b0eb22d45708211ff8a620d25ca3439df8b1be075deff0c04769af79"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/CTO/cto-646807813-cassa-in-cloud-tenancy-data-segregation-and-platform-adoptio.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---
# Cassa in Cloud - Tenancy, data segregation and platform adoption

# Use Cases

## 1. Single Store

![Screenshot 2025-09-10 alle 20.26.58.png](assets/Screenshot 2025-09-10 alle 20.26.58.png)

## 2. Multiple etherogeneous stores of the same company (no data are shared between them)

![Screenshot 2025-09-10 alle 20.28.19.png](assets/Screenshot 2025-09-10 alle 20.28.19.png)

## 3. Franchising entirely owned by a single company. Some data are shared between the stores (e.g. articles, customers, suppliers)

![Screenshot 2025-09-10 alle 20.29.40.png](assets/Screenshot 2025-09-10 alle 20.29.40.png)

## 4. Franchisor and franchisees are different companies with different owners. Some data are shared between the stores (typically articles but not customers and suppliers because they can be competitors)

![Screenshot 2025-09-10 alle 20.30.10.png](assets/Screenshot 2025-09-10 alle 20.30.10.png)

## 5. Franchisor and franchisees are different companies, sometimes owned by the same user. Some data are shared between the stores.

![Screenshot 2025-09-10 alle 20.30.43.png](assets/Screenshot 2025-09-10 alle 20.30.43.png)

## 6. Franchisor and some stores are in the same company, but some other store are in different ones. Some data are shared between the stores (typically articles, customers and suppliers, but not between different owners)

![Screenshot 2025-09-10 alle 20.31.25.png](assets/Screenshot 2025-09-10 alle 20.31.25.png)

# Potential Issues in Workspace adoption

- **How to share data between workspaces of different companies, with a single owner but multiple readers?** This will cover the use case of a Franchisor sharing articles definition to all the franchisees.
- **How to share data between workspaces of different companies both in read and write mode?** This will cover the “wallet” use case, where a customer of our customers have a shared virtual wallet he can recharge and use in different stores of different companies.
- **How to segregate data for different users of the same company based on the belonging to a specific store?** This will cover the use case of different managers of different stores of the same company that should not see and update customers and suppliers each other.


## Attachments & figures

![Screenshot 2025-09-10 alle 20.30.43.png](assets/Screenshot 2025-09-10 alle 20.30.43.png)
<!-- transcribe: assets/Screenshot 2025-09-10 alle 20.30.43.png -->

![Screenshot 2025-09-10 alle 20.31.25.png](assets/Screenshot 2025-09-10 alle 20.31.25.png)
<!-- transcribe: assets/Screenshot 2025-09-10 alle 20.31.25.png -->

![Screenshot 2025-09-10 alle 20.26.58.png](assets/Screenshot 2025-09-10 alle 20.26.58.png)
<!-- transcribe: assets/Screenshot 2025-09-10 alle 20.26.58.png -->

![Screenshot 2025-09-10 alle 20.28.19.png](assets/Screenshot 2025-09-10 alle 20.28.19.png)
<!-- transcribe: assets/Screenshot 2025-09-10 alle 20.28.19.png -->

![Screenshot 2025-09-10 alle 20.29.40.png](assets/Screenshot 2025-09-10 alle 20.29.40.png)
<!-- transcribe: assets/Screenshot 2025-09-10 alle 20.29.40.png -->

![Screenshot 2025-09-10 alle 20.30.10.png](assets/Screenshot 2025-09-10 alle 20.30.10.png)
<!-- transcribe: assets/Screenshot 2025-09-10 alle 20.30.10.png -->

![Screenshot 2025-09-10 alle 20.31.08.png](assets/Screenshot 2025-09-10 alle 20.31.08.png)
<!-- transcribe: assets/Screenshot 2025-09-10 alle 20.31.08.png -->

![a4942ab9-4f10-4907-87ad-576c87c6674f.png](assets/a4942ab9-4f10-4907-87ad-576c87c6674f.png)
<!-- transcribe: assets/a4942ab9-4f10-4907-87ad-576c87c6674f.png -->
