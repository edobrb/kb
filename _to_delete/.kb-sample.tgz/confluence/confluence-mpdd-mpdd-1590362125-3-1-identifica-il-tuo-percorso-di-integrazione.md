---
source_id: "confluence:confluence-mpdd-mpdd-1590362125-3-1-identifica-il-tuo-percorso-di-integrazione"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1590362125/3.1+Identifica+il+tuo+percorso+di+integrazione"
title: 3.1 Identifica il tuo percorso di integrazione
authority: descriptive
version_hash: "sha256:de2ecb43b6daceb4a801679adafc0efb7228281224cfe9468be422e3ff096c0d"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1590362125-3-1-identifica-il-tuo-percorso-di-integrazione.md", version_hash: "sha256:de2ecb43b6daceb4a801679adafc0efb7228281224cfe9468be422e3ff096c0d"}
body_hash: sha256:59585aee848aff583c721f51cdb282cc601b9d595508cf08b90d7925d66a14e0
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1590362125-3-1-identifica-il-tuo-percorso-di-integrazione.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# 3.1 Identify your integration path

### 1 — Classify your OnePlatform scenario

Technical prerequisite that conditions everything else.

| Question | Yes (+1) | No (0) |
| --- | --- | --- |
| Does the product use TsID as its identity system? | +1 | 0 |
| Does it use Registry / Workspace? | +1 | 0 |
| Does it use itemId / ownerId / workspaceId? | +1 | 0 |
| Does it follow the standard authentication model (JWT, native tenancy)? | +1 | 0 |
| Does it still have legacy authentication flows? | → Hybrid | — |
| Does it use no OnePlatform core service? | → Scenario 3 | — |

**Result:** 4 Yes = Scenario 1 (Native) | 1–3 Yes = Scenario 2 (Hybrid) | 0 Yes = Scenario 3 (No integration)

| Scenario | Characteristics | Complexity | Metering implication |
| --- | --- | --- | --- |
| 1 — Native | TsID, JWT, ownerId/itemId/workspaceId | Low | Standard path. Direct Company or Workspace Flow. |
| 2 — Hybrid | Some core services, legacy flows still active | Medium | Complete Integration Questionnaire v1.6 with Giovanni Colasurdo before proceeding. |
| 3 — No integration | No OnePlatform core service | High | Assess identity migration. Metering integration postponed. |

> ⚠️ **Scenario 2 or 3:** If your product is in Scenario 2 or 3, the first step is to complete the 1P questionnaire (Integration Questionnaire v1.6) with the OnePlatform team (Giovanni Colasurdo). Metering is a Core Service: identity, tenancy and workspace must already be aligned.

### Step 2 — Identify the Metering path

| Path | When | Where to go |
| --- | --- | --- |
| PATH A — First integration | Your product has NEVER interacted with Metering. No Family, Services or Constraints are configured. | → Page 3.A |
| PATH B — Already integrated | Your product already has Family and/or packages active on Metering. You want to create a new Family, add a service or modify the existing configuration. | → Page 3.B |

### Step 3 (mandatory for both) — Definition with BBS

All the following items must be completed before opening a call with the Metering team.

> ⚠️ **Products already active in BBS:** It is not possible to modify the flow flag (APIOK → Metering) on existing product codes. If the product is already active in BBS with the standard flow, a recoding is required.

| To be defined with BBS | Notes |
| --- | --- |
| Commercial offer defined | New offer or cloned from an existing one |
| BBS items created with the Metering flag | No longer APIOK/APIX. The flag is per item and not modifiable retroactively |
| User email made mandatory | Blocking field in the POST Company — mandatory both in the CRM and in the Store |
| Price list structure defined | Versions / packages / add-ons: this structure is the basis for defining the Family |
| Family drafted (name and structure) | Same functionality + different limit = same Family. Different functionality = distinct Family |
| Multi-plant: Plant ID pre-named | Only if the product manages multiple sites/plants for the same client |

### General information to bring to the call

| Field | Answer |
| --- | --- |
| BC name ★ | E.g.: Electronic Invoicing, HR Suite… |
| Product Owner ★ | Contact details |
| Engineering Manager | Contact details |
| OnePlatform scenario ★ | Scenario 1 / 2 / 3 |
| Product status | In development / In production / In roadmap |
| Integration timeline ★ | E.g.: Q2 2026, by September, to be defined |
| Path | A (first integration) / B (already integrated) |

---

##
