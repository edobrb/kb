---
source_id: "confluence:confluence-mpdd-mpdd-1587380572-1-1-i-tre-attori-bc-family-bbs"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1587380572/1.1+-+I+tre+attori+BC+-+Family+-+BBS"
title: 1.1 - I tre attori BC - Family - BBS
authority: descriptive
version_hash: "sha256:dc27eb979c7287c2771e0820471c233e1091e1023f581c436a649112c57244df"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1587380572-1-1-i-tre-attori-bc-family-bbs.md", version_hash: "sha256:dc27eb979c7287c2771e0820471c233e1091e1023f581c436a649112c57244df"}
body_hash: sha256:b0d623f559533a1dc62f67462652302e6f443b8ba1fce6768be7ad874fc7516b
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1587380572-1-1-i-tre-attori-bc-family-bbs.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# 1.1 - The three actors BC - Family - BBS

## **What happens when a client buys a TeamSystem product?**

A client can acquire a TeamSystem product in two ways: **buying directly from the TeamSystem Store** (self-service), or through a **sales rep who enters the order in the CRM**. In both cases, the flow goes through BBS and produces the same result.

![flow-01-tripletta (1).png](assets/flow-01-tripletta (1).png)

These three systems do not know each other directly: they communicate through **precise contracts**. Understanding how they work is the basis for integrating any product with Metering.

## **The three actors**

|  |  |
| --- | --- |
| **1 - BBS / FIC Store** | **The commercial system**  It manages contracts, prices, expiry dates, renewals. It receives orders both from the self-service Store and from the sales reps via CRM. It knows nothing about features or webhooks: it only knows that that client has bought that package, with that expiry date.  **What it does towards Metering:** it sends two calls — POST Company (who the client is) and POST Package (what they bought). The Family name is the link between the two systems. |

|  |  |
| --- | --- |
| **2 - Metering - (Family)** | **The execution engine**  It receives the order from BBS and knows what to do: it reads the Family associated with that package, finds all the linked features, and calls the webhook of each one. It does not manage prices or contracts — it executes.  **The Family** is the technical name of the commercial offer in Metering. It is the bridge: BBS uses that name to tell Metering what to activate. Format: UPPERCASE\_WITH\_UNDERSCORE. E.g.: FATTURAZIONE\_PRO. |

|  |  |
| --- | --- |
| **3 - Business Capability** | **The product**  The real functional domain: Electronic Invoicing, HR, Payroll… It is composed of granular features, each of them independently activatable and measurable. Owned by the product team.  **What it receives from Metering:** an HTTP POST call to the webhook for each feature, every time the state of a client subscription changes. |

## **The Family: the technical name of your offer**

The Family is **the name with which BBS and Metering talk to each other**. When BBS creates a package for a client, it puts the Family name in it. Metering reads that name and knows exactly which features to activate, with which limits.

|  |
| --- |
| BBS creates package → Family: "FATTURAZIONE\_PRO"                                │                                ▼  Metering reads the Family FATTURAZIONE\_PRO    └── serviceId: FATTURA-ATTIVA    → calls product webhook    └── serviceId: FATTURA-PASSIVA   → calls product webhook    └── Constraint: 500/year         → keeps the counter |

>  🔭 **M3 direction**
>
> Today the Family is a technical concept configured manually by the Metering team. In M3 it will become a **Commercial Offer** , dynamically composable by the product team through the Capability Catalog, without manual intervention. The name "Family" remains for compatibility, but the concept evolves towards a structured commercial object with native tiers, add-ons and coupons.

## **The features: the minimum unit of the system**

A **feature** is the single piece of functionality that is switched on or off for a client. It is the minimum unit: it can be activated, deactivated, put into read-only **independently of the others**.

Every feature has three fundamental attributes:

|  |  |  |
| --- | --- | --- |
| **Attribute** | **What it is** | **Example** |
| **serviceId** | The unique technical name of the feature. Used by Metering to know which feature to call. | FATTURA-ATTIVA, BI-AMM Format: UPPERCASE with hyphen. |
| **Webhook endpoint** | The URL to which Metering sends the activation/deactivation calls for this feature. | https://mioprodotto/api/v1/webhook |
| **Flow type** | What the feature is activated on: on the whole company or on the single workspace. | WORKSPACE (default) /  ITEM  Definitive choice — hard to change afterwards. |

|  |
| --- |
| ⚠️  Metering does not call "the capability". It calls every single feature associated with the Family, one by one, each on its own webhook.  If a Family has 3 features, Metering makes 3 separate webhook calls — one per feature. |

## **How a commercial offer is composed**

A commercial offer (= a Family) is a combination of features, which can come from **one or more Business Capabilities**.

|  |
| --- |
| Offer "Product PRO"  →  Family: PRODOTTO\_PRO    ├── serviceId: CORE-FUNCTION     ← from the "Product" BC    ├── serviceId: ADVANCED-FEATURE  ← from the "Product" BC    └── serviceId: ANAGRAFICA        ← from a different BC |

The composition rules:

- **A BC can have N features** — you decide how many pieces of functionality to expose

- **A Family can include features from different BCs** — maximum commercial flexibility

- **A feature can be in more than one Family** — the same functionality in different tiers

- **Same functionality + different limit = same Family** — only the constraint changes

- **Different functionality = distinct Families**

## **The multi-licence case**

If the same feature is included in two different Families and a client has bought **both**, Metering handles the situation like this:

|  |  |
| --- | --- |
| **Event** | **What happens** |
| The client buys both packages | Metering sends ENABLE\_SUBSCRIPTION for the same feature twice — one per package. The product must handle it without breaking (idempotency). |
| One of the two packages expires | Metering sends DISABLE\_SUBSCRIPTION. But the feature must remain active because the other package is still valid. |
| Both packages expire | DISABLE\_SUBSCRIPTION → the feature really is to be deactivated. |

|  |
| --- |
| Metering deactivates a feature only if no active package keeps it switched on.  The product must handle the multi-licence case using (serviceId + itemId) or (serviceId + workspaceId) as a composite key — serviceId alone is not enough.  The governance of the multi-licence case on shared features is an open topic at platform level. |

## **Note on BBS and FIC Store**

BBS collects orders from two sources: the **TeamSystem Store** (self-service) and the **CRM** (a sales rep who enters the order manually). In both cases the flow towards Metering is identical.

For the external channels there is the **FIC Store**, which performs the same role through the Wrapper (agyo-subscription-api).

|  |
| --- |
| ⚠️  The Wrapper is a target mode to be eliminated — it is not the path to aim for.  From the point of view of the Business Capability, however, the channel is transparent: the webhook receives exactly the same payload from BBS as from FIC.  Wherever in this wiki it says "BBS must do X", the same responsibility applies to whoever manages the FIC Store. |

Next page: 1.2 - One capability, many features  |  For the flows in detail: 1.3 - The two channels: BBS and FIC Store


## Attachments & figures

![01-business-capability.png](assets/01-business-capability.png)
<!-- transcribe: assets/01-business-capability.png -->

![02-offerta-prodotto-pro.png](assets/02-offerta-prodotto-pro.png)
<!-- transcribe: assets/02-offerta-prodotto-pro.png -->

![08-modello-completo.png](assets/08-modello-completo.png)
<!-- transcribe: assets/08-modello-completo.png -->

![flow-03-composizione-offerta.png](assets/flow-03-composizione-offerta.png)
<!-- transcribe: assets/flow-03-composizione-offerta.png -->

![flow-01-tripletta.png](assets/flow-01-tripletta.png)
<!-- transcribe: assets/flow-01-tripletta.png -->

![flow-01-tripletta (1).png](assets/flow-01-tripletta (1).png)
<!-- transcribe: assets/flow-01-tripletta (1).png -->

![flow-02-family-feature.png](assets/flow-02-family-feature.png)
<!-- transcribe: assets/flow-02-family-feature.png -->
