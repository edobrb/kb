---
source_id: "confluence:confluence-cto-cto-1079836744-oneplatform-reference-implementation-scope"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/1079836744/OnePlatform+Reference+Implementation+Scope"
title: OnePlatform Reference Implementation Scope
authority: descriptive
version_hash: "sha256:9d40ba3eca0d5d588af97ad9ed39b4d750e4ab5054a3da845c95ee01022b0123"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/CTO/cto-1079836744-oneplatform-reference-implementation-scope.md", version_hash: "sha256:9d40ba3eca0d5d588af97ad9ed39b4d750e4ab5054a3da845c95ee01022b0123"}
body_hash: sha256:678c36991ef25554c95e7b4d836f888539d6a84b19a3b6f427e8e1e319c08ad7
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/CTO/cto-1079836744-oneplatform-reference-implementation-scope.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# OnePlatform Reference Implementation Scope

## **Executive Summary**

OnePlatform's Reference Implementation ( RI ) came about to solve a structural problem of the platform: the architecture exists, the principles are clear, the services are available, but what is missing is an executable and reproducible model showing how all of this takes shape in a real application: a Business Capability ( BC ) . The RI fills exactly this gap.

It is not a Proof of Concept and it is not a teaching example. It is an official golden path, built with real platform components, which represents the correct, supported and maintainable way of developing applications on OnePlatform. Its value lies not so much in what it demonstrates as in what it prevents: arbitrary interpretations, local shortcuts, improper couplings and solutions that work today but tomorrow become constraints.

The RI is meant to be copied, not studied. It must be possible for an internal team, a country or a system integrator to take it and make it the basis of a real project, without conceptual rewrites. For this reason it is delivered as a complete package: working code, libraries, configurations, documentation and a clear start-up path. Everything that is not industrially replicable is deliberately excluded.

## **Scope of the Reference Implementation**

The Reference Implementation defines the minimal but complete scope of a OnePlatform business capability. It does not cover a specific business domain, but stages the structural elements that every real application will inevitably have to face: application lifecycle, integration with the platform core services, tenant management, security, observability and extensibility.

From the architectural point of view, the RI makes explicit the model of domain separation and the way in which these talk to each other through APIs and events. There are no shortcuts or direct accesses: every interaction is mediated by clear, versioned and verifiable contracts. This is not an implementation detail, but an underlying assumption: the platform lives on contracts, not on implicit knowledge.

The frontend is an integral part of the scope. The RI uses ICE not as a technology showcase, but as a concrete demonstration of federation, isolation and composition. The ICE playground is not an accessory: it is the place where the frontend model is made observable, experimented with and then reused in the final boilerplate.

A central aspect of the scope is controlled extensibility. The Reference Implementation demonstrates how a BC can evolve, introducing new behaviours through composition, configuration and explicit extension points. This holds both for the backend and for the frontend. The goal is not maximum flexibility, but governed flexibility, the kind that allows different teams to work autonomously without introducing systemic risk.

Finally, the RI explicitly includes the way in which development is done. Pipelines, scripts, configurations and conventions are not accessories, but part of the contract.

## Requirements

The Reference Implementation provides for a frontend developed in React, integrated as a micro-frontend inside ICE / OneFront / playground, used as the official composition shell that offers a HelloWorld screen displaying company data. The frontend has no internal business logic: it limits itself to orchestrating interactions, displaying state and respecting the authorization constraints defined by the platform. ICE is therefore a structural part of the solution, not an optional container.

The application exposes two distinct Business Capabilities, clearly separated at the conceptual and implementation level. The first Business Capability (BC1) represents an explicit action by the user: a simple interaction, such as clicking a button. This action produces no direct effects on the second capability, but generates a domain event published through Hermes, which represents the only communication mechanism between the two.

The second Business Capability (BC2) is completely decoupled from the first and reacts exclusively to the events it receives. On receipt of the event coming from BC1, BC2 updates a persistent running total, saved to a database. This data represents a real application state, not a simulated one, and is made available through an API exposed by BC2, consumed by the frontend for display.

From the point of view of application security, the Reference Implementation provides for two distinct user profiles. The first profile has the permission to interact with BC1 and to view BC2, and can therefore generate events and observe the effect on the running total. The second profile is instead limited to viewing BC2 only and has no possibility of interaction with BC1. The difference in behaviour is managed through authorizations, not through conditional logic in the frontend.

The solution includes the configuration of two companies / workspaces. The first workspace is intentionally empty and serves to demonstrate the behaviour of the platform in the absence of enabled Business Capabilities. The second workspace is instead configured with both Business Capabilities active and represents the complete application context. This makes it possible to show clearly the concept of isolation and per-tenant configuration.
