---
source_id: "confluence:confluence-mpdd-mpdd-1589149784-2-2-guida-per-tech-lead-e-dev-wip"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1589149784/2.2+-+Guida+per+Tech+Lead+e+Dev+WIP"
title: 2.2 - Guida per Tech Lead e Dev (WIP)
authority: descriptive
version_hash: "sha256:08cf82142907e1ecabafe14e6c0e4ad3ef692622f815531830132baa0050503b"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1589149784-2-2-guida-per-tech-lead-e-dev-wip.md", version_hash: "sha256:08cf82142907e1ecabafe14e6c0e4ad3ef692622f815531830132baa0050503b"}
body_hash: sha256:adf019f91a4674177ddc522d5deca004631337a0f52fc6eba9a7334b6e4bc9a0
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1589149784-2-2-guida-per-tech-lead-e-dev-wip.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# 2.2 - Guide for Tech Leads and Devs (WIP)

## **Your responsibilities**

1. **Define the serviceIds**

They must be globally unique. Convention: UPPERCASE, separated by -, max chars 15

**Implement the webhooks**

One endpoint per feature (or a shared one that routes by serviceId), idempotent, handling all 4 actions

3. **Choose Company Flow vs Workspace Flow**

A single and final decision for every feature — high impact to change in production

4. **Handle multi-licensing**

The same feature could receive several ENABLEs from different packages. Use serviceId + itemId/workspaceId as the key

5. **Integrate the Metering read APIs**

To check the activation status of the features at runtime and show the user which features are active

6. **Validate the incoming M2M token** — the token is managed by the Metering team, you only have to validate it

> The token that Metering uses to call your webhook contains the action `SERVICES_SUBSCRIPTION_WEBHOOK:WRITE`. **You must not request this token yourself** , it is managed by the Metering team. Your responsibility is to validate it on arrival by checking the JWK signature + the presence of that action. Read more here: <https://development.teamsystem.com/docs/default/component/m3/m3/core-features/feature-activation-flow/>

## **Webhook architecture**

Metering calls the endpoint exposed by your product in HTTP POST every time the status of a subscription changes. Your endpoint must be reachable for every environment (DEV / TEST / PROD) and respond HTTP 200 on success.

```
 https://tuo-prodotto/api/v1/webhook
                        │
                        ├── leggi "action"    → cosa fare
                        └── leggi "serviceId" → per quale feature]]>
```

> _Translation note:_ the diagram branches read "read "action" → what to do" and "read "serviceId" → for which feature".

![07-webhook-metering.png](assets/07-webhook-metering.png)

## **Expected behavior for each action**

**Base rules:**

- The endpoint must be reachable from the Metering network for every environment: DEV / TEST / PROD
- It must respond HTTP 200 on success
- **It must be idempotent**: the same call repeated always produces the same result
- **It must handle all 4 actions** — implementing only some of them causes malfunctions

## **The payload you will receive**

Metering sends an HTTP POST with the following JSON. The action names in the payload use the extended form (different from the abbreviated aliases used in the documentation).

## Meaning of each field

|  |  |  |
| --- | --- | --- |
| **Field** | **Type / Example** | **Operational meaning** |
| action | ENABLE\_SUBSCRIPTION | Action requested by Metering. See the action table below. |
| ownerId | uuid (always populated) | Identifies the tenant owner (TsID). Use it for logging and audit trail. |
| itemId | uuid or null | UUID of the company (Company Flow). Null if the product uses Workspace Flow. |
| workspaceId | uuid or null | UUID of the workspace (Workspace Flow). Null if the product uses Company Flow. |
| appId | APP\_CATEGORY | Application category. Constant for all the services of your product. |
| featureCode | APPLICATION\_NAME | Application name. Do not use it to route the logic: use serviceId. |
| serviceId | product.feature-name | Primary routing key: it identifies which feature to activate/deactivate. |
| details | { } or object | Optional extra data. By default it is empty; it can contain custom fields if agreed with the Metering team. |
| resellerId | UUID or **null** |  |

> **⚠️  WARNING** itemId and workspaceId are mutually exclusive: one will always be null. The Company Flow vs Workspace Flow choice is final for every feature: it is not changed in production without impact on active clients. See [→ Section 3.0, Step 2] to choose the correct flow.

## Expected behavior for each action

|  |  |  |
| --- | --- | --- |
| **Action (name in the payload)** | **Short alias** | **What your product must do** |
| ENABLE\_SUBSCRIPTION | ENABLE | Activate the feature for the indicated company or workspace. If no activation exists → create and activate. If it already exists → noop (idempotent). |
| DISABLE\_SUBSCRIPTION | DISABLE | Completely deactivate the feature. If it exists → deactivate. If it does not exist → noop. |
| ENABLE\_READONLY\_SUBSCRIPTION | ENABLE\_RO | Put the feature into read-only (e.g. constraint threshold reached). If an activation exists → switch to readonly. If it does not exist → noop. |
| DISABLE\_READONLY\_SUBSCRIPTION | DISABLE\_RO | Remove readonly mode and restore full access. If a readonly activation exists → restore. If it does not exist → noop. |

> **Behavior in case of a webhook error**
>
> If the webhook responds with an error code (not 200), Metering schedules a retry If the webhook keeps failing, the event is moved to dead-letter and requires manual intervention by the Metering team. Make sure your endpoint is idempotent: the same payload can arrive several times.

|  |
| --- |
| **→** For the full detail of the idempotency and multi-licensing rules → Section 4.1 — The 4 webhook actions |

## Testing with curl — mandatory before the call

Before requesting the call with the Metering team, the webhook must be tested with curl for ALL 4 actions. An untested webhook is the main cause of onboarding delays.

```
" \
  -d '{
    "action": "ENABLE_SUBSCRIPTION",
    "ownerId": "test-owner-001",
    "itemId": null,
    "workspaceId": "test-workspace-001",
    "appId": "MY_APP",
    "featureCode": "MY_FEATURE",
    "serviceId": "NOME-FEATURE",
    "resellerId": null,
    "details": {}
  }' \
  https://tuo-prodotto/api/v1/webhook

# Ripetere con: DISABLE_SUBSCRIPTION
#               ENABLE_READONLY_SUBSCRIPTION
]]>
```

> _Translation note:_ the two commented lines read "repeat with:" followed by those action names.

## Family data to communicate to the Metering team

Before the call with the Metering team, you must have these fields ready. They are the same ones present in the M3 Template — this is a quick reference for the Tech Lead.

|  |
| --- |
| **→** For the complete filling-in → Section 3.A, block A2 (Path A) or 3.B, block B2 (Path B) |

|  |  |  |
| --- | --- | --- |
| **Technical field** | **Req.** | **Description and expected values** |
| **Family name** | ★ | Unique identifier on the platform. UPPERCASE format without spaces. E.g.: HR\_TIMESHEET, TREASURY\_CORE |
| **Description** | ★ | What this family represents commercially. |
| **ACTIVATION\_TARGET\_RESOURCE** | ★ | Where the subscription is activated: ITEM (company, Company Flow) or WORKSPACE (Workspace Flow). |
| **multi-purchasable** | ★ | Can the same company have several active subscriptions of this family? → true / false |
| **upgrade** | ★ | Does it support an upgrade of the constraint limit? (e.g. 50→100) → true / false |
| **downgrade** | ★ | Does it support a downgrade of the constraint limit? (e.g. 100→50) → true / false |
| **trial** | ★ | Is there a trial version? → true / false (if true, a separate Trial Family is needed) |
| **Is it an add-on?** | ★ | Can the package be purchased only by those who already have another active plan? Yes / No |
| **Parent Family** | if add-on | If add-on: name of the Family that must be active as a prerequisite. |
| **serviceId (for every feature)** | ★ | Unique identifier of the service. Format: product.feature-name |
| **Webhook endpoint (DEV)** | ★ | URL reachable from the Metering network in the DEV environment |
| **Webhook endpoint (TEST)** | ★ | URL reachable from the Metering network in the TEST environment |
| **Webhook endpoint (PROD)** | ★ | URL reachable from the Metering network in the PROD environment |
| **Constraint to be counted** | if present | What is measured (e.g. number of invoices), SYNC or ASYNC type, threshold, behavior at threshold (BLOCK or READONLY) |
| **Billing cycle** | if present | Monthly / Annual. Anniversary or fixed date. |

note42ec106fa0e2

**Family naming rule**

Same functionality + different limit = same Family. Different functionalities = distinct Families. Never configure Metering before BBS has defined (or is defining in parallel) the commercial offer.

**Family naming rule**

Same functionality + different limit = same Family. Different functionalities = distinct Families. Never configure Metering before BBS has defined (or is defining in parallel) the commercial offer.

## M2M authentication - the two flows

The integration provides for two distinct channels, both with M2M authentication:

|  |  |  |  |
| --- | --- | --- | --- |
| **Flow** | **Direction** | **When it happens** | **Token requested by** |
| Config flow (webhook) | Metering → Product |  | The token that Metering uses to call your webhook contains the action `SERVICES_SUBSCRIPTION_WEBHOOK:WRITE`. **You must not request this token yourself** — it is managed by the Metering team. Your responsibility is to validate it on arrival by checking the JWK signature + the presence of that action. |
| Consumption flow | Product → Metering  [https://development.teamsystem.com/docs/default/Component/m3/m3/core-features/consumption-flow/#aut…](https://development.teamsystem.com/docs/default/Component/m3/m3/core-features/consumption-flow/#authentication) | On every event to be counted | Product Team |

|  |
| --- |
| **→** To request the M2M token → MPDD: Quick Guides – Legacy M2M technical tokens and opening a Metering ticketand Legacy M2M technical tokens guide |

> **⚠️  WARNING** The token must be requested per environment (DEV / TEST / PROD separately). Delays in requesting the token are a frequent cause of longer integration times: open the ticket as soon as the serviceId is known, do not wait for the call with the Metering team.

## **Handle multi-licensing**

The same feature can receive several ENABLEs from different packages — e.g. the client has purchased two subscriptions that include the same feature.

**Rule:** use the pair (serviceId + itemId) or (serviceId + workspaceId) as a composite key and keep a counter of active subscriptions for that key.

|  |
| --- |
| ENABLE arrives  → increment the counter for (serviceId, workspaceId)  DISABLE arrives → decrement the counter. Deactivate ONLY if counter = 0 |

|  |
| --- |
| ⚠️  Do not overwrite the state: if a second ENABLE arrives for the same key, the feature must stay active and the counter must rise to 2. |

## **Technical pre-go-live checklist**

**serviceId and naming**

- Every feature has a unique serviceId with product.feature-name naming
- No generic serviceId (e.g. main, core without a product prefix)
- The serviceId has been communicated to the Metering team

**Webhook**

- The webhook is reachable from the Metering network for every environment: DEV / TEST / PROD
- The webhook handles all 4 actions (ENABLE, DISABLE, ENABLE\_READONLY, DISABLE\_READONLY)
- The webhook is idempotent (same call repeated = same result)
- The webhook responds HTTP 200 on success
- Tested with curl all 4 actions BEFORE going into the call with the Metering team

**Integration and flow**

- Multi-licensing handled (same feature activated by several packages at the same time)
- Flow chosen (Company / Workspace) and communicated to the Metering team
- The token that Metering uses to call your webhook contains the action `SERVICES_SUBSCRIPTION_WEBHOOK:WRITE`. **You must not request this token yourself** , it is managed by the Metering team. Your responsibility is to validate it on arrival by checking the JWK signature + the presence of that action.
- Verified that the BCs are registered on OnePlatform

**Pre-call coordination**

- Information A1–A5 (Path A) or B1–B2 (Path B) filled in and ready
- BBS has already configured the items with the Metering flag
