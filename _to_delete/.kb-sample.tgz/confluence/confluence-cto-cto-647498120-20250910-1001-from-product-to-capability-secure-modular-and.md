---
source_id: "confluence:confluence-cto-cto-647498120-20250910-1001-from-product-to-capability-secure-modular-and"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design"
title: "20250910_1001_From Product to Capability - Secure, Modular and Scalable Design"
authority: descriptive
version_hash: "sha256:eea5790024646d0e640c9c70aeeb044ae23685d0c93f9491c893bdd619dcc343"
body_hash: "sha256:2fff26ff9ef89a040ddf45a05c46a7b84e27eb6437c3584cd8981daf56a982e5"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/CTO/cto-647498120-20250910-1001-from-product-to-capability-secure-modular-and-.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---
# 20250910_1001_From Product to Capability - Secure, Modular and Scalable Design

# From Product to Capability - Secure, Modular and Scalable Design

## Summary

[From Product to Capability: Secure, Modular and Scalable Design](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#From-Product-to-Capability%3A-Secure%2C-Modular-and-Scalable-Design)

[Agenda](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Agenda)

[What is a business capability](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#What-is-a-business-capability)

[A product is something you can touch…](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#A-product-is-something-you-can-touch%E2%80%A6)

[Software can’t be touched.](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Software-can%E2%80%99t-be-touched.)

[Our offerings are playlists of capabilities](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Our-offerings-are-playlists-of-capabilities)

[TeamSystem Citymap](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#TeamSystem-Citymap)

[Business Capability & Architectural Dimensions](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Business-Capability-%26-Architectural-Dimensions)

[Diagram](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Diagram)

[Activation and Consumption Tracking](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Activation-and-Consumption-Tracking)

[Activation and Consumption Tracking - Offering](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Activation-and-Consumption-Tracking.1)

[Activation and Consumption Tracking - Details](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Activation-and-Consumption-Tracking.2)

[Tenancy and Isolation in the Platform: the Workspace model](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Tenancy-and-Isolation-in-the-Platform%3A-the-Workspace-model)

[Approach to Tenancy Specialization](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Approach-to-Tenancy-Specialization)

[Business Capabilities Authorization](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Business-Capabilities-Authorization)

[Business Capabilities Authorization User flow](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Business-Capabilities-Authorization---User-flow)

[Business Capabilities Authorization M2M flow](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Business-Capabilities-Authorization---M2M-flow)

[Business Capabilities Authorization Policy](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Business-Capabilities-Authorization---Policy)

[Business capability: autonomous yet composable](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Business-capability%3A-autonomous-yet-composable)

[OnePlatform sounds live](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#OnePlatform-sounds-live)

[When software is really a Business Capability?](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#When-software-is-really-a-Business-Capability%3F)

[Data Ownership and Data Sharing](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Data-Ownership-and-Data-Sharing)

[Distributed Master Data Model](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Distributed-Master-Data-Model)

[Distributed Master Data Model Example](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Distributed-Master-Data-Model---Example)

[Distributed Master Data Model UI/UX challange](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Distributed-Master-Data-Model---UI%2FUX-challange)

[The Integration layer as an enabler of dialogue between BCs](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#The-Integration-layer-as-an-enabler-of-dialogue-between-BCs)

[The Integration layer as an enabler of dialogue between BCs support to differ...](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#The-Integration-layer-as-an-enabler-of-dialogue-between-BCs---support-to-different-integration)

[Disassemble and reassemble to create value — not only software](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Disassemble-and-reassemble-to-create-value-%E2%80%94-not-only-software)

[Pattern to support trasformation](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Pattern-to-support-trasformation)

[An example: FiC use case](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#An-example%3A-FiC-use-case)

[… and AI?](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#%E2%80%A6-and-AI%3F)

[Key takeaways](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Key-takeaways)

[THANK YOU](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#THANK-YOU)

---

## **From Product to Capability: Secure, Modular and Scalable Design**

![slide-01.png](assets/slide-01.png)

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Agenda

![slide-02.png](assets/slide-02.png)

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## What is a business capability

![slide-03.png](assets/slide-03.png)

We're full of modules, microservices, APIs... yet we're still not truly ready to define it. Maybe it's because we make software, and software isn't like any other product.

It's fluid, changeable, and difficult to fit into traditional categories. And that's precisely why it's so fascinating to design, but also extremely complex to define, precisely because of the absence of clear boundaries. It forces us to think differently.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## A product is something you can touch…

![slide-04.png](assets/slide-04.png)

When you design them, you already think of them as a whole. And each of their parts—a leg, a handle, a wheel—has no value on its own. No one would be satisfied with a chair leg. Why? Because those pieces aren't autonomous; they can't be activated on their own, and they don't represent business value by themselves.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Sommario)

---

## Software can’t be touched.

![slide-05.png](assets/slide-05.png)

And it's this very fluid nature that leads us to the concept of **Business Capability**: what really matters isn't the software's external appearance, but its function—the value it can express in different contexts.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Sommario)

---

## Our offerings are playlists of capabilities

![slide-06.png](assets/slide-06.png)

**What is a business capability**? It’s a complete and autonomous business function—something that generates value for the customer, *and potentilly a custmer is willing to pay*, and can be activated, measured, and orchestrated.

Just as a song has value on its own and can be part of a thousand different playlists, a Business Capability can be reused and recombined to create different offers for different clients without having to rewrite everything from scratch.

This allows us to move from a monolithic product model to a modular and flexible one: we just compose the right playlist with the right capabilities every time.

And if capabilities are the songs, then what is Spotify for us? It’s our **OnePlatform**: the platform that allows songs to exist, to be accessible, listenable, and orchestrable without every team having to build everything from scratch.

OnePlatform is what enables Business Capabilities to become real-world offerings.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Sommario)

---

## TeamSystem Citymap

![slide-07.png](assets/slide-07.png)

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Business Capability & Architectural Dimensions

![slide-08.png](assets/slide-08.png)

---

### **Users**

This is where we define and manage the identities of the subjects—whether they are people or automated systems—who interact with the business capabilities. Their profiles also establish how these subjects are authorized to use the various functionalities.

---

### **Security**

Closely related to the user dimension, security ensures that every interaction with the capabilities is protected, reliable, and in full compliance with our corporate security requirements and current regulations.

---

### **Data Tenancy**

When we talk about security, another key dimension is data tenancy. This enables the data isolation model, which is fundamental for distinguishing between customers or different organizational units. Within OnePlatform, this concept materializes in the **'Workspace'**, which works in close connection with the Item Registry.

---

### **Data Governance & Integration**

In a platform that aims for modularity and composability, data governance and integration are essential. We must ensure that all managed data is properly governed, easily accessible, integrable, and consistent across different capabilities. This aspect is structured both in terms of the principles of responsibility that the capabilities must respect and a technological dimension supported by our iPaaS services, with **Hermes** at the forefront.

---

### **License Lifecycle Orchestration**

Finally, a crucial dimension is the orchestration of the license lifecycle delivered through business capabilities. It is essential to have centralized support to activate services, monitor their usage, evaluate their performance, and measure the value generated by each individual capability.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Diagram

![slide-09.png](assets/slide-09.png)

---

### **Phase 1: Startup and Provisioning**

The lifecycle of a capability begins in the bottom-right corner. When a license is purchased, the **BBS** system notifies **Metering**, which then orchestrates the essential setup activities for the customer. This process includes verifying the customer's existence on the **Item Registry** and creating or validating their corporate **workspace**. Once the environment is provisioned, the capability is activated.

---

### **Phase 2: Usage and Authorization**

Once a capability is activated, it becomes operational. To access it, users interact with **TSID** to obtain an authorization token, which is then used for calls to the capability. For access authorization, the capability queries the **Policy Manager**, which verifies the necessary permissions by consulting the **Profiles service**. Once authorized, the process proceeds within the capability's domain, always contextualized by the specific user and tenant.

---

### **Phase 3: Integration and Interoperability**

A capability may need to interact with other services or capabilities outside its own domain. In these cases, it will interface through the systems in the **integration layer**, based on its specific needs.

---

### **Phase 4: Consumption Logging**

Finally, a key responsibility of the business capability is to log consumption by communicating data to **Metering**. This can be done in two ways:

- If the capability emits business events on **Hermes** that are directly correlated with consumption (e.g., issuing an invoice), **Metering** can automatically register the consumption.
- Alternatively, the capability must explicitly invoke the **Metering APIs** when a consumption event occurs.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Activation and Consumption Tracking

![slide-10.png](assets/slide-10.png)

**Metering** isn't just a measurement mechanism; it's an enabler that allows for the activation of capabilities for our client companies, laying the groundwork for service delivery.

It is also integrated into the capability's lifecycle. This means it constantly tracks service usage and consumption throughout every phase, from activation for the entire life of the license, offering a complete and dynamic view.

Its configurable nature is a significant advantage: it flexibly supports various business models, such as pay-per-use or trial offers. It allows for the definition of customized thresholds, the generation of automatic alerts, and the production of analytical reports.

These reports ensure transparency and complete visibility for all stakeholders involved.

Finally, **Metering** is fully auditable and compliant. It ensures the traceability of all operations, information security, and full compliance with regulations—all fundamental aspects for governance and trust.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Activation and Consumption Tracking

![slide-11.png](assets/slide-11.png)

---

### **The Commercial Offering: Bridging Business and Technology**

A **Commercial Offering** is, in essence, a market concept. It represents a well-defined package of **Capabilities** that can be sold to or subscribed by our clients. For example, a 'Basic Package,' a 'Premium Offer,' or a 'Pay-per-Use' model are clear examples of how an offering translates into concrete solutions. Each offering is a true aggregation of capabilities, bundling a specific set of **Business Capabilities**. Each of these capabilities can, in turn, have multiple functionalities, or **features**.

---

### **Metering's Role as an Operational Translator**

This is where **Metering** plays a crucial role, acting as a true operational translator. It's responsible for evaluating the contractual conditions and consumption models associated with each offering. Based on this, it activates the relevant capabilities and enables the correct **features**. Following this, it constantly monitors and measures the actual consumption of every single capability included in the offering.

---

### **Metering-Driven Activation**

This brings us to the concept of **Metering-Driven Activation**. Using the data it collects—about consumption, reached thresholds, or other specific conditions—our system can dynamically enable or disable technical functionalities. This means we can, for example, bill for over-limit consumption, block certain **features** once a usage level is reached, or manage the temporary enablement of trial services.

---

### **Integrated Technical-Commercial Governance**

In this way, **Metering** enables **Integrated Technical-Commercial Governance**. It becomes the essential bridge between our business model and the actual behavior of the system. This integration guarantees fundamental consistency: what is sold to the customer translates precisely into what the system executes and enables, ensuring transparency and reliability.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Activation and Consumption Tracking

![slide-12.png](assets/slide-12.png)

---

- **Commercial Offerings**: These precisely define the contents of our proposals and establish the entire license lifecycle sold to our clients.
- **Constraints**: They define the specific consumption limits within which a license can be used, ensuring controlled and transparent resource management.
- **Extradata**: These are additional functionalities or add-ons that can be activated or configured to fit a specific commercial offering, enriching its value.
- **Capabilities**: Every commercial offering is directly linked to one or more specific **Business Capabilities** that must be enabled to deliver the service. This ensures that every commercial promise is backed by a concrete technical function.
- **Webhooks**: To orchestrate service management, we use **Webhooks**. Each **Business Capability** exposes a dedicated HTTP endpoint. This is essential for automatically receiving and managing requests for service activation, deactivation, or suspension, ensuring efficient and responsive management throughout the entire license lifecycle.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Tenancy and Isolation in the Platform: the Workspace model

![slide-13.png](assets/slide-13.png)

---

### **The Workspace: Data Isolation and Consistency**

The **Workspace** is our unit of isolation, a logical and completely isolated partition. This ensures the secure separation of organizational contexts, keeping the data and operations of one entity distinct and protected from all others.

Each workspace represents a well-defined organizational context, modeling an autonomous reality like a company, an agency, or a professional firm, and includes all of its basic master data.

Its structure is based on two key concepts: the **Owner**, who indicates who owns the data, and the **Item**, who the data is about. Depending on the operational context, the owner and item can be the same or different, offering the flexibility needed to model various business scenarios.

This is where **Shared Tenancy** across capabilities becomes crucial. The **workspace-id** is the common, unique identifier that all **Business Capabilities** on the platform use to operate within the same data context. This ensures that, even when interacting with different capabilities, information remains consistent and correctly isolated within the relevant workspace. It's the core mechanism that guarantees every operation is executed within the correct and protected organizational context.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Approach to Tenancy Specialization

![slide-14.png](assets/slide-14.png)

---

### **Granular Tenancy: Extending the Workspace**

Some capabilities require particularly specific access or visibility policies that operate at a more granular level than what the **workspace-id** provides. In these situations, we introduce an internal tenancy identifier, such as a **project-id** or a **business-unit-id**, to create additional logical compartments within a single workspace.

It's crucial to highlight some fundamental conditions for using these identifiers:

- **They do not replace the workspace-id.** The **workspace-id** always remains the primary key for organizational-level isolation. The granular identifier is an extension, not a replacement.
- **They are managed within the workspace itself.** This ensures their validity and management are always contextualized and controlled within the relevant organizational environment.
- **Validation is handled by the Policy Manager.** The **Policy Manager** is responsible for verifying that the user or system attempting to access a resource with a specific **project-id** or **business-unit-id** is authorized to do so. This guarantees compliance with access policies and consistency among capabilities that share the same level of specialization.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Business Capabilities Authorization

![slide-15.png](assets/slide-15.png)

---

- **Centralized Access Management** ensures unique and consistent identification for every user. With a centralized system, we guarantee that every subject—whether human or an automated system—is unequivocally recognized and managed with uniform policies across the entire platform.
- **Intrinsic Security of Business Functionalities** means security isn't an afterthought; it's a native property of every capability. It is designed and integrated from the ground up, cross-cutting across all functionalities. Every component is 'born secure,' which significantly reduces risk and complexity.
- **Zero Trust & Explicit Verification** means we adopt a "Zero Trust" approach. This implies that no entity is implicitly trusted, even if it's inside our network. For every service interaction, we require explicit verification of identity and permissions.
- **Clear Ownership in Access Management** is fundamental. The 'owner' of a capability has the explicit responsibility to define and maintain its access policies, ensuring they are always aligned with business and security needs.
- **Context-Aware Authorization Policies** mean permissions aren't static; they are always consistent with the specific context of the interaction. For example, a user might have different permissions depending on the workspace they're in or the type of transaction they're performing, which guarantees maximum precision and security.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Business Capabilities Authorization - User flow

![slide-16.png](assets/slide-16.png)

---

### **The Authorization Process: A Step-by-Step Guide**

1. **User Authentication.** The process begins with the **User**. The first step is for the user to log in via **TSID** (our identity management service) and, in doing so, obtain a **JWT** (JSON Web Token) that securely authenticates them. This token is their "access key."
2. **Capability's Delegation.** Once the user attempts to interact with a **Business Capability**, the capability receives the request. After validating the user's token, the capability does not decide authorization on its own. Instead, it delegates this responsibility by sending a specific request to the **Policy Authorizer**. This is a fundamental step of separating responsibilities, where the capability focuses on its core business logic and delegates security.
3. **Policy Evaluation.** The **Policy Authorizer** is the heart of this mechanism. Its function is to evaluate security rules, which are defined and managed in the **Policy Manager**. This evaluation occurs using the **ABAC** (Attribute-Based Access Control) model, an approach that allows for the definition of flexible and granular rules based on attributes of the user, resource, action, and context.
4. **The Outcome.** The outcome of this evaluation is simple and binary: the **Policy Authorizer** responds with a Boolean value, indicating whether the user is authorized or not authorized to perform the requested action.
5. **Execution or Blocking.** The result of this response directly guides the execution or blocking of the requested operation. If the user is authorized, the flow proceeds within the **Business Capability**; otherwise, the operation is blocked, ensuring security and compliance with policies.

This process ensures that every interaction is explicitly verified and that permissions are always consistent with the context of the operation.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Business Capabilities Authorization - M2M flow

![slide-17.png](assets/slide-17.png)

---

In these cases, specific **JWT** tokens are issued by **TSID** via a **client credential flow**. These tokens identify the calling *system*, not an end-user. The diagram we just discussed remains valid, with the only difference being that the original request comes directly from another **Business Capability** or system that needs to interact.

In these **M2M** scenarios, the assignment and management of access policies become the direct responsibility of the **owner** of the *called* **Business Capability**. This ensures that the calling capability is itself authorized to perform specific operations on the called capability.

The major advantage of this approach is that **M2M** access management is decentralized, while still maintaining a centralized evaluation logic. This allows for extremely granular control over permissions. Each **Business Capability** can be configured to interact only with the other capabilities it needs, which reduces the attack surface and increases the platform's overall security.

In summary, our **authorization framework** offers a consistent and scalable centralized solution capable of managing both user-to-service and purely system-to-system interactions, always guaranteeing security and control.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Business Capabilities Authorization - Policy

![slide-18.png](assets/slide-18.png)

As we've seen, the general authorization flow proceeds from the Authenticated Subject (whether a user or a system), passes through **TSID** for authentication, and then the **Business Capability** delegates authorization to the **Policy Authorizer**, which queries the **Policy Manager** for **Policy Evaluation**.

The **Policy Manager** is the heart of our authorization logic. Inside, we distinguish three main types of rules or profiles that work in synergy:

### **System Rules**

These are rules centrally defined by the platform. They represent the basic, cross-cutting, and fundamental security policies for the entire system's operation. They are established at an architectural level to guarantee a minimum level of security and consistency across all capabilities. They fundamentally concern interactions between items and are assigned dynamically by evaluating the combination of user profile, item, and connections.

- **Examples**:

  - When a feature is accessed, the policy manager checks that it is correctly licensed.
  - When a feature is accessed, the policy manager verifies that a firm can manage a company's data by checking the connections.

### **Domain Rules**

Every **Business Capability** has the flexibility to define its own specific domain rules. This means the owners of a capability can set policies that reflect their service's particular needs. These rules can be oriented toward specific users or other systems, allowing for notable granularity and customization.

- **Examples**:

  - The Product Owner (PO) defines the access rule for Timesheet reporting.
  - The PO of the **Company Registry** defines a specific rule for the billing application.

### **User Profiles**

Finally, we have **User Profiles**. Here, users themselves, the owners of the **Business Capabilities**, or sysadmins have the ability to assign rules directly, often through self-service interfaces or specific configuration tools. This allows for dynamic management and the assignment of permissions based on role or individual needs, ensuring each person can access only what they truly need to operate.

- **Examples**:

  - An end-user assigns Timesheet reporting permissions to another user.
  - The PO of the **Company Registry** assigns the policy for the billing application to access data.
  - A platform administrator assigns the PO the management of profiling for the business capabilities they own.

---

The integration of these three levels of rules within the **Policy Manager** allows us to have an authorization system that is extremely powerful, flexible, and, above all, able to adapt to diverse security and business needs, from the platform level all the way down to the individual user.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Business capability: autonomous yet composable

![slide-19.png](assets/slide-19.png)

A capability like Billing, Deadline Management, or Customer Registry is designed to be combined with others or to even stand alone. This means we can build a capability once, in the right way, and then reuse, adapt, and recombine it into different offerings, without duplicating effort or creating rigid solutions.

This approach allows us to adapt to markets, reduce duplication, and accelerate delivery. It is the heart of the flexibility and scalability we want to achieve with **OnePlatform**.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## OnePlatform sounds live

![slide-20.png](assets/slide-20.png)

But what if we think about the Spotify of the future? A platform where you can not only choose the tracks but also modify them, mix them, and make them interact with each other.

Imagine being able to say: I want this song, but with the voice of another artist and the beat of a third. Or: Adapt the music to my mood, my location, or the time of day.

This is exactly what **OnePlatform** does:

- It lets us build **Business Capabilities** that don't live in isolation, but can collaborate, exchange data, and react to events.
- It enables the personalization of the business experience by adapting capabilities to different contexts, without rewriting them every time.
- It's the platform that orchestrates not only the playlist, but also the interaction between the tracks and the listening experience itself.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## When software is really a Business Capability?

![slide-21.png](assets/slide-21.png)

To truly be one, a capability must:

- Be **autonomous**: It must have a clear set of business functions and not depend on external logic to exist.
- Be **activatable and measurable**: It must be able to be sold or activated independently and be traceable.
- Be **interoperable**: It must be able to communicate with other capabilities.
- Be **reusable**: It should be able to be applied in different offerings and contexts without re-engineering.
- And it must be **governed**: with security, observability, and clear responsibilities.

These are the criteria that guide us in designing true **Business Capabilities**, and not just technical modules or features.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Data Ownership and Data Sharing

![slide-22.png](assets/slide-22.png)

---

### **The Guiding Principles**

- **Single Source of Truth**: There's a central core of fundamental data that represents the shared source of truth. This means that for every crucial, shared entity, only one **Business Capability** holds ownership and is the sole authorized point for management and publishing. This prevents redundancies, inconsistencies, and data quality issues.
- **Explicit Responsibility**: In line with the **Single Source of Truth** principle, every capability has an explicit responsibility. Capabilities that hold data ownership are not limited to just managing it; they are actively responsible for ensuring its quality, integrity, and constant updating. This clear assignment of responsibility is essential for building trust in the data.
- **Distributed Coherence, Not Central Dependency**: To create a modular and scalable ecosystem, data consistency shouldn't depend exclusively on synchronous operations or a single central point of control that could become a bottleneck. Instead, it relies on a robust distributed alignment model. This allows capabilities to be operationally independent while still maintaining data coherence through asynchronous communication and synchronization mechanisms. This is our approach to being interoperable: allowing capabilities to communicate and collaborate effectively.

---

In summary, our **Data Ownership** and **Data Sharing** model allows us to build a platform where **Business Capabilities** are autonomous and powerful, yet at the same time, they collaborate in a coherent and secure way based on reliable and well-governed data.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Distributed Master Data Model

![slide-23.png](assets/slide-23.png)

The basic model to be inspired by is **CQRS** (Command Query Responsibility Segregation) and **asynchronous synchronization**—key elements for ensuring performance, scalability, and resilience. The central idea is that every **Business Capability** can have a local projection of master data.

---

### **Key Advantages**

- **Performance**: It's not necessary to make synchronous calls to the central master data service for every read operation, which reduces latency and improves responsiveness.
- **Local Availability**: A capability can continue to function even in case of a temporary fault in the central master data service, increasing the system's overall robustness.
- **Decoupling**: **Business Capabilities** remain autonomous, scalable, and independent, which reduces interdependencies and facilitates development and deployment.

---

### **Logical Structure of the Model**

- **Central Master Data (SSOT - Single Source of Truth)**: This contains the master data that represents the business entity and is the only authorized source to receive write commands for this data. All modification events arrive here.
- **Business Capabilities (BC)**: **Business Capabilities** maintain local read models. These models are derived from the events (or modifications) emitted by the central master data service. For example, a "Sales" capability might have a read model of a customer with ID and Name, while a "Billing" capability might have ID and VAT number, locally extending the model with its own domain information.
- **Read → Local**: The rule is simple: every capability always reads master data from its own local projection. This guarantees maximum speed and resilience, avoiding direct dependencies on the central service for read operations.
- **Write → Only to the Owner**: No **Business Capability** can write directly to the common master data. If a capability needs to modify a core master data point, it sends specific commands to the owning master data service (the **SSOT**), which is the only entity tasked with performing the write and emitting the update events.
- **Own Data Only (Bounded Context)**: Finally, **Business Capabilities** only modify the functional data they have full ownership of, respecting the principle of bounded context. This means each capability is responsible only for the data and logic that fall within its specific domain.

---

This distributed master data model allows us to build an agile, performant, and resilient platform, where data is consistent even while being distributed and managed autonomously by the capabilities.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Distributed Master Data Model - Example

![slide-24.png](assets/slide-24.png)

---

### **The Central Hub: The Single Source of Truth**

At the core of our ecosystem is the **Employee Master Data** service. This is the central employee registry from HRS, which we will soon begin prototyping. It acts as the **Single Source of Truth** (**SSOT**) for all fundamental employee information.

This service, in turn, relies on two secondary **SSOTs** responsible for specific entities:

- The **Item Registry** is the SSOT for a person's personal information. The **Employee Master Data** service "writes" the relevant data to it.
- The **Connections** service is the SSOT for the employment contract. Here, the **Employee Master Data** service "writes" the details of the working relationship.

These three components—**Employee Master Data**, **Item Registry**, and **Connections**—work in concert to form the primary, authoritative source of all fundamental employee information. The **Employee Master Data** service then adds all supplementary details, such as the position in the organizational structure.

### **Data Distribution and Local Projections**

Now, let's see how this data is distributed and used by **Business Capabilities**. The **Employee Master Data** service emits update events, which are distributed via **Hermes**, our Event Bus.

These events allow **Business Capabilities** to create and maintain their own local, read-only projections of the data, optimized for their specific needs.

For example, a **Timesheet** capability receives only the essential employee details and adds its own local data, such as hours worked or specific projects. It doesn't need all the contractual or personal information, just what it needs for its specific function.

Like **Timesheet**, other capabilities could intercept the same events to build local models suited to their own needs.

### **The Write Flow**

Regarding data writing, the diagram shows that the **Timesheet** capability does not need to issue write requests to the **Employee Master Data** service. Instead, data originates either from the **Employee Master Data** UI itself or from external HR or management systems. This data is acquired and normalized through the **Integration Hub**, ensuring that the information is clean and compliant before being entered.

---

This model clearly demonstrates how we maintain a centralized, authoritative registry for data writing and governance while allowing each **Business Capability** to have a local, high-performance, and isolated view of the data it needs, enabling autonomy and scalability.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Distributed Master Data Model - UI/UX challange

![slide-25.png](assets/slide-25.png)

Our goal is to give the end-user the ability to view and manage data on a single screen, even though it comes from different capabilities. This requires specific considerations in UI/UX design.

### **The Aggregated View**

The user must be able to view the core master data, which comes from the **Customer Service** (our **Single Source of Truth**), in an aggregated way. At the same time, they need to see specialized functional data, which is managed by specific capabilities like Sales, Billing, or Support. This means the user interface must be designed to dynamically compose an aggregated view that draws from multiple data origins, making the underlying complexity transparent to the user.

### **Modular View Management**

For managing this modular view, we have several approaches.

The UI can be structured in distinct blocks, each representing a specific **Business Capability**. For example, a 'Client' card could include tabs like 'Master Data,' 'Commercial,' 'Billing,' and 'Support.' Each tab would be managed by the capability that owns that specific data set.

Alternatively, we can opt for a single form with clearly separated sections, which still provides a clear visual distinction between the different data domains.

### **Integrated Modification Management**

Integrated modification management presents unique challenges. The editable fields must be separated by ownership. For example, core master data can only be modified by sending a command to the **Customer Service** SSOT. Other fields, however, will be sent locally to their respective owning **Business Capability**.

If a user wants to modify data distributed across different capabilities, we need clear mechanisms and a deliberate strategy to handle **eventual consistency**, as opposed to the "save all" approach of monolithic transactions.

---

In short, the goal is to mask the complexity of the distributed model from the end-user, ensuring a fluid and intuitive experience while respecting the principles of data ownership and integrity.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## The Integration layer as an enabler of dialogue between BCs

![slide-26.png](assets/slide-26.png)

---

### Flexible & Standardized Integration

We support a wide range of integration models, including both synchronous mechanisms, like direct API integration for real-time interactions, and asynchronous models, such as the use of messages, files, and events. We use common, standardized tools specifically adapted to meet different needs for coupling (how tightly capabilities are linked), performance (the speed and responsiveness of interactions), and data consistency across various systems. This flexibility allows us to choose the most suitable integration model for each specific scenario.

### Centralized Governance

While offering flexibility in models, we maintain centralized governance over all integrations. This means every integration, without exception, must pass through the platform's **Integration** component. This strategic choice ensures unified control, visibility into data flows, compliance with security policies, and the ability to efficiently monitor and manage the entire integration ecosystem. In this way, we avoid creating integration silos or ungoverned "point-to-point" interactions.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## The Integration layer as an enabler of dialogue between BCs - support to different integration

![slide-27.png](assets/slide-27.png)

---

### API Gateway

The first component is the **API Gateway**. This component manages direct calls between **Business Capabilities** and primarily supports synchronous messages. It is the ideal solution when one capability needs an immediate response from another. Given the synchronous nature of these interactions, it is essential that the calling capability is equipped with robust resilience mechanisms, such as **retry** (to re-attempt failed calls), **fallback** (to provide alternative responses in case of failure), and **circuit breaker** (to prevent overloading services that are already struggling). The **API Gateway** acts as a centralized entry and control point for these direct interactions.

### Integration Hub

The second component is the **Integration Hub**. This hub is designed for the exchange of asynchronous commands and data flows. It is the reference point for point-to-point interactions between two services when an immediate response is not required or when more complex integrations and data exchange need to be managed. A significant advantage of the **Integration Hub** is its ability to also support integration with on-premise systems, serving as a bridge between our cloud environment and pre-existing infrastructures.

### Hermes

Finally, we have **Hermes**, our **event streaming** system. **Hermes** enables a completely **event-driven** integration model. Here, **Business Capabilities** don't call each other directly for every piece of information; instead, they share business events. One capability (the '**producer**') emits an event when something relevant happens (e.g., 'new order created'), and a set of other capabilities (the '**consumers**') can subscribe to these events to react autonomously. The producer has no idea which or how many consumers are listening, but the connected systems react to the business events. This model promotes high decoupling between services, improves scalability and resilience, and has an additional strategic advantage: it directly feeds our datalake, creating a continuous flow of data for analytics and artificial intelligence.

---

These three components—**API Gateway**, **Integration Hub**, and **Hermes**—work in synergy to provide a complete suite of integration tools, allowing us to choose the most suitable model for every need.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Disassemble and reassemble to create value — not only software

![slide-28.png](assets/slide-28.png)

Just as a musical track can be broken down into its basic elements—drums, bass, vocals—and then recomposed into new versions for new audiences, new experiences, and new contexts. We are not creating different music. We are making each part simpler, more universal, more reusable.

But to do this, we must step outside the narrow view of our product and learn to see the capabilities from the outside.

This is the real shift: to think like architects of value, not just developers of functions.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## Pattern to support trasformation

![slide-29.png](assets/slide-29.png)

### **Domain-Driven Design (DDD)**

The first and most fundamental approach is **Domain-Driven Design (DDD)**. **DDD** guides us to collaborate closely with business domain experts. The goal is to identify the **Bounded Contexts** within the monolith. A **Bounded Context** is a specific area where a domain has internal coherence and a complete meaning, using a common, shared language known as the **Ubiquitous Language**. Once these contexts are identified, **DDD** helps us represent the relationships between these domains through a **Context Map**, providing us with a clear roadmap for deconstruction.

### **The Strangler Fig Pattern**

Furthermore, to take an incremental and safe approach to the transformation, we often use the **Strangler Fig Pattern**. This pattern is particularly effective for complex migrations. In practice, new **Bounded Contexts** (which will become our **Business Capabilities**) are developed and progressively replace portions of the monolith. This is done via routing mechanisms that gradually reroute traffic from the old monolith to the new capabilities, minimizing risk and allowing the rollout to be spread over time. It's like a strangler fig that grows around a host tree, slowly absorbing it.

### **Supporting Techniques for Gradual Release**

There are also other techniques that support the transition and gradual release of new functionalities to customers:

- **Feature Flags** allow you to enable or disable features in production with a simple switch, controlling who sees what.
- **Canary Releases** involve releasing a new version to a small subset of users before extending it to everyone, in order to monitor its behavior.
- **Blue/Green Deployment** is where a stable version ('blue') is maintained while a new version ('green') is released to a separate environment, allowing traffic to be switched instantaneously once stability is verified.

---

All of these patterns and techniques provide us with a robust toolkit for tackling the transformation of our application ecosystem toward a more agile, scalable, and **Business Capability**-based architecture.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## An example: FiC use case

![slide-30.png](assets/slide-30.png)

---

Here, we see how some of the patterns we just described were applied to decompose an existing product into capabilities. On the left, you can see the representation of the initial monolith. This monolith included several key functionalities like **'tradeitems'** (commercial articles), **'invoicing'** (invoicing/billing), **'warehouse'** (warehouse), and **'csl'** (customer supplier list).

We applied the **Bounded Context** principle to divide this complex domain into more coherent and autonomous contexts. Each context was identified as a logically independent part of the business, and each was transformed into an independent functionality or capability. The goal was to achieve a clear separation of responsibilities.

Next, to manage the transition in a safe and gradual way, we used the **Strangler Fig Pattern**. As you can see from the diagram, the new capabilities—represented by the colored blocks on the right (**Tradeitems**, **Warehouse**, **Pricelist**, etc.)—progressively took the place of the monolith's functionalities. The traffic, symbolized by the percentage icon, was safely rerouted, allowing us to migrate gradually without significant interruptions for users.

In combination with the **Strangler Fig Pattern**, we employed **Canary Releases**. Each new capability was not released to all users at once, but was progressively introduced to a small percentage of customers. This approach allowed us to test the new functionalities in a real environment with controlled risk, gather feedback, and facilitate any rollback operations in case of problems.

The result of this transformation process is an architecture composed of modular Capabilities that can now be integrated into other commercial offerings.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Summary)

---

## … and AI?

![slide-31.png](assets/slide-31.png)

---

### Datalake

Our datalake is the foundation for **AI**. As we've already mentioned, **Hermes**, with its business events, directly feeds the **data products** within the datalake. This creates a continuous and structured flow of operational data that is fundamental for training **AI** models. In this ecosystem, **AI** agents, when properly configured, can access these data products, leveraging a rich and constantly updated source of truth for their analyses and decisions.

### User Experience

Our **Business Capabilities** are designed to be **AI-ready** at the interface level as well. The capabilities have native access to the **AI** platform's conversational interfaces. This means a user can interact with a capability not only via a traditional graphical interface but also through a **chatbot** or a virtual assistant, directly supported by **AI**. The potential for interaction with **AI** is set to grow significantly over time, enriching the user experience and enabling new use case scenarios.

### Interaction via APIs

Finally, direct interaction between capabilities and **AI** engines primarily happens via **APIs**. Each **Business Capability** exposes its own **API**. But there's an important specificity: this **API** acts as a specific **Facade** for the technology of **AI** agents. This means the capability does not expose its full complexity directly to the **AI** engine but offers a simplified and optimized interface tailored to **AI** needs. This 'Facade' masks the capability's internal complexities, allowing **AI** agents to interact efficiently and in a targeted way.

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Sommario)

---

## Key takeaways

![slide-32.png](assets/slide-32.png)

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Sommario)

---

## THANK YOU

![slide-33.png](assets/slide-33.png)

[⬆️ Torna al sommario](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/647498120/20250910_1001_From+Product+to+Capability+-+Secure+Modular+and+Scalable+Design#Sommario)

---


## Attachments & figures

![Slide 01 — Titolo-20250911-150453.png](assets/Slide 01 — Titolo-20250911-150453.png)
<!-- transcribe: assets/Slide 01 — Titolo-20250911-150453.png -->

![809d6198-a0fc-4ccd-81be-c5b150c3112e.png](assets/809d6198-a0fc-4ccd-81be-c5b150c3112e.png)
<!-- transcribe: assets/809d6198-a0fc-4ccd-81be-c5b150c3112e.png -->
