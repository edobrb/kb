---
source_id: "confluence:confluence-mpdd-mpdd-1587216639-1-4-i-cicli-di-vita-commerciale-e-a-consumo"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1587216639/1.4+I+cicli+di+vita+commerciale+e+a+consumo"
title: "1.4 — I cicli di vita: commerciale e a consumo"
authority: descriptive
version_hash: "sha256:63c6372697d501b6733a47778c4125375084b691ae9693080241568911ad6c71"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1587216639-1-4-i-cicli-di-vita-commerciale-e-a-consumo.md", version_hash: "sha256:63c6372697d501b6733a47778c4125375084b691ae9693080241568911ad6c71"}
body_hash: sha256:3aece989bde507062c8ad78c55ebce481301be6219b77a9ab3ef05e30f42f461
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1587216639-1-4-i-cicli-di-vita-commerciale-e-a-consumo.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# 1.4 — The lifecycles: commercial and consumption

**The commercial lifecycle (governed by BBS / FIC Store)**

> **Key point**
>
> BBS (or FIC Store) is currently the owner of the commercial lifecycle. Metering is the technical executor.

|  |  |  |
| --- | --- | --- |
| Event | Who decides | What happens in Metering |
| Package sold | BBS / FIC Store | Receives expireDate, autoRenewal,  newYearRenewal |
| Automatic renewal | BBS / FIC Store | Renews the package; Metering does nothing autonomously |
| Expiry without renewal (immediate) | BBS / FIC Store → Metering | State → EXPIRED; sends  DISABLE\_SUBSCRIPTION to the BC |
| Expiry without renewal (soft) | BBS / FIC Store → Metering | State → READONLY; sends  ENABLE\_READONLY\_SUBSCRIPTION to the  BC |
| Constraint threshold reached | Metering (autonomously) | Sends ENABLE\_READONLY\_SUBSCRIPTION  to the BC |
| Constraint reset / upgrade | Metering (autonomously) | Sends DISABLE\_READONLY\_SUBSCRIPTION  to the BC |

**The consumption lifecycle (governed by Metering)**

When a feature has a **constraint**, the consumption cycle comes into play, managed by the **Smartmeter** component in M3. It is independent of the commercial cycle

**The two counting modes**

|  |  |  |  |
| --- | --- | --- | --- |
| Mode | How it works | When to use it | Examples |
| Synchronous  (Slot-based) | The BC asks BEFORE acting. Metering  locks a slot (LOCKED), the BC executes,  then confirms (USED) or cancels (FREE).  Slot → COOLDOWN → FREE after 6  months. | Small numbers, critical actions  that must NEVER  exceed the limit | Signature certificates,  user enablement,  company management |
| Asynchronous  (Queued) | The BC performs the action and AFTERWARDS notifies  Metering via message bus. Aggregated into  daily buckets. Does not block in  real-time. | Massive volumes, where immediate  blocking is not acceptable | Invoices issued, electronic  submissions, API calls,  documents |

**Synchronous flow (slot) in detail**

![05-consumo-sincrono-slot.png](assets/05-consumo-sincrono-slot.png)

**Asynchronous flow in detail**

![06-consumo-asincrono-bus.png](assets/06-consumo-asincrono-bus.png)

**What happens when the threshold is reached**

|  |  |  |  |
| --- | --- | --- | --- |
| Behaviour | What Metering does | Webhook to the BC | Package state |
| Block / Readonly | The user can no longer consume. The BC decides  whether a total block or read-only. | ENABLE\_READONLY\_SUBSC  RIPTION | READONLY\_C  ONSTRAINT\_LI  MIT\_REACHED |
| Overage  (over-threshold) | Consumption continues as overage,  billed at the end of the period by BBS. | No webhook — consumption  continues | ACTIVE  (unchanged) |

> **Important note**
>
> The ENABLE\_READONLY\_SUBSCRIPTION webhook is the same both when the threshold is reached and when BBS communicates a soft expiry. It is the BC that decides internally whether the user must see the data in read-only or be blocked completely.

**Exemptions**

In exceptional cases agreed commercially, Metering supports **exemptions**: derogations that allow a single client to exceed the limits of its own constraint for a defined period. Useful for seasonal peaks or enterprise clients.

**Flat features (without constraint)**

If the feature is on a fixed fee with no limits, the consumption cycle **does not apply**. Metering only manages

activation/deactivation. The ENABLE\_READONLY and DISABLE\_READONLY actions will never be

invoked, but they **must nevertheless be implemented** for correctness.

**The "base for everyone" model — The included offer (formerly C+)**

Some capabilities provide for a **base tier activated automatically** for all users of the platform, without an explicit act of purchase.

|  |  |
| --- | --- |
| Aspect | Detail |
| Who decides what goes into the base plan | GTM, in agreement with the PO. It is a commercial/strategic decision. |
| Volume of webhook calls | Adding a feature to the base Family means webhook calls for ALL active users/workspaces. If the base is large, the volumes can be significant. |
| Webhook ready first | The feature must have a working and tested webhook BEFORE being added — activation is triggered immediately across the whole base. |
| Downgrade from a higher tier to base | The extra features are deactivated via DISABLE\_SUBSCRIPTION, but the  base features remain active. |
| Features shared between base and higher  tiers | Metering deactivates the feature only if no active package keeps it switched on (multi-licence rule). |
