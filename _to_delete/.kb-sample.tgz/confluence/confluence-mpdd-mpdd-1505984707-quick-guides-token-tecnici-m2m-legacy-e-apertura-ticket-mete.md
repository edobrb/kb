---
source_id: "confluence:confluence-mpdd-mpdd-1505984707-quick-guides-token-tecnici-m2m-legacy-e-apertura-ticket-mete"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1505984707/Quick+Guides+Token+tecnici+M2M+legacy+e+apertura+ticket+Metering"
title: Quick Guides – Token tecnici M2M legacy e apertura ticket Metering
authority: descriptive
version_hash: "sha256:a5b934ec84b56cfb15ef021ac0d0a0d28cef6159cb48c19c8e3bc109ec3693c2"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1505984707-quick-guides-token-tecnici-m2m-legacy-e-apertura-ticket-mete.md", version_hash: "sha256:a5b934ec84b56cfb15ef021ac0d0a0d28cef6159cb48c19c8e3bc109ec3693c2"}
body_hash: sha256:9c95f3ed9b27d9ce0786d82def1852cbc09d58a27d2a07541fee756bc9e067a8
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1505984707-quick-guides-token-tecnici-m2m-legacy-e-apertura-ticket-mete.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# Quick Guides – Legacy M2M technical tokens and opening Metering tickets

# **Purpose of the guide**

This guide collects in a single document the instructions to:

- request a **legacy M2M technical token** in **Digital Mode**, therefore **without using client credentials**
- correctly open a **support ticket to the Metering team**

The technical token flow must be used in the cases where the application **does not yet support the client credential mechanism** and it is necessary to obtain a technical token to invoke APIs related to the **Monetization / Metering** domain.

---

# **When to use this guide**

This guide is to be used in two distinct cases:

## **1. Legacy M2M technical token request**

When a token is needed to:

- send consumption internally
- call remote enable / disable webhooks
- make calls between microservices

## **2. Opening a ticket to Metering**

When it is necessary to open an operational or functional support request to the Metering team.

---

# **Flow A – Legacy M2M technical token request**

**3.1 When to request a technical token**

As a rule, a technical token is requested in the following scenarios:

- **Sending consumption internally**
- **Calls to remote webhooks** for enable / disable feature
- **Calls between microservices**

This flow is to be used **only in legacy cases**, that is, when **it is not possible to use client credentials**.

---

**3.2 Portal access**

To open the request use the following link:

👉 <https://teamsystem.atlassian.net/servicedesk/customer/portal/6/group/38/create/231>

Alternatively, from the portal:

- go to **Service Desk 1P Technical Support**
- select **One Platform Technical Services**
- select **M2M Credential Issuance - Technical Token**

The form to be filled in will open.

---

**3.3 General rules**

- The token is **environment-specific**
- The possible environments are:

  - **DEV**
  - **TEST**
  - **PROD**

**Warning**

If the request concerns more than one environment, it is necessary to open **a separate ticket for each environment**.

All fields marked as **required** are mandatory.

---

**3.4 Filling in the form – common fields**

Below are the general indications on the form fields.

**Summary**

Enter a short and concise description of the request.  
This field represents the **ticket title**.

Examples:

- `Legacy M2M token request for integration with the Metering API`
- `Token for calls to the webhook of service X - TEST`
- `Token for internal use between m3 microservices - TEST`

**Environment**

Specify the environment for which the token is to be created:

- DEV
- TEST
- PROD

**Capability / Service**

Select:

- **Monetization**
- **Metering**

or, depending on the form:

- **Monetization - Metering**

**Have you considered alternative authorization methods before requesting this token?**

Select one of the following options according to the case:

- **Sì, l’applicativo non supporta client credential**
- or, for internal cases between microservices:
- **Yes, we need this type of m2m token only for internal use**

**Detailed description / Description of the activity**

Clearly describe for which activity the token is needed.

Examples:

- `Token needed to call the config of a feature`
- `Token needed to send consumption to the m3-consumption-producer service`
- `Internal use between our microservices - generate a consumption event on m3`

**Which services or resources will be accessed using this token?**

Indicate the name of the target API or service.

The value must be consistent with the service actually exposed by the owning team.

Examples:

- `m3-consumptions-producer (v2)`
- name of the webhook API
- name of the microservice called

**Have you discussed this request with the product owners of the target services?**

Select:

- `yes`

**Have you assessed the potential impacts on data access and security?**

Select:

- `yes`

**Platform engineer / contact who validated the integration**

Indicate:

- **Alessandro Mulé**
- [**a.mule@teamsystem.com**](mailto:a.mule@teamsystem.com)

**What permissions are required?**

Indicate the **claims required on the token**.

**Warning:** claims **must not be invented**. They must always be provided or confirmed by the **owner of the API**.

**Service identifier where the token will be installed**

Indicate the name of the technical service that will use the token to invoke the API.

**Technical Contact**

Indicate:

- **Alessandro Mulé**
- or the **reference developer** who will follow the activity

**Functional Contact**

Indicate:

- **Giorgio Ratti**
- or the **reference Product Owner**

---

## **Case 1 – Sending consumption internally**

**Objective**

M2M token request for internal use on m3, aimed at generating consumption events.

**Recommended filling in**

**Summary**

`Token for internal use between m3 microservices - TEST`

**Environment**

- DEV / TEST / PROD

**Capability / Service**

- Monetization
- Metering

**Have you considered alternative authorization methods before requesting this token?**

`Yes, we need this type of m2m token only for internal use`

**Detailed description**

`Internal use between our microservices - generate a consumption event on m3`

**Which services or resources will be accessed using this token?**

`m3-consumptions-producer (v2)`

**Have you discussed this request with the product owners of the target services?**

`yes`

**Have you assessed the potential impacts on data access and security?**

`yes`

**Platform engineer**

`Alessandro Mule'`

**What permissions are required?**

Enter the required claims, for example:

- `M3-CONSUMPTIONS-PRODUCER:WRITE`
- `M3-CONSUMPTIONS-PRODUCER:TSDOC-SRV`  
  that is: `M3-CONSUMPTIONS-PRODUCER:<NOME_SERVIZIO>`

**Service identifier where the token will be installed**

Enter the technical service that will use the token, for example:

- `M3-CONSUMPTIONS-PRODUCER:TSDOC-SRV`  
  that is: `M3-CONSUMPTIONS-PRODUCER:<NOME_SERVIZIO>`

**Technical Contact**

`Alessandro Mule'`  
or the developer who will follow the task

**Functional Contact**

`Giorgio Ratti`

---

## **Case 2 – Calls to remote enable/disable webhooks**

**Objective**

Token request to invoke remote webhooks for enabling or disabling a feature.

**Recommended filling in**

**Summary**

`Token for calls to the webhook of service X - TEST`

**Environment**

- DEV / TEST / PROD

**Capability / Service**

- Monetization
- Metering

**Have you considered alternative authorization methods before requesting this token?**

`Sì, l’applicativo non supporta client credential`

**Detailed description**

Describe the activity, for example:

- `Token needed to call the config of a feature`

**Which services or resources will be accessed using this token?**

Enter the **name of the API to be accessed**

**Have you discussed this request with the product owners of the target services?**

`yes`

**Have you assessed the potential impacts on data access and security?**

`yes`

**Platform engineer**

`Alessandro Mule'`

**What permissions are required?**

Indicate the claims required by the owner of the API.

In the webhook case, use:

**Service identifier where the token will be installed**

Indicate the technical service that will use the token.

In the webhook case, enter:

- `ts-services-subscription-webhook-invoker`

**Technical Contact**

`Alessandro Mule'`  
or the developer who will follow the task

**Functional Contact**

`Giorgio Ratti`

**Practical example**

- **Activity:** Token needed to call the config of a feature
- **Claim:** `<nome_feature>:enableDisable`
- **Technical service:** `ts-services-subscription-webhook-invoker`

---

## **Case 3 – Calls between microservices**

**Objective**

M2M token request for communication between microservices.

**Recommended filling in**

**Summary**

`Token for calls between microservices of service X - TEST`

**Environment**

- DEV / TEST / PROD

**Capability / Service**

- Monetization
- Metering

**Have you considered alternative authorization methods before requesting this token?**

`Yes, we need this type of m2m token only for internal use`

**Detailed description**

`Internal use between our microservices`

**Which services or resources will be accessed using this token?**

Enter the **name of the service called**

**Have you discussed this request with the product owners of the target services?**

`yes`

**Have you assessed the potential impacts on data access and security?**

`yes`

**Platform engineer**

`Alessandro Mule'`

**What permissions are required?**

Indicate the claims required to access the API.

**They must be indicated by the owner of the API.**

**Service identifier where the token will be installed**

Indicate the name of the microservice that needs to authenticate to the API.

**Technical Contact**

`Alessandro Mule'`  
or the developer who will follow the task

**Functional Contact**

`Giorgio Ratti`

---

**Quick summary of the main fields**

| **Field** | **Value / indication** |
| --- | --- |
| Capability / Service | Monetization - Metering |
| Environment | DEV / TEST / PROD |
| Alternative authorization methods | If legacy: “Sì, l’applicativo non supporta client credential” |
| Activity description | Clearly describe the purpose of the token |
| Target API / service | Name of the API or service called |
| Target PO validation | yes |
| Security impact evaluation | yes |
| Platform engineer | Alessandro Mulé – [a.mule@teamsystem.com](mailto:a.mule@teamsystem.com) |
| Permissions / claim | Provided by the API owner |
| Service identifier | Name of the technical service that uses the token |
| Technical Contact | Alessandro Mulé or reference developer |
| Functional Contact | Giorgio Ratti or reference PO |

---

**Important notes**

- This flow is to be used **only for legacy cases**
- If available, the preferable mechanism remains **client credentials**
- **Claims must not be invented**
- Claims must always be **confirmed by the team that owns the API**
- The description of the activity must be **clear and complete**, so as to speed up the taking in charge
- If tokens are needed on more than one environment, **separate tickets** must be opened

---

# **Flow B – Opening a ticket to the Metering team**

**4.1 Objective**

This procedure describes how to correctly open a support ticket to the **Metering** team through the support portal.

---

**4.2 Portal access**

To open the ticket use the following link:

👉 <https://teamsystem.atlassian.net/servicedesk/customer/portal/6/group/1537/create/2459>

![image-20260417-074413.png](assets/image-20260417-074413.png)

---

## **Filling in the ticket**

**Summary**

Enter a short and concise description of the request.

The field must represent the **ticket title**.

**Description**

Describe the object of the request in a detailed and complete way.

It is mandatory to specify the **environment** on which the Metering team will have to act:

- DEV
- TEST
- PROD

**Capability / Service**

In the Capability/Service field select:

- **Monetization**
- **Metering**

**Attachments**

Optional, but recommended if useful.

Examples:

- screenshots
- documentation
- technical evidence
- payload
- logs or details useful for the diagnosis

**Submission**

Before submitting:

- verify the completeness of the information
- check that the environment is clearly indicated
- attach any useful evidence

Then click on **Submit**.

---

> ⚠️ **Important note**  
> If the request concerns **more than one environment**, it is necessary to open **a separate ticket for each environment**.

---
