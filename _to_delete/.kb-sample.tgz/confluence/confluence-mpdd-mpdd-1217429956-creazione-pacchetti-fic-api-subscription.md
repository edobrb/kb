---
source_id: "confluence:confluence-mpdd-mpdd-1217429956-creazione-pacchetti-fic-api-subscription"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1217429956/Creazione+pacchetti+FIC+API+Subscription"
title: Creazione pacchetti FIC – API Subscription
authority: descriptive
version_hash: "sha256:4bb42d2759b1bb4b33e9206dd086f7f76b58dab2b475294277daf280becc8c86"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/confluence/MPDD/mpdd-1217429956-creazione-pacchetti-fic-api-subscription.md", version_hash: "sha256:4bb42d2759b1bb4b33e9206dd086f7f76b58dab2b475294277daf280becc8c86"}
body_hash: sha256:e90f315edae7cf777ada14c98c10caf3ec2f10a0c146aa1e0d42aab44306ee30
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1217429956-creazione-pacchetti-fic-api-subscription.md
taxonomy_origins: "authority=convention_default, lang=document, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---

# FIC package creation – Subscription API

**FIC** packages can be created through two different APIs, depending on the activation perimeter:

- **Subscription V2** (uses ItemID)

  <https://agyo-subscription-api-test.agyo.io/swagger-ui.html#/Subscription%20V2/subscribeUsingPOST_1>
- **Subscription V3** (uses WSID)

  <https://agyo-subscription-api-test.agyo.io/swagger-ui.html#/Subscription%20V3/subscribeUsingPOST_2>

> V2 is to be used when the activation is on **ItemID**, V3 when it is on **WorkspaceID**.

## **⚠️ Important note on the name field**

Both when using **V2** and when using **V3**, in the request body the name field must be populated **without an underscore (“\_”)**, even if the family provides for one.

### **Example – FIC\_COMPLETE**

{  
 "application": "metering",  
 "family": "FIC\_COMPLETE",  
 "itemId": "678e7ab9-35fc-49b8-be72-2fa79ad95c11",  
 "name": "FICCOMPLETE",  
 "ownerId": "678e7ab9-35fc-49b8-be72-2fa79ad95c11",  
 "quantity": 0  
}

## **Mapping Family → Name**

Below is the correct value assignment for the FIC packages currently present:

| **Family** | **Name** |
| --- | --- |
| FIC\_STANDARD | FICSTANDARD |
| FIC\_PREMIUM | FICPREMIUM |
| FIC\_PREMIUM\_PLUS | FICPREMIUMPLUS |
| FIC\_COMPLETE | FICCOMPLETE |

### **Operational summary**

- The family keeps the underscore (e.g. FIC\_PREMIUM\_PLUS)
- The name must always be populated without an underscore (e.g. FICPREMIUMPLUS)
- The choice between V2 and V3 depends on the activation level (Item vs Workspace)
