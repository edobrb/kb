---
source_id: "confluence:confluence-mpdd-mpdd-1590755364-5-2-raci-chi-fa-cosa"
source_type: confluence
unit_kind: documentation
source_url: "https://teamsystem.atlassian.net/wiki/spaces/MPDD/pages/1590755364/5.2+-+RACI+-+Chi+Fa+Cosa"
title: 5.2 - RACI - Chi Fa Cosa
authority: descriptive
version_hash: "sha256:e253ea4695d9f160d96c758d24a9cea1e4b546ac71c4915da7b49faf8e65d3a0"
admission: refused
admission_rule: insufficient_content
admission_reason: "carries 0 characters of content after the frontmatter, below the declared 32-character floor — the page exists but no knowledge was written into it"
admission_model: rule:screen-admission@1
admission_at: 2026-07-29T22:11:01Z
body_hash: "sha256:1bc5f3a2f75379c15c0ed1595ece3f6530802e00382e957d291baf74a0f92147"
lang: und
source_langs: [und]
fetched_at: "2026-07-23"
ingested_from: obsidian-web-clipper
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/confluence/MPDD/mpdd-1590755364-5-2-raci-chi-fa-cosa.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=document, source_url=document, title=document, unit_kind=producer_admission"
---
# 5.2 - RACI - Chi Fa Cosa
