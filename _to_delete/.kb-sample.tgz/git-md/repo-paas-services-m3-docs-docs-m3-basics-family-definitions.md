---
source_id: "git-md:repo-paas-services-m3-docs-docs-m3-basics-family-definitions"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/paas/services/m3/docs/-/blob/1a1607cdd8d49c974e61c819cb0e4f2cb8a838ce/docs/m3/basics/family-definitions.md"
title: Family Definitions (Legacy)
authority: descriptive
version_hash: "sha256:a2855efb06d0122fa674f9bb0ab14a61e5400a334ce333f7a35f49b47291d7c6"
body_hash: "sha256:a2855efb06d0122fa674f9bb0ab14a61e5400a334ce333f7a35f49b47291d7c6"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:paas/services/m3/docs"
index_status: pending
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/paas/services/m3/docs/docs/m3/basics/family-definitions.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Family Definitions (Legacy)

When we talk about **Family** definitions, we are referring to the legacy M1 concept that corresponds to the **Tier** of a **Commercial Offer** in M3. In the legacy M1 ecosystem, a Family permits BBS and Metering to integrate. A Family identifies the technical definition of a Commercial Offer. It is used to list the Features that are part of the offer and define its Constraints and Thresholds.

It is important to note that the Family information is not strictly necessary for M3's Business Capabilities and Features to work, but it is maintained for backward compatibility. For example, legacy Consumptions flow use the Family information to identify the Subscription to which the Consumptions must be assigned.
In the future, we will completely phase out the concept of Families in favor of a more flexible approach where the Subscription self-describes its Features and Constraint configurations. This will allow for greater flexibility and easier integration with the store and the billing system.

One of the main problems with using the legacy Family model is the proliferation of units when introducing complex Commercial Offers with multiple Feature configurations. For example, if we have a Commercial Offer with 3 Features and each Feature has 3 different configurations (e.g., extra-data), we would have to manage 27 different Families. This is not sustainable in the long term and is one of the core technical debts M3's Tier approach resolves.

Another severe technical limitation of the legacy M1 model is the maximum number of Constraints that can be introduced for a Family. Currently, M1 can manage a maximum of 3 Constraints per Family. This is a critical blocker when dealing with complex Commercial Offers involving multiple Features.

This section is primarily relevant for understanding the legacy context and the structural problems M3 is actively solving with the introduction of Tiers. The definition of a legacy Family remains a task for Product Owners and the commercial team. You can find more information about Family definitions in the [Full Integration Guide](https://teamsystem.atlassian.net/wiki/spaces/TeamMeteri/pages/1388511375/Integrazione+con+il+Metering+-+Guida+completa).
