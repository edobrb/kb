---
source_id: "git-md:repo-oneplatform-tsdataplatform-data-governance-ts-dataplatform-datagovernance-documentation-docs-resource-witboost-witboost-governance"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/-/blob/256aaa023d7a1968e3a84c8985dae5a7c2db39ff/docs/resource/witboost/witboost-governance.md"
title: Governance and Policies
authority: descriptive
version_hash: "sha256:1b7da30d28ada958c604094e6bee3a00bc493c9c82a67a60cb48059d48b6fe1c"
body_hash: "sha256:03c4d517639efe40ed7939a45fcdc9d6369d3830bf66a3732e219c23bfd1e198"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/docs/resource/witboost/witboost-governance.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Governance and Policies

This page describes how governance and policy enforcement work in Witboost, ensuring compliance, data quality, and secure access throughout the data product lifecycle.

## Policy Overview

Policies ensure compliance and coherence across all data products (DPs) on the platform.

- **For Policy Developers:** Policies can be tested on all DPs before release.
- **For Data Product Developers:** Policies can be tested before release, and a mandatory check is performed before deployment.

## Types of Policies

- **Active Policies:**  
  Written in CUE, these are manually executed during test and pre-release stages to validate metadata and configurations.
- **Passive (Computational) Policies:**  
  Executed on a schedule via an associated microservice. Useful for data quality checks, integration with external services, or other custom validations.

Passive Policies are often defined as a Data Contract: a set of controls and quality checks that DP developers implement to ensure compliance and deliver reliable, up-to-date data. DP metrics are managed in a similar way.

## Policy Enforcement and Feedback

- If a policy is broken, you can click on the error message in Witboost to analyze the CUE output:  
  ![Policy Error Example](./images/witboost-governance-policy-example.png)
- Types of Policies: 
    - **Error Policies:** Prevent deployment of the data product.
    - **Warning Policies:** Allow deployment, but consumers will see a warning in the marketplace:  
    ![Policy Warning Example](./images/witboost-governance-policy-example2.png)

## Data Access Requests

NOTE: At the moment, granting access to the data DOES NOT grant access to a Databricks Workspace. 
To read the granted Tables, you have the following options:

- If you are a Consumer: ask the Domain Owner to grant you access to their Workspace.
- If you are a Developer: ask the Domain Owner to assign the Domain Catalog to your Workspace.

To request access to a data product, go to the marketplace and shop for an output port:  
![Access Flow](./images/witboost-governance-access-flow.png)

- The owner receives a notification and can approve or deny the request.
- If approved, you gain access to the data.
- The owner can revoke access at any time from the same page  
  ![Revoke Access](./images/witboost-governance-access-flow2.png)

## Azure Entra ID Integration
- Azure Entra ID groups must be synchronized in Witboost. To enable this, ensure “witboost” is included in the Azure Entra Group description.  
- Users can request data access only on behalf of groups they belong to.
