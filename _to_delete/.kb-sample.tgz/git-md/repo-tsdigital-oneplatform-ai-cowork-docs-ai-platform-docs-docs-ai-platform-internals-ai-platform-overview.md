---
source_id: "git-md:repo-tsdigital-oneplatform-ai-cowork-docs-ai-platform-docs-docs-ai-platform-internals-ai-platform-overview"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/-/blob/6c617371f851e6ffa24e0fe0c27751375233fdb5/docs/ai-platform-internals/ai-platform/overview.md"
title: Observability for GenAI
authority: descriptive
version_hash: "sha256:c13c81bc44d42f50abed2682c2cbd1991e32bc9db45ad87b7553569cc40a717b"
body_hash: "sha256:866691a6b508a72a646df1e9f0bc38fe4120b583c101d390638cff71f506efa9"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/docs/ai-platform-internals/ai-platform/overview.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=document, unit_kind=producer_admission"
---
# Observability

MLflow (hosted on Databricks) is our platform of choice for GenAI observability.
To enable advanced analysis, MLflow traces are stored in dedicated tables within Databricks Unity Catalog (UC).

![Databricks Trace](../../assets/observability/databricks-trace.png)

!!! warning "Request access to Databricks"

    To request access to Databricks, please contact a member of the GenAI Platform team.
    If you don't have access, please contact a member of the team:

    - **Carlo Piccinin** — [Teams](https://teams.microsoft.com/l/chat/0/0?users=c.piccinin@teamsystem.com) · [email](mailto:c.piccinin@teamsystem.com)
    - **Luca Baggi** — [Teams](https://teams.microsoft.com/l/chat/0/0?users=l.baggi@teamsystem.com) · [email](mailto:l.baggi@teamsystem.com)
    - **Adriana Farina** — [Teams](https://teams.microsoft.com/l/chat/0/0?users=a.farina01@teamsystem.com) · [email](mailto:a.farina01@teamsystem.com)

    If none of the above are available, reach out to **Marco Santoni** — [Teams](https://teams.microsoft.com/l/chat/0/0?users=m.santoni@teamsystem.com) · [email](mailto:m.santoni@teamsystem.com).

    You will provide the GenAI platform team member with the name of a **Microsoft Entra ID Group** to enable access to the resources on the Databricks workspace.

Interactions with GenAI systems can be logged to MLflow in three ways:

- **Platform-level observability**
    All interactions that pass through the AI Gateway (LiteLLM) are automatically logged to a centralized MLflow experiment and stored in Unity Catalog tables. This process is fully managed by the GenAI Platform team. See [LiteLLM Gateway Observability](./tracing-litellm-gateway.md).

- **TS AI observability**
    All interactions that go through TS AI and its orchestrator are logged to a separate centralized MLflow experiment and stored in Unity Catalog tables. While the GenAI Platform team manages the experiments and tables, developers of MCP clients must instrument their servers to send traces to the centralized MLflow experiment. See [Tracing MCP Servers](../../genai-platform/tracing-mcp-servers.md).

- **Application-level observability**
    GenAI applications that are not integrated with TS AI or its orchestrator are expected to create and manage their own MLflow experiments and Unity Catalog tables for collecting product analytics. See [Standalone GenAI Applications](#standalone-genai-applications) below.

!!! tip "In short"

    If you are a member of the AI Adoption team, or a business unit, and you want to publish a new MCP server or Gen AI Application, refer to [Tracing MCP Servers](../../genai-platform/tracing-mcp-servers.md).

## Why Application-Level Observability?

The platform-level observability is effective in gathering general statistics, controlling model use, costs, and errors.

However, collecting and analyzing MLflow traces gives product teams valuable insights, including:

- The inputs and outputs of each interaction between users and the AI
- The number of tokens used
- The latency of each LLM generation

With this data, teams can optimize their use cases and focus on the features that resonate most with users.

## Standalone GenAI Applications

This section covers how to instrument a GenAI application that does **not** connect with TS AI and its orchestrator. If you are building an MCP server, please refer instead to [Tracing MCP Servers](../../genai-platform/tracing-mcp-servers.md).

### Creating an MLflow experiment

You need an MLflow experiment entirely managed by your team; the central GenAI Platform team will not have ownership over it.

Follow [Setting Up MLflow on Databricks](./mlflow-on-databricks.md) to get it up and running.

### Instrumenting your application

Once you have the MLflow experiment and the Databricks UC tables up and running, follow the [official MLflow tracing guide](https://mlflow.org/docs/latest/genai/tracing/) to instrument your application.

MLflow is intended to be a complement — not a replacement — for standard technical Grafana instrumentation:

- **MLflow** gives you a better view of interactions with GenAI models.
- **Grafana** provides visibility on all user interactions, both inside and outside GenAI features.

If your application calls other services, distributed tracing in MLflow requires specific configuration. See:

- [The MCP instrumentation guide](../../genai-platform/tracing-mcp-servers.md)
- [The official MLflow distributed tracing guide](https://mlflow.org/docs/latest/genai/tracing/app-instrumentation/distributed-tracing/)
