---
source_id: "git-md:repo-oneplatform-tsdataplatform-data-governance-ts-dataplatform-datagovernance-documentation-docs-dataproductowner"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/-/blob/256aaa023d7a1968e3a84c8985dae5a7c2db39ff/docs/DataProductOwner.md"
title: The Role of the Data Product Owner
authority: descriptive
version_hash: "sha256:b2f1aff5dbdb8bd18e08c57731f81e4853933273636c8570670d146e6e712cae"
body_hash: "sha256:7b450c2713cffe6ea2bd9bef57f241c4468d956cd3066b97f31c235e200bb6eb"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/docs/DataProductOwner.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# The Role of the Data Product Owner

Every **Data Product** must have a clearly identified **Data Product Owner (DPO)**, a key figure responsible for ensuring its quality, consistency, and proper use within the organization.

The Data Product Owner plays both a strategic and operational role in managing the Data Product’s lifecycle. Specifically, the DPO is responsible for:

**1. Supervision of Development and Data Definition**

The DPO oversees and guides the end-to-end development of the Data Product by:

•	defining the **data perimeter** and identifying the relevant data sources,

•	structuring the **metadata** and maintaining all **descriptive documentation**,

•	establishing and validating **data quality rules** and controls, in close collaboration with a dedicated Data Engineer.

This ensures that the Data Product is well-designed, coherent, and aligned with business needs.

**2. Evaluating, prioritizing, and deciding on future enhancements of the Data Product**, ensuring alignment with business needs, corporate strategies, and technical feasibility.

**3. Managing data access requests**, assessing their relevance and compliance with internal policies, with the authority to approve or deny them. 

The presence of a Data Product Owner is essential to guarantee:

•	data quality and reliability,

•	correct and controlled use of information,

•	sustainable evolution aligned with organizational needs.


![Data Product Owner](./images/Data_product_owner.png)

Within the **Data Marketplace ([Witboost](https://witboost-ui.dataoneplatform.teamsystem.cloud/marketplace/home?category=taxonomy%3Adefault%2Fdata-mesh-taxonomy))**, the Data Product Owner is always listed on the Data Product’s dedicated page, ensuring full transparency regarding the reference contact for any needs, clarifications, or change requests.

# How to delegate access request management using Team Roles

To avoid bottlenecks and ensure a smoother access management process, a Data Product Owner can **delegate the responsibility of handling access requests** to other trusted users. This is particularly useful in scenarios where there are frequent access requests or when the owner wants to distribute operational tasks across a team. By assigning dedicated roles, you can improve efficiency, reduce delays, and enable faster response times for end users.  

This functionality is available in the Marketplace under the name **Team Roles** and allows you to formally grant permissions to specific users so they can manage access on your behalf. You can enable and configure this feature by following the steps below.

## Roles guidelines

### Owner
The Owner is the only role that can manage team roles, by adding or removing Data Access Manager. 

!!! warning "You should NOT modify Owner role to a Data Product, to avoid inconsistent state where there is more than one owner managing the Data Product or there's a different owner than the one in the Descriptor."

### Data Access Managers
The Data Access Manager receives access request notifications for the Data Product and is responsible for **reviewing, approving, or rejecting them**. This role should be assigned to team members who have a clear understanding of the data exposed and the appropriate criteria for granting access.
Aim for a few Data Access Managers per Data Product, around 2-4 people.



## Step-by-Step Guide

[Video guide available here.](https://tsspa.sharepoint.com/:v:/s/G365-FederatedGovernance-DataGovernance/IQDSEVu89ifdTIyIS6K_UEfEATvt-IJoQEO8MKgdho4-z4w?e=KVPt5J)

1. **Access Your Project**

   - Go to the **My Projects** section.

   - Select the **Data Product** for which you want to delegate access management.
  

2. **Open the Team Roles Tab**

   - From the Data Product page, click on the **Team Roles** tab.

   - Click the **“Onboard Project”** button located in the center of the page.
![](./images/teamroles_step_1.png)

3. **Refresh the Page**

   - Reload the page to update the interface.

4. **Access Role Management**

   - After refreshing, the role management interface will appear.

   - From the left-hand menu, select **Data Access Manager**.

   - Click the **“Add Assignment”** button in the top-left corner.
   ![](./images/teamroles_step_2.png)

5. **Assign a User**
   
   - Search for the user you want to delegate the activity to.

   - **Tip:** It is recommended to search by last name, as the system matches based on email.

   ![](./images/teamroles_step_3.png)

6. **Confirm Assignment**

   - Select the desired user.

   - Click **“Assign”** to complete the process.


The selected user is now enabled to manage access requests for the chosen Data Product. 

### Delete an assignment
From the same page, you can click on the kebab button on the right and delete the user that you do not want anymore ad Data Access Manager.

   ![](./images/teamroles_delete.png)


## Webinar and useful content

**Doubts about how to navigate the marketplace, handling access requests, see data quality results and managing groups?**

A webinar with demos is available at [this link](https://tsspa-my.sharepoint.com/:v:/g/personal/l_mazzini_teamsystem_com/IQAyBq9WZUsdQK5KoSMruDIyActCMRVZ1_eofqbOvyLYCrc?nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D&e=trgAbg) ( italian language ) and the same content is also available in [slides here](https://tsspa.sharepoint.com/:b:/s/G365-FederatedGovernance-DataGovernance/IQCNUA9IOQUaR7SP9xrZytDcAaCYaukddbgII2ITfJk6lCg?e=frCx1N).   

See also the section [Data Access guidelines](https://development.teamsystem.com/docs/default/Component/data-product-lifecycle/data-access-guidelines/) for doubts regarding granting access to your data.
