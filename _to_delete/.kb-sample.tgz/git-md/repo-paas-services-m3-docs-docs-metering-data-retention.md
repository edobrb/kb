---
source_id: "git-md:repo-paas-services-m3-docs-docs-metering-data-retention"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/paas/services/m3/docs/-/blob/1a1607cdd8d49c974e61c819cb0e4f2cb8a838ce/docs/metering/data_retention.md"
title: Data retention
authority: descriptive
version_hash: "sha256:e6b6b82e275d427b7972a3d73e35878f7c18ae717a6549d836f7a6332bc3910f"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T22:48:02Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/repo/paas/services/m3/docs/docs/metering/data_retention.md", version_hash: "sha256:e6b6b82e275d427b7972a3d73e35878f7c18ae717a6549d836f7a6332bc3910f"}
body_hash: sha256:a332f1c1841917c43953b010c05f5a0bb0c9e5c43d18d6e7b4d52b784da0d1ba
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:paas/services/m3/docs"
index_status: pending
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/paas/services/m3/docs/docs/metering/data_retention.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---

# Data retention


## Introduction

The problem of data deletion is crucial for the privacy and the processing of the personal data of the various clients. Indeed on the expiry of the various packages subscribed to by the clients, Teamsystem is required to delete the data of the clients who have not renewed their packages.  
In order to manage this problem some microservices have been developed, which communicate to the services linked to the expired package the notification to proceed with the deletion of the data for the company whose package has expired, at the moment in which the company has decided not to renew the subscription.


## Architecture

![architecture](images/data-retention-arch.png)

The data retention process on a given company is activated when all the services of one and the same application (common appID) are in readonly or deactivated. When a service is put into read only or is deactivated an event is sent on a service bus.

The `digital-data-retention` service listens to these events, and for every event it evaluates whether or not to start the data retention process, checking whether all the services associated with the application whose data one wants to delete are in read only or deactivated for the company for which the event was sent.

If all the services are in read only or deactivated the postRetention API of the `data-retention-write` service is invoked, which saves to db the request to proceed with the archiving and the deletion of the data for a given client.

The data retention process is based on some states for which different operations are performed on the data of a company. These states are:

- STARTED: it is the initial state when the record is created on database with the call to the postRetention API of data-retention-hub 

- ARCHIVE_INIT: it is an intermediate state in which a notification is sent to the client that the archiving of their consumption will be started 

- ARCHIVED: it is an intermediate state in which a notification is sent to the subscribed service to start the archiving of the client's data and the client is also notified that the archiving process has started 

- DELETE_INIT: it is an intermediate state in which a notification is sent to the client that the deletion of their consumption will be started. 

- DELETED:  it is an intermediate state in which a notification is sent to the subscribed service to delete the client's data and the client is notified that the deletion of their data has started 

- COMPLETED: it is the state that specifies that the deletion of the data has finished. The subscribed service notifies the data-retention-write service that the deletion has succeeded 

- ABORTED: it is the state that specifies that the data retention process has been interrupted (for example following the repurchase of the package by the client). This situation does not occur if the state is COMPLETED or ERROR 

- ERROR: it is the state for which problems have occurred on the side of the subscribed service which  notifies  data-retention-write (the cause of the problem is not sent). In these cases for now the manual intervention of the L2 team is provided for in order to restore the pre-error situation 

- INTERNAL_ERROR: identifies that an error internal to the data retention process has occurred

It is possible to configure the time that passes between one state and the next through the environment variables of the `data-retention-scheduler` service. 


## Digital data retention

It is the service that dequeues the activation/readonly/deactivation events and starts the data retention process, invoking the [postRetention](https://data-retention-write-test.agyo.io/swagger-ui/index.html#/Retentions/postRetention) API of the data-retention-write service, only in the case in which all the services of one and the same application (with the same App Id) are in readonly or deactivated. Specifically, if the services are in read only the data retention process is activated only if the package is in the READONLY_EXPIRE_DATE_REACHED state (read only because of having reached the expiry date).

It exposes an API to [invoke NCS](https://digital-data-retention-test.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Notifications/postNotify) for the sending of the notifications 

Important: this service must have ONE SINGLE instance: if the service had several instances there is a risk of executing the process more than once 


## Data retention write

This service exposes the APIs for the [creation](https://data-retention-write-test.agyo.io/swagger-ui/index.html#/Retentions/postRetention) and the [modification](https://data-retention-write-test.agyo.io/swagger-ui/index.html#/Retentions/patchRetention) of the state of the data retention process 

It also exposes APIs for the [enrollment](https://data-retention-write-test.agyo.io/swagger-ui/index.html#/Application/postApplication) and the [modification](https://data-retention-write-test.agyo.io/swagger-ui/index.html#/Application/patchApplication) of a new App that must integrate with the data retention system


## Data retention read

This service exposes a read [API](https://data-retention-read-test.agyo.io/swagger-ui/index.html#/Retentions/getRetentionList) of a data retention process of a company with the possibility of filtering the search by application and state


## Data retention scheduler

It is a service that is in fact a scheduler that invokes the data-retention-write service in order to update the state of the data retention process 

The service is managed by some environment variables that specify when the retention process must change state:

- ALERT_TIMEOUT_BEFORE_ARCHIVING_IN_SECONDS: specifies the number of seconds that must pass from the STARTED state to the ARCHIVE_INIT state. In production the value is set to 3888000 (45 days)

- ARCHIVING_TIMEOUT_IN_SECONDS: specifies the number of seconds that must pass from the STARTED state to the ARCHIVED state. In production the value is set to 5184000 (60 days)

- ALERT_TIMEOUT_BEFORE_DELETION_IN_SECONDS: specifies the number of seconds that must pass from the STARTED state to the DELETE_INIT state. In production the value is set to 9072000 (105 days)

- DELETION_TIMEOUT_IN_SECONDS: specifies the number of seconds that must pass from the STARTED state to the DELETED state. In production the value is set to 10368000 (120 days)

- SCHEDULER_PERIOD: environment variable that specifies how often to activate the scheduler. In production the value is 3600 seconds (1 hour)


## Integration with data retention

In order to be able to integrate with the data retention system an app must make available  the following APIs:

a POST to launch the data archiving job, which returns a 202
a POST to launch the data deletion job, which returns a 202
a POST to launch the rollback job (e.g. the client repurchases the license), which returns a 202
The APIs must be asynchronous, so that the apis of the data-retention-write service do not remain hanging for too long.

The authentication in front of these APIs is the responsibility of the application that wants to integrate,  a token must be arranged in order to be able to call the APIs on the part of data-retention-write. In the case of an app that uses the authentication system of TS Digital, a token generated by TSDigital is perfectly fine.

The structure of the headers and body of the requests will have to be identical for all 3 APIs.

cURL example

    curl --location --request POST 'http://localhost:8080/api/archive' \
    --header 'Content-Type: application/json' \
    --header 'X-App-Name: POSTMAN' \
    --header 'X-App-Version: 1.0.0' \
    --header 'X-Correlation-Id: e97120a7-b65e-4dac-85e7-311b0aa1b5fc' \
    --header 'X-Request-Id: 008f7273-8f01-48f7-b9fc-95422de6d77f' \
    --header 'Authorization: Bearer <TOKEN>' \
    --data-raw '{​
        "jobData":{​
            "itemId":"xyz"
        }​
    }​'
