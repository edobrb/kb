---
source_id: "git-md:repo-oneplatform-experience-ice-docs-docs-services-launchpad-docs-index"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/experience/ice-docs/-/blob/10bdeb3c4dad03814c044fb1991c730779659a29/docs/services/launchpad/docs/index.md"
title: Launchpad
authority: descriptive
version_hash: "sha256:ecf456a7850be3222ca8396d38677759b0266a1a70bf42eac5dcbd46e06613c9"
body_hash: "sha256:ff47a93f6e8f0a1544d816bcfdbfb5b8c61e256b267ccaf700afa387526db26f"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/experience/ice-docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/experience/ice-docs/docs/services/launchpad/docs/index.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Launchpad

**Launchpad** is the name of the 1F's service that allows you to manage the _menus_. It is a part of the OnePlatform and it will be available to all Teamsystem POs.

## What is a menu?

A **Menu** is a ordered tree of items which can be `Parent` or `Module` items. The **Menu** is used to organize the **Modules** in a meaningful way, for them to be seen and used by the users.

### What is a item then?

An item is a single element of a **Menu**. It can be a `Parent` or a `Module` item. A `Parent` item is used to group other items together, while a `Module` item is used to link to a specific **OnePlatform Module**. Topologically speaking, a `Parent` item is a node in the tree that can have children, while a `Module` item is a leaf node in the tree.

## How should I use the Launchpad?

If you are a _Product Owner_ and you want to create a **Menu** for your product, you should use the **Launchapd** to do it.
The **Launchpad** will expose a REST API that you can use to create your **Menu**. You will need to provide an unique name for the **Menu** and a tree of items that will be part of the **Menu**, you'll also need to provide the reference identifier of the entity or resource the **Menu** is linked to (example: `products:comic` or `settings`). This is a technical identifier that is used to link the **Menu** to the entity or resource.

## Fields of a Menu

Let's have a better look at the fields that compose a **Menu**, one by one, what they are and how to set them. Finally let's see a example.

### Definition

#### Name

The name of the **Menu** is a human-readable string that uniquely identifies the **Menu**.

#### RefId

The reference identifier to the entity or resource the **Menu** is linked to (example: `products:comic` or `settings`). This is a technical identifier that is used to link the **Menu** to the entity or resource.

#### Items (`menu` field)

The `menu` field is an array of **Item** objects that are used to define the menu tree. For each **Item** you need to provide information like the name, the icon, the description, while the `type` is not a field you need to set, it is automatically defined by the presence of the `children` field for `Parent` items or the `module` field for `Module` items.
