---
source_id: "git-md:repo-paas-services-m3-infrastructure-m3-outbox-relay-docs-index"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/paas/services/m3/infrastructure/m3-outbox-relay/-/blob/de8445cc3386e30eba7e1a27a62c59781a317fc3/docs/index.md"
title: M3 Outbox Relay Documentation
authority: descriptive
version_hash: "sha256:f918967fd38b6a378a4f9057d8b570bfa50c5446965f89716fd8cd469dfaecb9"
body_hash: "sha256:339ddc0768c6a1938e01f285b12cc42429ffc3a4dc4acb865d8a1a2f19652bcf"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:paas/services/m3/infrastructure/m3-outbox-relay"
index_status: pending
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/paas/services/m3/infrastructure/m3-outbox-relay/docs/index.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# M3 Outbox Relay Documentation

## Overview

The M3 Outbox Relay is a microservice implementing the **Outbox Pattern** for reliable event publishing in distributed
systems.
It ensures that domain events are reliably delivered to message brokers even in the presence of failures, providing *
*at-least-once delivery guarantees** and messaging order.

This service follows **Domain-Driven Design (DDD)** principles, **Hexagonal Architecture**, and **Clean Architecture**
patterns, written in idiomatic Kotlin using Quarkus framework.

## Architecture

### Hexagonal Architecture

The project is structured following hexagonal architecture principles with clear separation of concerns:

```
┌─────────────────────────────────────────────────────┐
│                   Bootloader                        │
│            (Application Configuration)              │
└─────────────────────────────────────────────────────┘
                         │
         ┌───────────────┼───────────────┐
         │               │               │
    ┌────▼────┐    ┌─────▼──────┐  ┌────▼────┐
    │ Adapters│    │   Domain   │  │ Adapters│
    │  (In)   │───▶│   (Core)   │◀─│  (Out)  │
    └─────────┘    └────────────┘  └─────────┘
    - Cron         - Use Cases      - Storage
                   - Models         - Bus
                   - Ports          - Messenger
                   - Pumps
```

### Modules

#### Domain Module

Contains the core business logic and defines the boundaries through ports (interfaces):

- **Models**: `OutboxEvent`
- **Use Cases**: `ProcessOutboxEvent`, `DeleteDeliveredEvents`
- **Ports: `OutboxRepositoryPort`, `Messenger`,`OutboxUseCase`, `RetentionUseCase`, `TransactionManager`
- **Pumps**: `OutboxStoreEventNoConcurrencyPump` - reactive event processing engine

#### Adapters Module

Implements the ports defined in the domain:

- **Storage Adapter**: JPA/Hibernate implementation of `OutboxRepositoryPort`
- **Bus Adapter**: Message broker integration implementing `Messenger`

#### Cron Module

- **Cron **: Scheduled tasks for retention policies

#### Bootloader Module

Application entry point and dependency injection configuration.

## Core Concepts

### Outbox Pattern

The Outbox Pattern solves the dual-write problem by:

1. Storing domain events in an outbox table within the same database transaction as the business operation
2. A separate process (pump) reads events from the outbox and publishes them to the message broker
3. Events are marked as `DELIVERED` after successful publishing
4. Failed events can be retried or moved to a dead letter table

### Event Processing Strategies

#### No Concurrency Strategy

The `OutboxStoreEventNoConcurrencyPump` provides **sequential, ordered event processing** with the following
characteristics:

- **Single-threaded processing** per aggregate to maintain ordering
- **Reactive pipeline** using Project Reactor for efficient resource utilization
- **Automatic retry** with exponential backoff for transient failures
- **dead letter pattern** for permanently failed events
- **Buffer-based batching** for optimal database access

**Key Features:**

- Events are processed in order by `aggregate_id` and `timestamp`
- Configurable batch size and buffer size for performance tuning
- Automatic cursor-based pagination to handle large event volumes
- Graceful shutdown with exhaustion waiting

**Configuration Properties:**

```properties
outbox.aggregator-id=your-aggregate-id
outbox.no-concurrency.pump.batch.size=100
outbox.no-concurrency.pump.prefetch.size=1
outbox.no-concurrency.pump.retry.delay.seconds=10
outbox.no-concurrency.pump.repeat.delay.seconds=5
outbox.no-concurrency.pump.buffer.size=100
```

### Event Lifecycle

```
┌──────┐    ┌─────────┐    ┌───────────┐    ┌───────────┐
│ READY├───▶│ Selected├───▶│ Processing├───▶│ DELIVERED │
└──────┘    └─────────┘    └─────┬─────┘    └───────────┘
                                 │
                                 │ Failure
                                 ▼
                            ┌──────────┐
                            │    DLQ   │
                            └──────────┘
```

1. **READY**: Event is stored in the outbox and ready for processing
3. **Processing**: Event is being published to the message broker
4. **DELIVERED**: Event successfully published and marked for cleanup
5. **Dead-letter**: Permanently failed events moved to dead letter table


### Retention Policy

The `DeleteDeliveredEvents` use case implements a retention policy:

- Periodically removes `DELIVERED` events older than the configured retention period
- Runs as a scheduled job (cron adapter)
- Only deletes events with `DELIVERED` status to maintain data integrity
- Configurable retention period (default: 7 days)

**Configuration:**

```properties
outbox.retention.period.days=7
```

Stores events that have permanently failed processing for debugging and analysis.

## Testing

The project includes comprehensive tests for all layers:

### Repository Tests

- `OutboxFacadeRepositoryTest`: Tests all repository operations including event selection, marking as delivered,
  pagination, deletion, and dead letter operations

### Integration Tests

- `NoConcurrencyTest`: Tests sequential processing with various event volumes (200, 500, 1000, 5000 events)
- `RetentionTest`: Tests retention policy execution

**Test Strategies:**

- Use real database (H2 for tests) to ensure transactional behavior
- Mock external dependencies (Messenger) to isolate tests
- Verify ordering guarantees in concurrent scenarios
- Test retry mechanisms and error handling

## Performance Considerations

### Optimizations

2. **Cursor-based Pagination**: Efficient handling of large event volumes without loading all events
3. **Buffer Management**: Reduces database round-trips by batching event fetching
4. **Reactive Pipeline**: Non-blocking processing with backpressure support
5. **Single-threaded Processing**: Maintains ordering while avoiding coordination overhead

### Scalability

- **Per-Aggregate Isolation**: Different aggregates can be processed by different instances
- **Configurable Batch Sizes**: Tune for your workload and database performance
- **Reactive Backpressure**: Prevents overwhelming downstream systems

## Error Handling

### Transient Failures

- Automatically retried with exponential backoff
- Configurable retry delay
- Unlimited retries (Long.MAX_VALUE) until success or permanent failure

### Permanent Failures

- Events that consistently fail are moved to dead letter table
- Original event data preserved for debugging
- Cause of failure recorded in `caused_by` field

## Monitoring and Observability

The service provides extensive logging at key points:

- Event selection and processing
- Retry attempts with failure reasons
- Pipeline lifecycle events (subscribe, complete, cancel)
- Buffer state and batch fetching
- dead letter operations

**Key Log Patterns:**

```
Processing event: {event-id}
Retry {count} for {event-id}: {error-message}
Pipeline repeating after delay of {seconds} seconds
Event {event-id} failed permanently: {error-message}
```


## Best Practices Key Points

1. **Unique Constraint**: Always maintain the `(aggregate_id, aggregate_version)` unique constraint
2. **Event Ordering**: Rely on the pump's ordering guarantees; don't process events out of order
3. **Retention Configuration**: Set retention period based on your audit and debugging needs
4. **Monitoring**: Monitor dead letter table for systematic failures
5. **Batch Size Tuning**: Start with default values and tune based on your workload
6. **Graceful Shutdown**: Always allow the pump to exhaust before shutting down
