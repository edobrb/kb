---
source_id: "git-md:repo-oneplatform-pet-developer-portal-documentation-teamsystem-id-docs-project-adoption-tsid"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/PET/developer-portal/documentation/teamsystem-id/-/blob/efd562b907329be3427ff46fc51373ad99b77195/docs/project/adoption_tsid.md"
title: Adoption TeamSystem ID v.3
authority: descriptive
version_hash: "sha256:469eca2edf8727f8fd03a428af714ff5781f9a37565bf19ecd2638ec776d2664"
body_hash: "sha256:469eca2edf8727f8fd03a428af714ff5781f9a37565bf19ecd2638ec776d2664"
lang: und
source_langs: [und]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/PET/developer-portal/documentation/teamsystem-id"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/PET/developer-portal/documentation/teamsystem-id/docs/project/adoption_tsid.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Adoption TeamSystem ID v.3

Below is the list of TeamSystem software integrated with TeamSystem ID v.3 in the production environment (data updated as of 28.02.2023)

| ID | Applicativi |
|----|-------------|
| 1  | Cassa In Cloud |
| 2  | Computi In Cloud |
| 3  | CPM Demo |
| 4  | CPM Pre Prod |
| 5  | Cross Products |
| 6  | Customer Hub |
| 7  | ENTERPRISE |
| 8  | Euroconference |
| 9  | Euroconference Blog |
| 10 | Fiscali SaaS |
| 11 | HORECA |
| 12 | Internal |
| 13 | Pandora |
| 14 | Reviso |
| 15 | TEAMSYSTEM INDUSTRY 4.0 |
| 16 | Tempi&Spese |
| 17 | TS Active |
| 18 | TS Analytics |
| 19 | TS Analytics Mobile App |
| 20 | TS DMS |
| 21 | TS Digital |
| 22 | TS Studio |
| 23 | TS VIALIBERA |
| 24 | TS VIALIBERA CLOUD |
| 25 | TS VIALIBERA SUITE |
| 26 | TSDesk |
| 27 | TSHR Mobile |
| 28 | TSHR_PORTAL |
| 29 | TSHR_PORTAL_KB |
| 30 | TSIH Backoffice |
| 31 | TSX Package Manager Panel |
| 32 | TeamSystem Digital Signature iOS |
| 33 | TeamSystem DigitalBox Android |
| 34 | TeamSystem DigitalBox Pro Android |
| 35 | TeamSystem DigitalBox Pro iOS |
| 36 | TeamSystem DigitalBox iOS |
