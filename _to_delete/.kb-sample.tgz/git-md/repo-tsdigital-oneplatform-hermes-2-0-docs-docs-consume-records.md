---
source_id: "git-md:repo-tsdigital-oneplatform-hermes-2-0-docs-docs-consume-records"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/oneplatform/hermes-2.0/docs/-/blob/4421edf391059ee5c1ad1535ce4ffe23890b2aed/docs/consume-records.md"
title: A common interface and multiple way to consumer record
authority: descriptive
version_hash: "sha256:72ad84beb149aa13c37969900692299333c54418b1939a86bc040ce28c169735"
body_hash: "sha256:aacadd88a4ce392a56c9311a7653f9c8515f1670d9f541e23e0e06e2ee53a69f"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/oneplatform/hermes-2.0/docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/oneplatform/hermes-2.0/docs/docs/consume-records.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# A common interface and multiple way to consumer record

!!! tip "Agent Skill available"
    Building your consumer with an AI coding assistant? The `hermes-kafka-consumer`
    skill guides it through the Hermes consumption contract. See [Agent Skills](agent-skills.md).

Consuming events from Hermes is made through a standard kafka interface, therefore you can use the tools
you prefer from a more customizable kafka streams (see kafka-stream-consumer page) to other tool such as kafka connectors,
flink, and other third party kafka compatible tools

# Bootstrap servers

We utilize Kafka across four environments: **Dev**, **Test**, **Demo**, and **Prod**. Each environment has its own dedicated bootstrap servers:

- **Dev**: `pkc-1wvvj.westeurope.azure.confluent.cloud:9092`  
  Used for internal development and debugging purposes.

- **Test**: `pkc-57q33g.westeurope.azure.confluent.cloud:9092`  
  This environment is for integration testing, allowing validation before deployment to production.

- **Demo**: `pkc-57q33g.westeurope.azure.confluent.cloud:9092`  
  This environment is used for pre-production demos and validation scenarios with production-like behavior.

- **Prod**: `lkc-wjw9qm.dom8w152emg.westeurope.azure.confluent.cloud:9092`  
  The production environment ensures stability, scalability, and availability for live systems. 
  The cluster is private and secured behind **Azure PrivateLink** to ensure restricted access. 
  For more information on accessing the Private Link, please contact the **IT department**.

These bootstrap servers act as the entry point for Kafka clients, enabling communication with the Kafka cluster for each respective environment.

## Kafka Consumer Examples  

You can find detailed Kafka consumer examples in a dedicated documentation page:  

🔗 [Kafka Consumer Examples](getting-started-consumers.md)

This page includes implementations for:  

- **Java** (Apache Kafka client)  
- **JavaScript** (KafkaJS)
- **Spring Boot** (Spring Kafka)  
- **Dapr** (Dapr Pub/Sub with Kafka)

!!! warning "DAPR Consumers: Enable `escapeHeaders`"
    Starting from upcoming versions of the Hermes REST Proxy, the native Confluent
    strategy for embedding schema validation references directly in Kafka record
    headers will be used (see [Schema ID in Kafka Headers](https://www.confluent.io/blog/schema-id-kafka-headers-data-governance/)).

    If your consumer uses DAPR, you **must** add the following metadata to your
    subscription component to ensure binary header values are correctly propagated:

    ```yaml
    - name: escapeHeaders
      value: "true"
    ```

    Without this setting, DAPR may silently drop or corrupt the `__value_schema_id`
    header injected by the serializer.
    [Ref](https://docs.dapr.io/reference/components-reference/supported-bindings/kafka/#spec-metadata-fields)

# The process of reading messages

The first thing to point out is that Consuming record from a topic is not destructive process. With this i mean that the 
record it's self remain untouched and persist for others to be read.
The need for clarify this thing comes from the fact that many of the teams are now used to consumer from an azure service bus.
This is completely a different approach with the relative pros and cons that are needed to build a resilient streaming data platform.
At this point you might think that "consuming" is not the right word since we are only "reading" the records, this is not true,
we are still "consuming" because after each successfully read with acknowledge that record and a state of where we have been
able to read to is preserved on server side allowing you to stop and resume from where you left without impacting other consumers.
Moreover, is possible to change that state to start re-processing everything from a previous index if we need to.

# Idempotency

Consumer applications should be designed to handle duplicate messages without causing unintended side effects.
This involves making the processing logic idempotent. For example, if the processing involves updating a database, the operation should be designed to be idempotent, ensuring that the same database update has the same result regardless of how many times it is applied.
This might involve using unique identifiers or checking the current state to avoid redundant operations such as the cloud events ID field.

# The offset

As we already mentioned while you consume the recrods an offset is kept on server side so that you can continue to consume messages
from where you left after a reboot. 
The offset can be used to monitor how consumers are performing by observing their "lag". The lag is the differenze from the 
current number of records minus the consumer offset.

### Reset the offset

Resetting the offset can be useful to start over and reprocess the messages from the beginning, or to be precise
from start of the retention period. if a topic a retention period of 1 week you will start over from the records of 1 week ago.
Since resetting an index is a dangerous and uncommon operation, in order to do that you need the kafka-tools installed (https://docs.confluent.io/kafka/operations-tools/kafka-tools.html)
This is useful in dev environment since you will need to star over multiple team with a clean situation.

the first thing to do is to create a config file. lets name it: config.properties
here is a basic configuration you can copy. update it with the kafka bootstrap server name and port and provide user and key
```
ssl.endpoint.identification.algorithm=https
sasl.mechanism=PLAIN
request.timeout.ms=20000
bootstrap.servers=<cloud-bootstrap-server>
retry.backoff.ms=500
sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username="<cloud-key>" password="<cloud-password>";
security.protocol=SASL_SSL
```

Now list the topic on witch the consumer group is consuming from.
Note that if a topic has more partition you will get a row foreach topic since every partition can have its own offset
```
kafka-consumer-groups --bootstrap-server <server:port> --command-config config.properties --group <consumer-group-name> --describe
```

Now we can run a dry run of the command with the following command
note that partitions can be specified using this format: `topic1:0,1,2`, where 0,1,2 are the partition to be included in the process. Reset-offsets also supports  multiple topic inputs.

```
kafka-consumer-groups --bootstrap-server <server:port> --command-config config.properties --group <consumer-group-name> --topic <topic-name> --reset-offsets --to-earliest --dry-run
```

if everything is ok, just replace the --dry-run option with --execute.
that's it.
