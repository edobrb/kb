---
source_id: "git-md:repo-oneplatform-tsdataplatform-data-governance-ts-dataplatform-datagovernance-documentation-docs-introduction"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/-/blob/256aaa023d7a1968e3a84c8985dae5a7c2db39ff/docs/introduction.md"
title: What is a data product?
authority: descriptive
version_hash: "sha256:e78b193ce156485dc2fef767a6df895eac9c56cf7749d7252ea2b1416a17d227"
body_hash: "sha256:ed7dd4f732f32af72219b28c388b01422cdfbb64b62123dd9c4e010de7b66fa2"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/docs/introduction.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# What is a data product?

The Data Product is the core concept of the Data Mesh paradigm, which is a sociotechnical approach  to data that has 4 main principles: 

- **Domain driven ownership**: the ownership of data is decentralized and distributed to business units teams, in order to leverage their deep knowledge of the domain. 
- **Data As a Product**: providing data must be treated as a product, from the design, to managing its versioning and lifecycle, and decommissioning. 
- **Self-serve Platform**: the Data Platform team will provide self-serve platform tools in order to simplifying infrastructure management and eliminate complexity and friction for data product teams. These tools will also guarantee interoperability between different data products. 
- **Federated Governance**: the federated governance will provide common policies and standards to allow an effective decentralization and self-sovereignty of domains. 

A **Data Product** is a logical unit that contains domain data, but also metadata (so data that describes how data is modeled and its meaning), the code that process the data and the underlying infrastructure. Each Data Product must have a Data Product Owner, from the domain team. The main goal is to build a modular data platform where each Data Product is a module that can be combined and reused in combination with other data products. 

There are two types of Data Product:

- **Source Aligned Data Products**: the products that bring data from the operational system to the data platform for the first time. Source Aligned Data Product should be as general purpose as possible in their data model to ensure reusability. 
- **Consumer Aligned Data Products**: the products that elaborate and may combine more Data Products to provide data to a specific use case (i.e. dimensional model for BI Dashboards ). 

Each Data Product is described by its ports:

- **Input ports**: interfaces from where the data is read; Source Aligned Data Products will describe the system from where the data is read ( i.e. production db ), Consumer Aligned Data Products will link the output ports from which is consuming data from other data products. 
- **Output ports**: interfaces that are provided to potential consumers to read data (i.e. streaming topics on Hermes, Databricks tables or views, ... )


## Is my data eligible to be a Data Product? 
You should treat you data as a Data Product if at least one of the following question has "Yes!" as answer:

- *Do other applications need my data?* 
- *Is this data needed for AI uses cases or BI dashboards?*
- *Can other domains be interested in consuming my data to satisfy their use cases?*

## How big is a Data Product? 
A Data Product should provide a set of __cohesive and complete information__: in order to be reasonably sure about the perimeter, there are some questions that you can ask yourself: 

- *Is this Data Product valuable on its own?* 
- *Can I describe the content of a Data Product in one or two simple sentences?*
- *Can I reuse this Data Product for other use cases?*

# Big picture of Data Platform 

![](./images/architecture.png)

1. Each TS Product can publish its data through Hermes - see detailed documentation [here](https://development.teamsystem.com/docs/default/module/hermes/#hermes-20) in form of events. 
2. These events may be useful for other TS Products, that can consume streaming data directly from Hermes. 
3. Those events that can serve AI/BI use cases, or need to be historicized and preserved in time, will be saved in the Data Lake where consumers will be able to consume them through tables and views. 

A Data Product is a logic module inside this big picture architecture.

![](./images/data_product.png)
