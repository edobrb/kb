---
source_id: "git-md:repo-paas-services-m3-subscription-manager-m3-subscriptions-read-docs-index"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/paas/services/m3/subscription-manager/m3-subscriptions-read/-/blob/6e22787dce3f3fc0d6ebd07df90990e4ae907b79/docs/index.md"
title: m3-subscription-read
authority: descriptive
version_hash: "sha256:9c6c235af809d2b753e51852b15ba28bb4c428a3976a5146aebf1277ef5e4acd"
body_hash: "sha256:e25632349bd1d736d0cf49dc35e133c7dfae61640c58a900f61cff880a557aad"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:paas/services/m3/subscription-manager/m3-subscriptions-read"
index_status: pending
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/paas/services/m3/subscription-manager/m3-subscriptions-read/docs/index.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# m3-subscription-read

## Overview
The  `m3-subscription-read` service is responsible for exposing Rest APIs to read subscriptions of a business package to a subscriber. It is built using Kotlin and Quarkus and it uses Maven for dependency management.
This service is a part of the M3 platform and is designed to return subscriptions data, as part of a CQRS architecture.

## Endpoints

The service exposes the following endpoints:
- `GET /api/v1/subscriber/{subscriberId}/subscription/active?page={page}&size={size}`: Returns a paginated list of active subscriptions tied to a certain subscriber
- `GET /api/v1/subscriber/{subscriberId}/subscription?page={page}&size={size}`: Returns a paginated list of subscriptions tied to a certain subscriber

### Pagination Parameters

Both endpoints support pagination with the following query parameters:

- `page` (required): The page number (0-based indexing). Must be >= 0
- `size` (required): The number of items per page. Must be between 1 and 100

### Response Format

All paginated responses include a `pageInfo` object with the following structure:

```json
{
  "subscriptions": ["..."],
  "pageInfo": {
    "page": {
      "value": 0
    },
    "size": {
      "value": 20
    },
    "totalElements": 150,
    "totalPages": 8,
    "hasNext": true,
    "hasPrevious": false
  }
}
```

#### PageInfo Properties

- `page`: Current page number (PageNumber value object)
- `size`: Page size (PageSize value object)  
- `totalElements`: Total number of items across all pages
- `totalPages`: Total number of pages
- `hasNext`: Whether there is a next page available
- `hasPrevious`: Whether there is a previous page available

### Validation Rules

The following validation rules apply to pagination parameters:

**Page Number:**
- Default value 0
- Must be >= 0

**Page Size:**
- Default value 10
- Must be between 1 and 100 (inclusive)
- Must be positive (> 0)
- Zero or negative values will result in HTTP 400 Bad Request
- Values exceeding 100 will result in HTTP 400 Bad Request


### Definition of `SUBSCRIPTION`
A Subscription represents a subscription to a certain package that has been granted to a subscriber.
The package being specified by the property `packageId` and the subscriber (which is the end user) by `subscriberId`
A subscription is valid between the `startDate` and `endDate` and contains several services as long as constraints.
The `commercialOffer` field carries the commercial offer associated to the subscription; it is a nullable string.

```json
{
  "packageId": "string",
  "subscriberId": "string",
  "priority": "int",
  "sharable": "bool",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "commercialOffer": "string | null",
  "constraints": [
    {
      "type": "string",
      "value": "int",
      "consumed": "float",
      "services": [
        {
          "name": "string",
          "type": "string"
        }
      ]
    }
  ],
  "services": [
    {
      "name": "string",
      "config": {
        "additionalProp1": "string",
        "additionalProp2": "string",
        "additionalProp3": "string"
      }
    }
  ]
}
```

### Error Responses

The API returns structured error responses for validation failures:

```json
{
  "code": "400",
  "type": "IllegalArgumentException", 
  "message": "Page number must be >= 0"
}
```

Common error scenarios:
- **Page number must be >= 0**: When `page` is negative
- **Page size must be positive**: When `size` is zero or negative
- **Page size must be between 1 and 100**: When `size` exceeds maximum limit

### Constraints
Each subscription can have constraints that define usage limits. Constraints contain:
- `type`: The constraint type identifier 
- `value`: The maximum allowed value for this constraint
- `consumed`: The amount of the constraint that has been consumed/used (float value)
- `services`: List of services this constraint applies to

The `consumed` field tracks how much of the constraint has been utilized, allowing for usage monitoring and enforcement. The consumed value is stored in a separate `subscription_consumptions` table and represents the total consumption as a float value.

## Flow

#### API Interaction
The service exposes a REST API endpoint (GET /api/v1/subscriber) that clients can use to get the subscriptions. When a request is made to this endpoint, the service processes the request using its relative UseCase.

#### Validation
The system checks if the ID passed is a correctly formed ID, then it uses it to retrieve the data.

#### Execution
The SubscriberUseCase class is used to handle the retrieval of subscriptions. This class performs the validation steps.

### Getting active subscriptions for a specific subscriber

To get all currently active subscriptions for a certain subscriber with pagination support, the following flow is followed.

#### API Interaction
The service exposes a REST API endpoint (`GET /api/v1/subscriber/{subscriberId}/subscription/active?page={page}&size={size}`) that clients can use to get the subscriptions. When a request is made to this endpoint, the service processes the request using the `SubscriberUseCase`'s GetActiveSubscriptionsById.

#### Validation
The system validates:
- The subscriberId is a valid UUID
- The page parameter is >= 0
- The size parameter is between 1 and 100

#### Execution
The `SubscriberUseCase` class handles the retrieval of active subscriptions by subscriberId with pagination. The response includes both the subscriptions data and pagination metadata (PageInfo).

### Getting subscriptions for a specific subscriber

To get all subscriptions for a certain subscriber with pagination support, the following flow is followed.

#### API Interaction
The service exposes a REST API endpoint (`GET /api/v1/subscriber/{subscriberId}/subscription?page={page}&size={size}`) that clients can use to get the subscriptions. When a request is made to this endpoint, the service processes the request using the `SubscriberUseCase`'s GetSubscriptionsById.

#### Validation
The system validates:
- The subscriberId is a valid UUID
- The page parameter is >= 0  
- The size parameter is between 1 and 100

#### Execution
The `SubscriberUseCase` class handles the retrieval of all subscriptions by subscriberId with pagination. The response includes both the subscriptions data and pagination metadata (PageInfo).

## Authentication
The service uses the `Authorization` header to authenticate requests. The header should contain a valid TSID token. The service validates the token using the `auth-service` and checks the authorization using the `opa-service`. Every request must contain a valid token, otherwise the service will return a `401 Unauthorized` response and every API has its own permission policy.

| API                                                         | Permission required on OPA |
|-------------------------------------------------------------|----------------------------|
| `GET /api/v1/subscriber/{subscriberId}/subscription/active` | subscription.read          |
| `GET /api/v1/subscriber/{subscriberId}/subscription`        | subscription.read          |
