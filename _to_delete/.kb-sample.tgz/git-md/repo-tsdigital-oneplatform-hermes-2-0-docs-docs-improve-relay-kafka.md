---
source_id: "git-md:repo-tsdigital-oneplatform-hermes-2-0-docs-docs-improve-relay-kafka"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/oneplatform/hermes-2.0/docs/-/blob/4421edf391059ee5c1ad1535ce4ffe23890b2aed/docs/improve-relay-kafka.md"
title: ✅ 1. Direct Kafka Client Integration
authority: descriptive
version_hash: "sha256:f78aa9c9d4b6a16df41aedf020dfd26af4cbd344203b3c51171959f04d187a12"
body_hash: "sha256:f78aa9c9d4b6a16df41aedf020dfd26af4cbd344203b3c51171959f04d187a12"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/oneplatform/hermes-2.0/docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/oneplatform/hermes-2.0/docs/docs/improve-relay-kafka.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# ✅ 1. Direct Kafka Client Integration

### Description:
Embed the Kafka client directly into Relay application.

### Pros:

- Lower latency and fewer network hops.
- Simplifies the architecture.

### Cons:

- Tighter coupling to Kafka (adds dependency and configuration complexity).

---

# ✅ 2. Add gRPC or Binary Protocol Alongside REST

### Description:
Introduce a gRPC (or other binary) interface alongside the existing REST proxy. Both APIs coexist, allowing clients to gradually move to a faster, more modern protocol without removing REST support.

### Pros:

- Enables gradual migration from REST to gRPC.
- Improved performance and efficiency for clients that adopt gRPC.

### Cons:

- Adds maintenance overhead (two APIs to support).
- More complex setup than REST.
- Maybe a lot of structural changes on the relay side, which adds complexity in the short term.

---

# ✅ 3. Embedded Kafka Producer via Sidecar Pattern

### Description:
Run a Kafka-producing sidecar container alongside Relay. Relay communicates locally and the sidecar produces to Kafka.

### Pros:

- Isolates Kafka complexity and configuration from rest proxy
- Still allows Kafka integration without exposing Kafka directly.

### Cons:

- Adds deployment complexity (two containers per service).
- The sidecar would still need to call our internal proxy to obtain secrets, which limits its independence and flexibility.

--- 

# 💡 Note on Azure Key Vault Access: 
> The current REST proxy is responsible for communicating with Azure Key Vault, which is hosted in a private VNet. This means not all consumers of the Docker image will necessarily have network access to the Key Vault.
<br><br>
Even in the sidecar pattern, access to secrets or cryptographic material may still require communicating with the REST API, since it centralizes Key Vault integration logic. In this case, the sidecar becomes a local interface for the main application, but it still depends on the REST proxy to retrieve secrets.
<br><br>
As a result, any alternative architecture (direct Kafka client, gRPC, sidecar, etc.) must account for the fact that secret retrieval or signing operations are tightly coupled with the REST proxy and its network placement.
<br><br>
This creates a tradeoff: removing or bypassing the REST proxy fully may not be feasible unless you replicate or relocate the Key Vault access logic to a place where network connectivity is guaranteed — such as a secure sidecar running in the same private network.

---

# 🔍 Recommendations
After evaluating the available architectural options, here are the proposed recommendations:

- Discard the sidecar pattern, as it introduces additional deployment complexity and does not remove the dependency on the REST API — the sidecar would still need to retrieve secrets from Key Vault via the REST proxy, defeating much of the purpose.

- Integrating the Kafka client natively into our Relay project appears to be the most robust and maintainable approach. It allows for tighter integration, improved performance, and opens the door to sharing core logic (e.g., Kafka producer setup, message format, error handling) between Relay and the REST API through a common library.

- The gRPC interface could make sense as part of a broader future strategy, potentially replacing or complementing our REST layer. However, it may not be the right tool to solve the specific problem at hand with Relay, given the current scope and requirements.
