---
source_id: "git-md:repo-tsdigital-oneplatform-ai-cowork-docs-ai-platform-docs-docs-ts-ai-and-orchestrator-meta-history"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/-/blob/6c617371f851e6ffa24e0fe0c27751375233fdb5/docs/ts-ai-and-orchestrator/meta/history.md"
title: Conversation history in `_meta`
authority: descriptive
version_hash: "sha256:c26bffd31d5896c9b64cf6f87e53fab66e71a614fcf5abbfc6d7888fa20f3669"
body_hash: "sha256:c26bffd31d5896c9b64cf6f87e53fab66e71a614fcf5abbfc6d7888fa20f3669"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/docs/ts-ai-and-orchestrator/meta/history.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Conversation history in `_meta`

This page is for **MCP server authors**. It explains a feature of the orchestrator that injects the recent conversation history of the current chat session into every tool call as a deterministic Markdown blob, so tools can ground their behaviour on what was already said without having to fetch it themselves. The mechanism is called **history meta**.

By the end of the page you should know what history meta is, who builds it, how to read it inside your MCP, and how it differs from the [bindings](bindings.md) channel that sits next to it under the same `_meta` envelope.

For the shared `_meta` envelope discipline — versioning, the side-channel guarantee, how to read any channel defensively — see the [`_meta` channels overview](index.md).

## What it is

For every chat run, the orchestrator pre-fetches the last few turns of the session from the memory service, renders them as a single Markdown document, wraps it in a versioned envelope and attaches it as protocol-level `_meta.history` on every outbound `tools/call` for that run.

A few concrete examples of what an MCP would do with it:

- Resolve anaphoric references in the current question ("the previous answer", "the document I asked about", "do it again but for the other product").
- Bias retrieval against the same topic the user has already been exploring without forcing the model to repeat itself.
- Detect "follow-up" intents that the model alone might miss because the channel is deterministic and not subject to prompt rewriting.

History meta is **server-owned**: the client cannot set it, cannot turn it off, and cannot influence what ends up inside it. This is the key difference from bindings.

## Why this design

History shares the [general `_meta` design](index.md#why-this-design) — side channel, versioned, computed once per run — plus two concerns unique to this channel:

**The orchestrator is the single source of truth for history.** Every MCP tool in the same run sees exactly the same history snapshot, rendered by the same code path. No tool needs to call the memory service itself, no two tools can disagree on what "the previous turn" was, and there is no risk of N-times duplicated HTTP traffic to `runtime-history` per run.

**Strict byte budget.** History is potentially unbounded; the channel is not. The orchestrator enforces a hard cap on the serialized envelope size and binary-searches a UTF-8-safe truncation that fits inside it. Past the cap, the channel degrades to "history truncated" rather than silently corrupting a request.

## The contract

There are two surfaces to think about: what the orchestrator builds, and what the MCP receives on each tool call.

```mermaid
flowchart LR
    M["runtime-history<br/>(memory service)<br/><i>last N turns for the session</i>"]
    R["format_history_as_markdown<br/><i>deterministic Markdown</i>"]
    B["HistoryEnvelope<br/>{ version: '1', data: { conversation_history_md: '...' } }<br/><i>orchestrator builds once per run</i>"]
    C["_meta.history<br/>(orchestrator → MCP, every call)<br/><i>same dict reused by reference</i>"]
    M --> R
    R --> B
    B --> C
```

**The envelope** is what the orchestrator builds and what your MCP receives:

```json
{
  "version": "1",
  "data": {
    "conversation_history_md": "# Conversation history\n\nPrevious conversation turns, ordered from oldest to newest.\n\n## Turn 1\n\n**User**\n\n...\n\n**Assistant**\n\n...\n"
  }
}
```

The envelope is strict: `extra="forbid"`. The orchestrator validates the shape (a `version` literal and a `data` dict) and is the only writer of `data`. The key under `data` is configurable via the `MCP_HISTORY_META_KEY` env var on the orchestrator and defaults to `conversation_history_md`.

The envelope arrives on the wire under the `history` key of the request `_meta`, as a sibling of `bindings`. FastMCP may also add transport or runtime keys to the same `_meta` map — those are added transparently and you should not try to manage them yourself.

## What goes inside `data`

The current shape has a single field: a pre-rendered Markdown string. Each past turn becomes a `## Turn N` section with `**User**` and `**Assistant**` sub-headings, ordered from oldest to newest. If the turn was produced by a specific sub-agent, its name is appended to the section heading (e.g. `## Turn 2 (ance)`).

```markdown
# Conversation history

Previous conversation turns, ordered from oldest to newest.

## Turn 1

**User**

What products do I have on this tenant?

**Assistant**

You have ...

## Turn 2 (ance)

**User**

Open the first one.

**Assistant**

...
```

If the rendered Markdown plus the envelope wrapper exceeds the configured byte budget, the tail is trimmed and the string ends with the literal marker:

```text
[conversation history truncated]
```

Treat the value as **opaque human-readable text**. It is meant to be injected into another prompt or shown to a sub-model, not parsed for fields. The format may evolve under the same `version: "1"` if the change is additive (e.g. extra headings); structural breaks would bump the version.

## Reading it in your MCP

Three steps. History meta is optional, so your tool MUST work whether it is present or not.

**Step 1 — declare what you expect.** Define a Pydantic model for the subset of `data` your tool reads. Use `extra="ignore"` so the orchestrator can add fields without breaking your tool.

```python
from pydantic import BaseModel, ConfigDict


class HistoryData(BaseModel):
    model_config = ConfigDict(extra="ignore")
    conversation_history_md: str | None = None
```

**Step 2 — read `_meta.history` from the request context.** FastMCP exposes the request `_meta` via `ctx.request_context.meta`. The `history` key is an extra attribute on that model, sibling of `bindings`.

```python
from fastmcp import Context


@mcp.tool
async def my_tool(query: str, ctx: Context) -> ToolResult:
    meta = ctx.request_context.meta
    raw_envelope = getattr(meta, "history", None) if meta else None
    raw_data = (raw_envelope or {}).get("data") or {}
    history = HistoryData.model_validate(raw_data)
    ...
```

**Step 3 — degrade gracefully when history is absent.** Many flows do not set it: feature flag off, first exchange, memory service down. Treat absence as "no prior context" and behave exactly like a stateless tool would. Never raise on missing history.

```python
if not history.conversation_history_md:
    return await answer_without_context(query)
```

!!! tip "The value is a Markdown string, not a list"

    Do not try to JSON-parse `conversation_history_md` or to split it into turns with a regex. The format is designed to be pasted into an LLM prompt or shown to a sub-agent. If you need a structured per-turn view, call the memory service yourself with the session id you already have on the request.

!!! warning "Treat the tail as possibly truncated"

    If the rendered Markdown ends with `[conversation history truncated]`, the older turns are missing — never the most recent ones. Your tool should not assume the first `## Turn 1` in the string is actually the first turn of the session.

## How it relates to bindings

`_meta.history` and `_meta.bindings` are siblings under the same envelope discipline (versioned, strict shape, side-channel to the model, max-size enforced) but they are **not** interchangeable.

| Aspect          | `_meta.bindings`                                  | `_meta.history`                                       |
| --------------- | ------------------------------------------------- | ----------------------------------------------------- |
| Who sets it     | Chat client (in `RunRequest.bindings`)            | Orchestrator (server-owned, no client input)          |
| Purpose         | Deterministic application context (product, etc.) | Tactical recall of recent conversation turns          |
| Shape of `data` | Free-form JSON object agreed by client and MCP    | Single Markdown string under a known key              |
| Scope           | One run                                           | One run, sourced from the session's memory snapshot   |
| Optionality     | Optional per request                              | Optional per deployment (feature-flagged) and per run |
| Size cap        | 4 KB serialized                                   | Configurable via `MCP_HISTORY_META_MAX_BYTES`         |

If a tool needs *both* — for example, "use the bound product to scope retrieval, and reuse the previous turn to disambiguate the question" — it should read each independently and tolerate the absence of either.

## Common pitfalls

**Assuming history is always present.** It is gated by an orchestrator-level feature flag and by the memory pre-fetch succeeding with non-empty entries. A tool that crashes or returns degraded answers on missing history will be useless in any flow where the flag is off or the session is brand new. Default-handle absence in every tool that reads it.

**Parsing the Markdown.** The shape of the rendered string is an implementation detail of the orchestrator. Treat it as a string to be embedded into another prompt, not as a serialization format. If you need a structured per-turn API, query the memory service directly.

**Trying to set or extend `_meta.history` from the client.** The channel is server-owned. Anything the client sends under that name will be ignored (and may be rejected by future orchestrator versions). Use [bindings](bindings.md) for client-supplied context.

**Echoing the entire history back through the LLM.** The MCP is free to inject parts of the history into its own prompt for a sub-model, but blindly concatenating the Markdown into the tool's textual output that the orchestrator's model reads defeats the side-channel guarantee, doubles token cost, and risks looping the user's own words back into chat history.

**Confusing history meta with the model's chat history.** The main orchestrator model already sees the conversation through its standard memory injection (controlled by `PUT_HISTORY_IN_CONTEXT`). `_meta.history` is for **MCP tools**, which otherwise have no view of the conversation at all. Do not conflate the two.

## Related

- [`_meta` channels overview](index.md) — the shared envelope discipline and the full list of sibling channels.
- [Bindings](bindings.md) — the client-set sibling channel under `_meta.bindings`, used for deterministic application context.
- [Inline Components](../inline-components/index.md) — the opposite-direction `_meta` envelope, used by MCP tools to return structured payloads back to the chat UI.
