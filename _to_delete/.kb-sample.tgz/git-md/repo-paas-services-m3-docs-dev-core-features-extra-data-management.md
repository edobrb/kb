---
source_id: "git-md:repo-paas-services-m3-docs-dev-core-features-extra-data-management"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/paas/services/m3/docs/-/blob/1a1607cdd8d49c974e61c819cb0e4f2cb8a838ce/dev/core-features/extra-data-management.md"
title: Extra Data Management
authority: descriptive
version_hash: "sha256:603fd348570f2c272717f362795a245306b8fee55cbef74772922daadcf153f8"
body_hash: "sha256:603fd348570f2c272717f362795a245306b8fee55cbef74772922daadcf153f8"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:paas/services/m3/docs"
index_status: pending
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/paas/services/m3/docs/dev/core-features/extra-data-management.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Extra Data Management

The **extra data** (a.k.a. `details` on the webhook, `config`/`extraData` on the internal payloads) is a
`Map<String, String>` that Metering attaches to each Feature/service at activation time. It carries per-Feature
configuration: sub-capability switches, plant info, buyer/commercial context, and the Subscription constraints.

Two services build this map with **the same rules** but deliver it to **different destinations**:

| Service                       | Pipeline               | Stack           | Where the map lands                                                                                   |
| ----------------------------- | ---------------------- | --------------- | ----------------------------------------------------------------------------------------------------- |
| `metering-m3-invoker`         | M3 subscription        | Kotlin / Quarkus | `services[].config` of the M3 subscription payload (`POST`/`PATCH` to `m3-subscriptions-subscriber`) |
| `metering-services-activator` | legacy M1 activation   | Java / Spring   | `extraData` of the `EnableRequest` (Thrift) / `ServiceRestModelRequest` (Workspace REST) to the Feature |

Both read from the same Metering tables (`family_descriptor`, `service_descriptor`, `family_service` /
`service_extra_data`, `package_subscription`, `package_constraint`) and produce the same logical map. The map is
composed in layers:

```mermaid
flowchart LR
    A[Base configuration<br/>service_extra_data] --> B[Plant information<br/>plantId / plantDescription]
    B --> C[Feature-specific settings<br/>per-service handler]
    C --> D[Legacy information<br/>legacy family+service]
    D --> E[(Assembled extra data<br/>webhook details / M3 subscription config)]
```

1. **Base configuration** — static name/value pairs from `service_extra_data`, linked to the `family_service` row.
2. **Plant information** — `plantId`/`plantDescription` for multi-resource (plant) families, only when both are present.
3. **Feature-specific settings** — service-specific keys computed by the per-service handler.
4. **Legacy information** — extra commercial/buyer data for family+service pairs flagged as legacy.

---

# How to use it

This section covers the operations a developer performs against the extra-data mechanism. None of them, except
adding a brand-new handler, require code changes.

## Enable legacy enrichment for a family + service

Legacy enrichment is driven purely by the **presence of a row** in a dedicated table (no boolean flags on the
descriptor tables). Both services read from the **same table**, `legacy_family_service`, with composite primary
key `(family_id, service_id)`. To enable it for a pair, insert a row — it is picked up at the next activation,
no deploy needed:

```sql
INSERT INTO legacy_family_service (family_id, service_id) VALUES (:familyId, :serviceId);
```

> The insert is a single operation on the shared Metering DB — both `metering-m3-invoker` and
> `metering-services-activator` see it, so the legacy keys are added consistently on both pipelines.

## Change the static configuration of a service

The base map comes from `service_extra_data` (name/value), joined to the family through `family_service`. Add or
update rows there to change the default keys a service receives — again picked up at the next activation.

## Add a new per-service handler

A handler contributes the service-specific keys (layer 3). It must be added in **both** services:

- **`metering-m3-invoker`** — implement `ExtraDataHandler` (`domain/.../extradata/ExtraDataHandler.kt`):

  ```kotlin
  interface ExtraDataHandler {
      val type: List<String>   // service name(s) this handler serves (matched upper-cased)
      fun handle(
          packageSubscription: PackageSubscriptionDto,
          serviceName: String,
          extradata: MutableMap<String, String>?,
      ): Boolean               // false => base/plant/feature-specific keys are dropped for that
                               //          service (config emptied); legacy enrichment still runs
  }
  ```

  Then register it in the `handlerClasses` list of `ApplicationProducer.createServiceManager(...)`
  (`bootloader/.../ApplicationProducer.kt`), which registers each handler in the `ExtraDataHandlerRegistry` by
  every entry of its `type`.

- **`metering-services-activator`** — add a `case` to the `switch` in `ExtraDataManagerAdapter.resolve(...)`
  (`adapter/extradata/ExtraDataManagerAdapter.java`) and a matching `handleXxx(...)` private method returning
  the `shouldActivate` flag. Returning `false` here **skips the Feature activation entirely** for that service
  (see [Handler return semantics differ across services](#handler-return-semantics-differ-across-services)).

## Keys produced

### Feature-specific keys

| Feature (service name)                         | Keys                                                                                            |
| ---------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| `B2B-PASSIVE-FLOW`, `CRT`                      | `interop`                                                                                       |
| `SDI-FLOW`                                     | `fatturaSmart`, `interop`                                                                        |
| `ARC`                                          | `uploadFrontendActive`                                                                           |
| `SIGNATURE-FLOW`                               | `accounts`, `signatureTimestampEnabled`, `signatureFe`, `fsc`, `fga`, `frq`, `fra`, `fmq`        |
| `TSH-PMS`                                      | `enterprise`, `guestPortal`, `governingApp`, `domotics`, `HOAU`, `tsIntegrationHub`, `externalIntegrationHub` |
| `TSH-CM`                                       | `enterprise`                                                                                    |
| `MODE-CRAM`                                    | `personalisedAnalysis`, `esg`, `pro`, `base`, `light`                                            |
| `TS-CANTIERI-SICUREZZA`                        | `cantieriAccounts`                                                                              |
| `TS-DIREZIONE-PREV/CONT/COLL`                  | `cantieriPdl`                                                                                    |
| `CAF-SERVICE`                                  | `CAF_CASES`                                                                                       |
| `CS-SERVICE`                                   | `CS_CASES`                                                                                        |

### Legacy keys

| Key                                       | Source                                                     |
| ----------------------------------------- | ---------------------------------------------------------- |
| `zuoraId`                                 | `package_subscription.package_id` (external package id)    |
| `buyerEmail`, `buyerName`, `buyerSurname` | `package_subscription.buyer_*`                             |
| `trial`                                   | `family_descriptor.trial` (`"true"` / `"false"`)           |
| `constraints`                             | all `package_constraint` rows, serialized as a JSON string |

Every value is a **string**. `constraints` is a JSON-array **string** (not a nested object); both services emit the
same shape:

```json
[{"type":"AI_CREDIT","limit":100,"threshold":true},{"type":"INVOICES","limit":5,"threshold":false}]
```

`limit` is the constraint's `maximumQuantity`; `threshold` is its `absolute` flag.

---

# How it works technically

## metering-m3-invoker (Kotlin / Quarkus)

The map is built inside `ServiceManager.createServices()`, invoked by **both** `CreateSubscription` and
`UpdateSubscription` — so the enrichment applies to activation *and* update.

```mermaid
flowchart TD
    UC[CreateSubscription / UpdateSubscription] --> SM[ServiceManager.createServices]
    SM -->|per catalog service| EDM[ExtraDataManager.manageExtraData]
    EDM --> REG{ExtraDataHandlerRegistry<br/>getHandler serviceName}
    REG -->|handler found| H[Handler.handle -> mutates config]
    REG -->|no handler| KEEP[keep config as-is]
    SM -->|after building all services| LEG[LegacyExtraDataManager.enrich]
    LEG --> REP[(LegacyFamilyServiceRepositoryPort<br/>findByFamilyId)]
    REP -->|empty| RET[return services unchanged]
    REP -->|rows| PUT[putAll legacy keys on matching services]
    SM --> MAP[SubscriptionMapper.toServiceRequest]
    MAP --> OUT[POST/PATCH m3-subscriptions-subscriber]
```

### Steps

1. **Build services** — `ServiceManager.createServices(packageSubscription, catalogServices, familyServices)`
   maps each catalog service to a `ServiceDto(name, config)`, seeding `config` from the `service_extra_data`
   entries of the matching `family_service`.
2. **Per-service handler** — for each service `ExtraDataManager.manageExtraData(serviceName, packageSubscription,
   extradata)` first calls `Utils.addExtraDataMultiPackageResource(...)` (adds `plantId`/`plantDescription` for
   `tshFamilies`), then looks up a handler in `ExtraDataHandlerRegistry` by upper-cased service name. If a handler
   is found it runs `handle(...)`, which mutates the `config` map and returns a boolean; **`false` clears the
   base + plant + feature-specific keys for that service** (`ServiceManager` returns an empty map). The service
   is still kept in the list — legacy enrichment runs next (step 3) and can repopulate the config with legacy
   keys if the service is part of the family's `legacy_family_service` set. With no handler the service is kept
   as-is.
3. **Legacy enrichment** — after all services are built, `LegacyExtraDataManager.enrich(packageSubscription,
   services)`:
   1. `legacyFamilyServiceRepository.findByFamilyId(familyDescriptor.id)` — returns the configured legacy service
      names for the family; if empty, returns the services unchanged.
   2. Reads the constraints via `packageConstraintRepository.findConstraints(packageSubscription.id)`.
   3. Builds the legacy map (`zuoraId`, `buyerEmail`/`buyerName`/`buyerSurname` — each omitted when null —,
      `trial` from `familyDescriptor.trial`, and `constraints`), then `putAll`s it onto the `config` of **only**
      the services whose name is in the configured set.
   4. `constraints` is built by hand: `[{"type":"…","limit":<maximumQuantity>,"threshold":<absolute>}, …]`.
4. **Output** — `SubscriptionMapper.toServiceRequest` copies `ServiceDto.config` into `ServiceRequest.config`
   (`HashMap<String, Any>`); the request is sent to `m3-subscriptions-subscriber`.

### Code locations

| Role                        | File                                                                          |
| --------------------------- | ----------------------------------------------------------------------------- |
| Orchestration               | `domain/.../domain/ServiceManager.kt`                                         |
| Per-service manager         | `domain/.../domain/extradata/ExtraDataManager.kt`                             |
| Handler interface           | `domain/.../domain/extradata/ExtraDataHandler.kt`                            |
| Handler registry            | `domain/.../domain/extradata/ExtraDataHandlerRegistry.kt`                    |
| Handlers                    | `domain/.../domain/extradata/services/*.kt` (Arc, SdiFlow, B2bPassiveFlowCrt, SignatureFlow, TshPms, TshCm, ModeCram) |
| Plant helper                | `domain/.../domain/extradata/Utils.kt`                                        |
| Legacy manager              | `domain/.../domain/extradata/LegacyExtraDataManager.kt`                      |
| Legacy port                 | `ports/.../outgoing/LegacyFamilyServiceRepositoryPort.kt`                    |
| Legacy repository           | `adapters/storage/.../repository/LegacyFamilyServiceRepository.kt`          |
| Legacy entity / id          | `adapters/storage/.../entities/LegacyFamilyService.kt`, `LegacyFamilyServiceId.kt` |
| Legacy DTO                  | `ports/.../dto/LegacyFamilyServiceDto.kt`                                    |
| Output mapper               | `adapters/rest/.../subscriber/model/SubscriptionMapper.kt`                   |
| Wiring                      | `bootloader/.../bootloader/ApplicationProducer.kt` (`createServiceManager`)  |

## metering-services-activator (Java / Spring)

The map is resolved by `ExtraDataManagerAdapter.resolve(ServiceExtraDataContext)` (implementing
`ExtraDataManagerPort`), called from `PackageCreatedStrategy` during activation.

```mermaid
flowchart TD
    S[PackageCreatedStrategy.enableService] --> CTX[build ServiceExtraDataContext]
    CTX --> R[ExtraDataManagerAdapter.resolve]
    R --> MP[addExtraDataMultiPackageResource]
    MP --> LG[addLegacyExtraData]
    LG --> LM{LegacyManager.isLegacy<br/>row in legacy_family_service?}
    LM -->|yes| ADD[put zuoraId/buyer/trial/constraints<br/>nulls skipped]
    LM -->|no| SKIP[skip legacy enrichment]
    LG --> SW{switch serviceName}
    SW --> HND[handleXxx -> mutate extraData, return shouldActivate]
    HND --> RES[ExtraDataResolution shouldActivate, extraData]
    RES -->|shouldActivate| SET[request.setExtraData]
    SET --> OUT[EnableRequest Thrift / ServiceRestModelRequest REST]
```

### Steps

1. **Context** — `PackageCreatedStrategy` builds a `ServiceExtraDataContext` (serviceName, packageId, ownerId,
   itemId, familyName, plantId, plantDescription, correlationId, and the seed `extraData` from
   `service_extra_data`).
2. **Plant info** — `addExtraDataMultiPackageResource(...)` adds `plantId`/`plantDescription` when the family is in
   `Utils.multiPackageResourceFamilies` and both values are present.
3. **Legacy enrichment** — `addLegacyExtraData(...)`:
   1. `legacyManager.isLegacy(serviceName, familyName)` — resolves the `service_id`/`family_id` and checks for a
      row in `legacy_family_service` (same table used by `metering-m3-invoker`).
   2. If legacy: loads the subscription, `constraintAdapter.getAllBySubscription(id)` returns
      `List<SubscriptionConstraint>` — the **domain record** `SubscriptionConstraint(type, limit, threshold)`
      mapped from the JPA entity (`maximumQuantity → limit`, `absolute → threshold`) — which
      `objectMapper.writeValueAsString(...)` serializes to the `constraints` string.
   3. Puts `zuoraId` (`subscription.packageId`), `buyerEmail`, `buyerSurname`, `buyerName` — each **only when
      non-null** (Thrift's `writeString` NPEs on null map values) — plus `trial` (`familyDescriptor.trial`,
      defaulting to `"false"` if null) and `constraints`.
4. **Per-service handler** — a `switch` on the upper-cased service name dispatches to `handleBDG`,
   `handleB2bPassiveFlowOrCrt`, `handleSdiFlow`, `handleArc`, `handleSignatureFlow`, `handleTshPms`, `handleTshCm`,
   `handleModeCram`, `handleCantierSic`, `handleCantierDir`, `handleCaf`, `handleCentroServizi` (default `true`).
   Each mutates `extraData` and returns whether activation should proceed.
5. **Result & output** — `resolve` returns `ExtraDataResolution(shouldActivate, extraData)`. If `shouldActivate`,
   `PackageCreatedStrategy` sets it on the request, which `StrategyUtils` builds as an `EnableRequest` (Thrift, by
   item) or `ServiceRestModelRequest` (REST, by workspace) sent to the Feature.

### Code locations

| Role                        | File                                                                     |
| --------------------------- | ------------------------------------------------------------------------ |
| Resolver + handlers         | `adapter/extradata/ExtraDataManagerAdapter.java`                         |
| Resolver port               | `domain/port/ExtraDataManagerPort.java`                                  |
| Legacy detection            | `adapter/extradata/LegacyManager.java` / `domain/port/LegacyManagerPort.java` |
| Context DTO                 | `domain/dto/ServiceExtraDataContext.java`                                |
| Resolution model            | `domain/model/ExtraDataResolution.java`                                  |
| Constraint domain record    | `domain/model/SubscriptionConstraint.java`                               |
| Constraint adapter          | `adapter/repository/ConstraintAdapter.java`                              |
| Legacy entity / id          | `adapter/repository/entity/LegacyFamilyService.java`, `LegacyFamilyServiceId.java` |
| Legacy repository           | `adapter/repository/jpa/LegacyServiceRepository.java`                    |
| Static config entities      | `adapter/repository/entity/FamilyService.java`, `ServiceExtraData.java`  |
| Activation strategy         | `server/strategy/PackageCreatedStrategy.java`                            |
| Payload builders            | `adapter/utils/StrategyUtils.java` (`buildEnableRequest`, `buildServiceRestModelRequest`) |

## Consistency notes

- **Same table** — both services read from **`legacy_family_service`** with composite primary key
  `(family_id, service_id)` and use the entity class `LegacyFamilyService` + composite id
  `LegacyFamilyServiceId`. Enabling a legacy pair is a single insert on the shared Metering DB and takes effect
  on both pipelines at the next activation.
- **Same rules, different destination** — the layering and legacy logic are equivalent; only the transport
  differs (`m3-invoker` → M3 subscription config, consumed internally by M3's Subscription/Service Manager;
  `activator` → Feature webhook `details`/`extraData`).
- **Constraints shape is identical** — both emit `type` / `limit` / `threshold`. `m3-invoker` builds the string
  by hand; `activator` maps the JPA entity to the `SubscriptionConstraint(type, limit, threshold)` record before
  Jackson serialization, so the field names match.
- **Different implementation of the same rules** — internal naming and pattern differ (registry vs. switch,
  handler classes vs. private methods, repository/manager class names), but the emitted keys and their sources
  are the same.

### Handler return semantics differ across services

The per-service handler's boolean return has **different semantics** on each side. This is intentional — the two
services have different downstream consumers — but it is a real behavioural difference to be aware of:

- **`metering-services-activator`** — if a handler returns `shouldActivate = false`, `PackageCreatedStrategy`
  **skips the Feature activation entirely** for that service (the Thrift/REST `enable` call is not made). This
  gives the activator a per-service **veto** on activation, based on the resolved extra data.
- **`metering-m3-invoker`** — if a handler returns `false`, the service is **still emitted** in the M3
  subscription. Its base + plant + feature-specific keys are dropped (the `config` is emptied), **but legacy
  enrichment still runs on top afterwards** — so if the service is configured as legacy for that family in
  `legacy_family_service`, its `config` will be repopulated with the legacy keys (`zuoraId`, `buyer*`, `trial`,
  `constraints`) and shipped that way. There is no true veto on the M3 side: skipping a service from the M3
  Subscription is not a concept there, because the downstream is M3's own Subscription/Service Manager (not a
  Feature webhook).

If you add a handler that must gate activation, that gating is only meaningful on the activator side.
