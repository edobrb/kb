---
source_id: "git-md:repo-tsdigital-core-connections-docs-docs-api"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/core/connections/docs/-/blob/45946c6e02c66995ea2371159fba99f163d6c348/docs/api.md"
title: API
authority: descriptive
version_hash: "sha256:a3579ccb3647ef107d8669a2a852481a53ace0ab680aed9765416c9015865393"
body_hash: "sha256:95c7fa0b504ec93219d5c9a2d00798e7629e61be37f7612d4501d7314c4a12d9"
lang: und
source_langs: [und]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/core/connections/docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/core/connections/docs/docs/api.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# API

## Endpoint di lettura

### API Base Url:

dev: https://connection-read-dev.agyo.io/api

test: https://connection-read-test.agyo.io/api

prod: https://connection-read.agyo.io/api

### Swagger:

https://connection-read-test.agyo.io/swagger-ui.html

## Endpoint di scrittura

### API Base Url:

dev: https://connection-write-dev.agyo.io/api

test: https://connection-write-test.agyo.io/api

prod: https://connection-write.agyo.io/api

### Swagger:

https://connection-write-test.agyo.io/swagger-ui.html

## Endpoint lettura notifiche

### Swagger

-   **dev:** https://notification-read-dev.agyo.io/swagger-ui.html
-   **test:** https://notification-read-test.agyo.io/swagger-ui.html

### Base URL

-   **dev:** `https://notification-read-dev.agyo.io`
-   **test:** `https://notification-read-test.agyo.io`
-   **dev:** `https://notification-read.agyo.io`

## Endpoint di scrittura notifiche

### Swagger

-   **dev:** https://notification-write-dev.agyo.io/swagger-ui.html
-   **test:** https://notification-write-test.agyo.io/swagger-ui.html

### Base URL

-   **dev:** `https://notification-write-dev.agyo.io`
-   **test:** `https://notification-write-test.agyo.io`
-   **dev:** `https://notification-write.agyo.io`
