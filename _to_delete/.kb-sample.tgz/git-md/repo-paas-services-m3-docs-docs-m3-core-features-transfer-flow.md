---
source_id: "git-md:repo-paas-services-m3-docs-docs-m3-core-features-transfer-flow"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/paas/services/m3/docs/-/blob/1a1607cdd8d49c974e61c819cb0e4f2cb8a838ce/docs/m3/core-features/transfer-flow.md"
title: Transfer Flow
authority: descriptive
version_hash: "sha256:88d4445956be66c397579cad0e3c0042c4166f9209de521f8114400fccf98b39"
body_hash: "sha256:88d4445956be66c397579cad0e3c0042c4166f9209de521f8114400fccf98b39"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:paas/services/m3/docs"
index_status: pending
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/paas/services/m3/docs/docs/m3/core-features/transfer-flow.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Transfer Flow

The **transfer** flow moves subscriptions — called _packages_ on the M1/metering side (see the [glossary](../getting-started/glossary.md)) — together with their slots, from an old company to a new one. The diagram below shows the end-to-end flow across the services involved.

```mermaid
flowchart TD
    Client([backoffice]) -->|POST /companies/transfer| MS[METERING-SERVICE]
    MS -->|HTTP| MPW[METERING-PACKAGE-WRITE]
    MPW -->|persist new owner & slots| MDB[(metering)]

    MPW -->|PACKAGE_TRANSFER on b2btopic| MSA[METERING-SERVICE-ACTIVATOR]
    MSA -->|old services → readonly<br/>new services → enable| M1[M1 service activation]

    MPW -->|notify| INV[M3-INVOKER]
    INV --> SUB[M3-SUBSCRIPTIONS-SUBSCRIBER]
    SUB -->|Dapr pub/sub| WRK[M3-SUBSCRIPTIONS-WORKER]
    WRK -->|change sub owner| SMDB[(m3 subscription manager)]
    WRK -->|TRANSFER_SLOTS<br/>if slots present| PROD[M3-CONSUMPTIONS-PRODUCER]
    PROD -->|change slots owner| SSDB[(m3 smartmeter)]

    classDef client fill:#ffcdd2,stroke:#c62828,color:#b71c1c;
    classDef m1 fill:#c8e6c9,stroke:#2e7d32,color:#1b5e20;
    classDef m3 fill:#bbdefb,stroke:#1565c0,color:#0d47a1;

    class Client client;
    class MS,MPW,MDB,MSA,M1 m1;
    class INV,SUB,WRK,SMDB,PROD,SSDB m3;
```

## Flow Description

The **`metering-service`** is the entry point of the whole flow: the transfer is triggered by a single call to it, and everything else happens automatically as a consequence.

On the **M1** side, the transfer reassigns the packages to the new company and updates the corresponding service activations: the old owner's services and slots are moved to _readonly_, while the new owner's ones are (re)activated.

The same change is then **propagated to M3**, where the subscriptions — and the slots attached to them, if any — follow the new owner as well.

# How to Perform a Transfer

A transfer is triggered by a single call to the **`metering-service`** API. Everything downstream — package write, M1 service activation, M3 subscriptions and slots — happens automatically as a consequence of that call.

## Trigger the transfer

|                |                                  |
| -------------- | -------------------------------- |
| **Method**     | `POST`                           |
| **Path**       | `/api/v1/companies/transfer`     |
| **Service**    | `metering-service`               |
| **Permission** | `METERING / postCompanyTransfer` |

### Required headers

| Header          | Description                                        |
| --------------- | -------------------------------------------------- |
| `Authorization` | Bearer JWT token used to authenticate the request. |
| `AppName`       | Name of the calling application.                   |
| `X-Request-ID`  | Request identifier (used for end-to-end tracing).  |

### Request body

Provide the fiscal code and VAT number of both the old and the new company:

```json
{
	"oldCompany": {
		"fiscalCode": "string",
		"vatNumber": "string"
	},
	"newCompany": {
		"fiscalCode": "string",
		"vatNumber": "string"
	}
}
```

- `oldCompany` — source company the subscriptions are transferred **from**.
- `newCompany` — destination company that will receive the subscriptions.

Companies are resolved by fiscal code + VAT number (with a fallback to fiscal code only for _PERSON_ registries). Both companies must already exist, and the new company must have an associated `bbsId`.

### Responses

| Status            | Meaning                                                             |
| ----------------- | ------------------------------------------------------------------- |
| `200 OK`          | Transfer accepted. Returns the `Company` object of the new company. |
| `400 Bad Request` | Error while processing the transfer.                                |
| `403 Forbidden`   | The caller does not hold the `postCompanyTransfer` permission.      |
| `404 Not found`   | Old/new company not found.                                          |
| `422 U. Content`  | `bbsId` missing on the new company.                                 |

## What happens under the hood

The entry call is **synchronous** only up to the package write step; the rest of the flow is **event-driven and asynchronous**, so the effects on services and slots settle shortly after the API responds.

1. **`metering-service`** validates the request, resolves both companies, and delegates the actual work downstream. It does **not** touch registry/master data.
2. **`metering-package-write`** reassigns the non-expired packages and their slots to the new company in a single transaction, then emits two events:
   - one towards the **M1** branch (service activation);
   - one towards the **M3** branch (subscriptions).
     If anything fails while persisting or enqueuing, the whole transaction rolls back — no partial transfer is left behind.
3. The **M1** branch moves the old owner's services to _readonly_ and (re)activates the new owner's ones.
4. The **M3** branch changes the subscription owner and, if the subscriptions have slots, reassigns those slots to the new company.

Every hop propagates a `correlationId` / `X-Request-ID`, so a single transfer can be traced end-to-end across all the services.

## Side effects

- **Subscriptions**: non-expired subscriptions of the old company are reassigned to the new company. On the M1/metering side they are called _packages_. Shared subscriptions are updated too, but only the owner's own subscriptions drive the downstream events.
- **Slots**: all slots of the transferred subscriptions are reassigned to the new company, regardless of their state (free, locked, cooldown).
- **M1 services**: the old owner's services become _readonly_; the new owner's services are (re)activated.
- **No master data is moved**: company/registry information stays untouched — only subscriptions and their slots follow the new owner.

## Q&A

**Does the transfer move company/registry data?**
No. It only reassigns subscriptions and their slots. The companies themselves are left as they are.

**Is the operation synchronous?**
The API call returns as soon as the package write step is accepted. The M1 and M3 effects are processed asynchronously via events, so they complete a short time later.

**What happens to expired subscriptions?**
They are not transferred. Only non-expired subscriptions (packages) follow the new owner.

**What if the old company has no subscriptions?**
There is nothing to transfer; the downstream branches simply do nothing.

**Is it safe to retry a transfer?**
Yes. Downstream events are retried on transient failures and dead-lettered only after repeated errors, and the slot transfer is idempotent. Re-running an already-completed transfer is effectively a no-op, since the source no longer owns the subscriptions/slots.

**Why did I get a `422 Conflict`?**
The new company has no associated `bbsId`. Make sure both companies exist and the destination is fully set up before retrying.

**Can I trace a transfer across services?**
Yes. Pass an `X-Request-ID`; it is propagated together with a `correlationId` through every service involved in the flow.
