---
source_id: "git-md:repo-tsdigital-core-registry-docs-docs-developers-read-flows-find-items"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/core/registry/docs/-/blob/dd12fa9ace30e514bd895fe5406701978cb14293/docs/developers/read-flows/find-items.md"
title: Find Items API
authority: descriptive
version_hash: "sha256:230cce42cd25619ed1a4e1d4d5741afdb0742e0cca1ba2e6f0b6dfd0e0e88fd4"
body_hash: "sha256:230cce42cd25619ed1a4e1d4d5741afdb0742e0cca1ba2e6f0b6dfd0e0e88fd4"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/core/registry/docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/core/registry/docs/docs/developers/read-flows/find-items.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Find Items API

The Find Items API can be used to search for items that match a specific list of criteria.

All requests to this API are paginated, unless the `unpaged` parameter is set to `true`.

## API Endpoint

### REST

- `GET /v3/items`

### Thrift

On the thrift side, the functionality was actually split into two different methods:

- `myItems` to search for items on which the requesting user has some form of permission
- `listItems` to search for items given a list of IDs
- `findItems` to perform a global search for items matching the provided criteria

All of these were available in the older Thrift version of the Registry Read service under the endpoints:

- `/thrift/v2/binary`
- `/thrift/v2/json`
- `/thrift/v3/binary`
- `/thrift/v3/json`

## Flows

As this API was, much like the rest of our older APIs, designed around the Thrift model, there are multiple different flows depending on the type of search being performed. These flows are identified by the name of the corresponding Thrift method.

### My Items Flow

This flow is used if the request parameter `userId` is provided **and** corresponds to a valid identifier of the requesting user (a valid identifier can be any one of: `email`, `id`, `tsid`).

#### Used filters

This flow only considers the following filters, if provided:

- `fullText.keyWord`: a string that is searched for fullText search in multiple fields of the item (`taxId`, `vatNumber`, `description`, `firstName`, `lastName`). This match is performed as a case-insensitive `LIKE %value%` search.
- `fullText.classifiers`: a comma-separated list of classifiers. Only items that have at least one of the provided classifiers are returned.

#### Flow Graph

```mermaid
flowchart TD

A((START))-->B{Is userId \nvalid?}
B--No -->FORBIDDEN(403 Forbidden)
B--Yes -->C{Are the search\nparameters valid?}
C--No -->BADREQUEST(400 Bad Request)
C--Yes -->D[Retrieve user permissions]
D-->E{User has no items?}
E--Yes -->MT[200 OK \n -- empty list]
E--No -->F[Perform DB Query]
F-->G[Build Response]
G-->RESPONSE[200 OK]
```

### List Items Flow

This flow is used if the request parameter `idList` is provided and **none** of the `identifier.*` or `fullText.*` parameters are provided.

This flow only accepts up to 1000 IDs in the `idList` parameter. If more than 1000 IDs are provided, a 400 Bad Request is returned. This restriction is lifted for `BACKOFFICE` and `M2M` users.

#### Used filters

- `idList`: a comma-separated list of item IDs (UUIDs) to search for. Required for regular users, optional for `BACKOFFICE` and `M2M` users.

#### Flow Graph

```mermaid
flowchart TD

A((START))-->B{IdList provided?}
B--No -->C{BO or M2M user?}
C--No -->FORBIDDEN(403 Forbidden)
C--Yes -->LIST_ALL[Fetch every item]
B--Yes -->D{IdList size \nover 1000?}
D--Yes -->E[Validated IDs]
E-->F[Fetch items with provided IDs]
F-->END((Return items))
D--No -->BAD_REQUEST(400 Bad Request)
LIST_ALL-->END
```

### Find Items Flow

This flow is used in any case not covered by the previous flows.

#### Used filters

- All `identifier.*` parameters
- All `fullText.*` parameters

At least one of the above filters must be provided for the request to be considered valid.

#### Flow Graph

```mermaid
flowchart TD

A((START))-->B{At least one filter \nprovided?}
B--No -->BADREQUEST(400 Bad Request)
B--Yes -->C{Are the search\nparameters valid?}
C--No -->BADREQUEST
C--Yes -->D{FullText.keyWord filters provided?}
D--Yes -->F{Is exact search?}
F--No -->E{Is M2M/BO user?}
F--Yes -->G[Perform exact search]
E--Yes -->H[Perform FullText search]
E--No -->BADREQUEST
D--No -->I{Identifier filters provided?}
I--Yes -->J[Perform Identifier search]
I--No -->BADREQUEST
```

#### Exact Search

This search is performed when the `fullText.keyWord` parameter is provided and its value matches the format of a valid `taxId` or `vatNumber` for the `IT` region. In this case, the search looks for an item whose `taxId` and/or `vatNumber` match the provided `fullText.keyWord`.

#### Identifier Search

This search is performed when `identifier.taxRegion` is provided in addition to `identifier.taxId`, `identifier.vatNumber` or both. In this case, the search looks for items that match all of the provided `identifier` filters.

#### FullText Search

This search is performed when the `fullText.keyWord` parameter is provided and its value does not match the format of a valid `taxId` or `vatNumber` for the `IT` region. In this case, the search looks for items that match the provided fullText keyword in multiple fields (`taxId`, `vatNumber`, `description`, `firstName`, `lastName`).

This operation can only be performed by `BACKOFFICE` and `M2M` users.

## Hidden items

Some items may specify that they want to be `hidden`. Such items act as non-existent to users that are not authorized to see them.

In this API, hidden items that the user cannot see are excluded from the results of the search.
