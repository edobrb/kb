---
source_id: "git-md:repo-oneplatform-tsdataplatform-data-governance-ts-dataplatform-datagovernance-documentation-docs-data-product-lifecycle"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/-/blob/256aaa023d7a1968e3a84c8985dae5a7c2db39ff/docs/data-product-lifecycle.md"
title: Data Product Lifecycle
authority: descriptive
version_hash: "sha256:e06dcc78405dc1c205def2b00250e2dd6995c8adb1f8221635f1e7b9de8bb9c3"
body_hash: "sha256:e49927a1bea3655d742836753964c6d992a317567fafd33eeaed696c4a100d21"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/docs/data-product-lifecycle.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Data Product Lifecycle

The data product will follow this stages:

* **Needed**

In this phase, Data Products are identified as potential solutions to detected needs or opportunities. An initial high-level definition of the contents is created, including a preliminary assessment of their relevance and the opportunities they might offer. Additionally, both functional and technical ownerships for each Data Product are identified.

* **Analyzing**

Here, the process of modeling the domain associated with the Data Product begins, either for integration into the platform or to meet specific business needs. The Business Domain Owner, together with the Governance team, models the business process, identifying the main entities involved. Semantics are defined, including the creation of a glossary and ontology, along with a description of the relationships between the various elements. The ontology census is then performed using Blindata.

* **Designing**

In this phase, the Data Product Development Team, composed of domain experts and, in the case of onboarding, members of the Enablement team, analyzes the available data to identify relevant events and entities. From this analysis, the team produces the JSON schema that describes the structure of the Data Product.

* **Approving**

The Governance team reviews and revises the work carried out by the Data Product Dev Team, ensuring that everything complies with the established standards and requirements. If everything is in order, the team approves the development of the Data Product, giving the go-ahead for the next phases.

* **Developing**

The Data Product Dev Team defines and compiles the "Data Product Descriptor," which includes the related metadata and mapping with the concepts defined in the ontology. Subsequently, the Data Product is registered on ODM (Open Data Mesh) through a push into the appropriate repository. A notification service publishes the registration event, and a Blindata observer distributes the census metadata. Meanwhile, the necessary flows to implement the defined logic and deployment pipelines are developed. The team then deploys the Data Product in the development environment (DEV) by invoking a specific ODM API to execute a stage defined in the descriptor. The notification service publishes the deployment event.

* **Testing**

In this phase, thorough and rigorous tests are conducted on the functionalities implemented in the development environment (DEV) to ensure that everything works as expected and that the Data Product meets the established requirements.

* **Deploying**

Once the tests are passed, the Data Product is deployed into the production environment. This marks the completion of the development cycle and the beginning of the operational phase of the Data Product, making it available for use by end consumers.

* **Done**

## Documents

In the steps described above, it is necessary to produce a series of documents in order to share the information required for the Data Governance team to create the Data Product Catalog. Below is a list of the documents that must be produced.

### Data Product Canvas

It is a high-level, human-readable descriptive document that is compiled during the identification phase of the Data Products to be developed, and it contains a series of key information:

* Data Product Name
* Associated Domain
* Data Product Owner
* Status
* Purpose
* Input Interfaces (Input Ports)
* Output Interfaces (Output Ports)
* Applied Business Logic
* Data Product Classification (Source/Consumer)
* The Business Case driving its creation
* Additional notes, such as possible constraints and limitations regarding the applicability of certain global policies.


![](./images/data_product_canvas.png)


### Data Product Descriptor

This second document, on the other hand, represents the most detailed, machine-readable description of the Data Product's characteristics. This specification document is what the platform needs to manage the operational aspects of the Data Product's lifecycle, from catalog registration to deployment in production environments. The specification used to describe the Data Product is an open specification managed by the initiative [Open Data Mesh][1].

In order to support the development of the Minimum Viable Platform, described in the following chapters, a subset of the entities constituting the Data Product Descriptor has been chosen to be activated. The Minimum Viable Descriptor includes what is shown in the following image.

![](./images/data_product_descriptor.jpg) 



[1]: https://dpds.opendatamesh.org/specifications/dpds/
[2]: https://biosphere.teamsystem.com/oneplatform/tsdataplatform/blueprints/data-products/ts-dataplatform-template-dpd
[3]: https://biosphere.teamsystem.com/oneplatform/tsdataplatform/blueprints/data-products/ts-dataplatform-consumer-blueprint/-/blob/prod/.gitlab-ci.yml?ref_type=heads
