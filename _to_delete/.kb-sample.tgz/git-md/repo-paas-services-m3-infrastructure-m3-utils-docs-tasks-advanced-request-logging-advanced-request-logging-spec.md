---
source_id: "git-md:repo-paas-services-m3-infrastructure-m3-utils-docs-tasks-advanced-request-logging-advanced-request-logging-spec"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/paas/services/m3/infrastructure/m3-utils/-/blob/82e5240fca782cae4294e21f89fa0962fb763778/docs/tasks/advanced-request-logging/advanced-request-logging.spec.md"
title: Feature Specification – Advanced Request Logging (MDC)
authority: descriptive
version_hash: "sha256:ae0bbc8874368059c8b43ce75b065c81330c6f33d00b52a84d9182fc50e36832"
body_hash: "sha256:ae0bbc8874368059c8b43ce75b065c81330c6f33d00b52a84d9182fc50e36832"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:paas/services/m3/infrastructure/m3-utils"
index_status: pending
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/paas/services/m3/infrastructure/m3-utils/docs/tasks/advanced-request-logging/advanced-request-logging.spec.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Feature Specification – Advanced Request Logging (MDC)

## Context

Introduce an advanced request logging capability in the m3-utils extension so that every HTTP request handled by microservices using this extension enriches logs with a standardized MDC context and enforces the presence of specific headers. The mechanism must capture the fully qualified resource method name and correlate requests across services via provided identifiers. If required headers are missing, the system must respond with an error and prevent the resource method from executing.

## Assumptions

- Consuming services are HTTP-based microservices.
- Header names are case-insensitive per HTTP standards; values are trimmed and whitespace-only is treated as empty.
- MDC is a request-scoped key/value context attached to logs; it must be set before any application log of the resource method and cleared after the request completes.
- The value for `action` is the fully qualified resource method name in the form `className.method`.
- Error responses for missing/empty headers use HTTP 400 Bad Request.
- Error response JSON format is `{ "code": number, "type": string, "message": string }`.

## Functional Requirements

1. Header Validation (Pre-Execution)

   - Inputs: HTTP request headers.
   - Required headers (must be present and non-empty after trimming):
     - `X-App-Name`
     - `X-App-Version`
     - `X-Correlation-ID`
     - `X-Request-ID`
   - Behavior:
     - Validate presence and non-empty values for all required headers before invoking any resource method logic.
     - If one or more required headers are missing/empty, abort request processing, do not execute the resource method, and return an error response.
     - When multiple headers are missing/empty, the response must report all missing headers.
   - Outputs (on validation failure):
     - HTTP status: 400.
     - Body (application/json): `{ code: 400, type: <exception name>, message: <error text> }`.
       - `type`: name of the exception used by the implementation (e.g., `MissingHeaderException` or `BadRequestException`).
       - `message`: a single string listing all missing fields using the template `$field is required`, concatenated by `; ` in a deterministic order: `X-App-Name`, `X-App-Version`, `X-Correlation-ID`, `X-Request-ID`.
         - Example: "X-App-Name is required; X-Request-ID is required".

2. MDC Context Injection

   - Inputs: Validated headers and the target resource method metadata.
   - Behavior:
     - Populate MDC with the following keys and values for the duration of the request:
       - `action`: fully qualified method name `className.method` of the invoked resource handler.
       - `app_name`: value from header `X-App-Name`.
       - `app_version`: value from header `X-App-Version`.
       - `request_id`: value from header `X-Request-ID`.
       - `correlation_id`: value from header `X-Correlation-ID`.
     - Ensure MDC is set prior to any application logs emitted by the resource method and cleared afterward, including for error and cancellation paths.
   - Outputs:
     - Logs emitted during request handling include the MDC keys above.

3. Execution Control

   - If validation passes, proceed with resource method execution; otherwise, the method MUST NOT be invoked.
   - The logging mechanism should be transparent to the business logic, requiring no changes in resource methods.

4. Error Handling and Reporting

   - For missing/empty headers, produce a JSON error response `{ code, type, message }` with status 400.
   - When multiple headers are missing/empty, the `message` must report all missing fields using `$field is required` joined by `; ` in deterministic order.

5. Observability and Configuration
   - MDC keys are fixed and documented; consuming services can configure their logging formatter to include MDC fields.
   - No runtime configuration is necessary to enable header validation; the feature is ON by default when the extension is included.

## Non-Functional Requirements

- Performance: Minimal overhead; header validation and MDC setting should target sub-millisecond per request in typical environments.
- Thread Safety: MDC operations must be safe under concurrent load; do not leak MDC across threads or requests.
- Async Propagation: MDC values must remain available across the entire lifecycle of a single request, including any asynchronous operations, continuations, or context switches performed while handling the request.
- Correctness: MDC MUST be cleared at the end of request processing, including error, timeout, or canceled paths.
- Security: Do not log sensitive data beyond the specified headers and method name; sanitize or bound values to prevent log injection where applicable.
- Reliability: The mechanism must operate consistently across synchronous and reactive/async request execution models.
- Compatibility: Should not require changes in consuming resource method signatures; operate as a request interceptor/filter.

## Data Models / Schemas

Error Response Schema:
{
"type": "object",
"properties": {
"code": { "type": "integer", "enum": [400] },
"type": { "type": "string", "description": "Exception name (e.g., MissingHeaderException)" },
"message": {
"type": "string",
"description": "Error text. If multiple headers are missing, messages are concatenated with '; ' in deterministic order.",
"examples": [
"X-App-Name is required",
"X-App-Name is required; X-Request-ID is required"
]
}
},
"required": ["code", "type", "message"],
"additionalProperties": false
}

MDC Context Schema (conceptual representation for logging context):
{
"type": "object",
"properties": {
"action": { "type": "string", "description": "Invoked resource method name" },
"app_name": { "type": "string", "description": "From header X-App-Name" },
"app_version": { "type": "string", "description": "From header X-App-Version" },
"request_id": { "type": "string", "description": "From header X-Request-ID" },
"correlation_id": { "type": "string", "description": "From header X-Correlation-ID" }
},
"required": ["action", "app_name", "app_version", "request_id", "correlation_id"],
"additionalProperties": true
}

## Validation & Testability

- Unit tests:
  - Validate that requests missing each required header return 400 and the `message` contains `$field is required` for that header.
  - Validate that when multiple headers are missing, `message` lists all missing using `; `, in the specified order.
  - Validate MDC contains all keys with correct values for successful requests and is cleared after completion.
  - Validate that MDC remains available across asynchronous processing segments within the same request.
- Integration tests:
  - Verify logs produced during a request include the MDC keys when using a formatter that outputs MDC.
  - Verify the resource method is not executed when headers are invalid (e.g., via a flag or spy).

## Open Questions

- None.
