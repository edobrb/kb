---
source_id: "git-md:repo-tsdigital-oneplatform-ai-cowork-docs-ai-platform-docs-docs-ts-ai-and-orchestrator-zero-trust"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/-/blob/6c617371f851e6ffa24e0fe0c27751375233fdb5/docs/ts-ai-and-orchestrator/zero-trust.md"
title: Zero trust
authority: descriptive
version_hash: "sha256:c0fcd9c2431d0204bb76a62485fb656cbb253b2dd897685c48a13fddcde3ce7b"
body_hash: "sha256:c0fcd9c2431d0204bb76a62485fb656cbb253b2dd897685c48a13fddcde3ce7b"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/docs/ts-ai-and-orchestrator/zero-trust.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Zero trust

!!! warning "Work in Progress"

    This page is under active development. Content may be incomplete or subject to change.

This page explains the **zero-trust** posture from the **orchestrator's point of view**: what the runtime does — and deliberately does *not* do — when it calls a tool. The server-side requirements (token validation, workspace-scoped authorization, the authentication middleware, the registration checklist) are documented once in the MCP section; this page only clarifies where the orchestrator's responsibility ends and yours begins.

## What the orchestrator does

When the runtime calls a tool, it **propagates identity faithfully** and nothing more: it forwards the `Authorization: Bearer` token and the platform metadata headers (`X-User-ID`, `X-Workspace-ID`, and the correlation/conversation/assistant identifiers) verbatim from the originating request. See [Request headers and identity](headers.md) for the exact set.

!!! important "Visibility cones live in the MCP, not the orchestrator"

    Workspace scoping and metering/policy — the **visibility cones** that decide *what each caller can actually reach* — are enforced **inside your MCP server**, not at the orchestrator level. The orchestrator only **propagates** identity; it does not filter, scope, or block calls on your behalf. Deciding what a given user and workspace may see is your server's responsibility.

## What your MCP server must do

Everything the server is expected to enforce — validating the bearer token before running a tool, rejecting requests missing required identity headers, scoping authorization to the workspace claims, and hardcoding no secrets — is covered in the MCP section. Start with the blueprint's `AuthenticationMiddleware` rather than rolling your own:

- [Building an MCP Server](../genai-platform/mcp/building-mcp-server.md#authentication) — the authentication middleware and what it enforces
- [Release process of an MCP Server](../genai-platform/mcp/deploying-mcp-server.md#security-and-zero-trust) — security, zero trust, and required headers
- [Registering an MCP Server](../genai-platform/mcp/registering-mcp-server.md) — the zero-trust checklist at registration time
