---
source_id: "git-md:repo-oneplatform-tsdataplatform-data-governance-ts-dataplatform-datagovernance-documentation-docs-groups"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/-/blob/256aaa023d7a1968e3a84c8985dae5a7c2db39ff/docs/groups.md"
title: Groups guidelines
authority: descriptive
version_hash: "sha256:1db49e07d7ec68979bc509edb68449fea52ad695759e337e702d6a32fb529be8"
body_hash: "sha256:17c4e0f705a4fd0236c669a1a4f631a647ebb9b9104a03ffa70b23fe997d8eba"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/docs/groups.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Groups guidelines

We are managing data access through Azure Entra ID groups, rather than assigning permissions to individual users. This approach ensures better scalability, security, and operational efficiency by reducing the risks associated with manual, user-specific authorizations. 

For any doubts or problems, please check the [FAQ section](faq.md). 


### Compliance audit
__Be aware that groups may be subject to audits by the Data Protection Officer and Compliance team.__  The owner is accountable and responsible to add and remove members accordingly to the access provided to the group. 

## Create your EntraID group

Create a group with a name that describes your role or team via [Azure Portal](https://portal.azure.com/#view/Microsoft_AAD_IAM/GroupsManagementMenuBlade/~/Overview): here, click on "New Group" and compile the form.

**NOTE**: Group type **must be "Security"** and Membership type must be "Assigned". 

You should provide a name for the group and a description following the guidelines below:

### Description
Provide a description of the group, explaining the team that it's representing. __The description must include "#witboost" in order to be syncronize in the Marketplace__. For example: _"This group contains Data Scientists of the Micro Solutions Data & Business Analysis unit. #witboost"._

### Team indication
We will ask you to indicate the Team in the name of the group: it is recommended to use __precise and descriptive naming__ when defining your Team. For example, avoid generic labels such as just "_Professional_" or "_Enterprise_", as those are BU that encompass a wide range of teams. Instead, provide a more specific designation, such as "_Enterprise-Analysis&Test_". You can refer to the team name in TS organizational chart.

### Data Producer 
Each team will have the following __4 groups__:

- `[Team][Domain]DataEngineersDev`/ `[Team][Domain]DataEngineersDemo` / `[Team][Domain]DataEngineersTest` / `[Team][Domain]DataEngineersProd`: these groups contain developers who can read and modify data. These groups will include the dedicated Enablement Data Engineers, and potentially business users if they have the required skills to operate on the Platform

The Data Product Owner is the owner of the above groups. 

__For new domains, these groups will be created by the Platform team during the creation of the domain subscription. If the domain already exists, the new team will create autonomously and provide them to their dedicated Data Engineer.__  

**DP development.** You need to be assigned the `DP_DEVELOPER` role in Witboost by Data Platform team if you need __to develop your Data Products__. You can ask via the [help channel](help.md).

### Data Consumer
Anyone who wants access to a dataset must create a dedicated EntraID group, named by BU and Role, following this naming convention:

- `[Team][Role]Dev` / `[Team][Role]Demo` / `[Team][Role]Test` / `[Team][Role]Prod`

Examples of __roles__ may include: 

- "Analysts": if you are part of a business and you want to explore data for business analytics goals

- "BIEngineers": if you are a BI developer and you will build dashboards and reports using the data

- "AIEngineers" or "AIScientist": if you are a AI developer and you will use the data to build AI use cases ( models, agents, ...)

The [Team] definition must follow the guidelines above. 

This group can be used to request access to all necessary Data Products for the team.

### Group members

Define the Owners and Members of the group.  One or more __group owners must be defined__, __responsible__ for ensuring that __only authorized members are included inside the group__. The owner will decide who should be added to the group. __Every member will inherit all the permission given to the group__. 

**NOTE**: **only members will receive the permissions** given to the group, not the owners. If a owners also need the permissions, they must be also members. 

### Databricks groups

Azure groups are automatically synchronized with Databricks groups. If you create an Azure group, a corresponding Databricks group with the same name is created, and the members will be the same in Databricks as defined in Azure.

Nested groups are supported in Databricks as well. If you add an Azure group as a member of another Azure group, the corresponding Databricks groups will also reflect this nesting. This allows for more complex permission structures and easier management of access rights across both platforms. For example, if you have an Azure group called "SalesAnalyticsBIEngineersDev" and you add it as a member of another Azure group called "SalesAnalyticsTeam", the corresponding Databricks groups will reflect this nesting. Members of "SalesAnalyticsBIEngineersDev" will thereby receive the same permissions in Databricks as those granted to "SalesAnalyticsTeam".

!!! warning "The Databricks group **NEEDS TO BE ACTIVATED** via a first usage in Databricks. This means that after creating the Azure group, you need to use it at least once in Databricks (for example, by adding it to a workspace) to ensure that the corresponding Databricks group is usable for the ACL requests in Witboost."

## Examples

**Scenario**: I want to request access on the Marketplace for my team. My team is call "Sales Analytics" and we build dashboards for our business unit. 
I will create four groups as follows:

- Names: **SalesAnalyticsBIEngineersDev**, **SalesAnalyticsBIEngineersDemo**, **SalesAnalyticsBIEngineersTest** and **SalesAnalyticsBIEngineersProd**
- Description: "This group contains BI developers from the "Sales Analytics" team. #witboost"
- Owners&Members: who creates the group is owner, but other owners can be added. All and only the required people from that team will be added as member.

**Scenario**: My team "HR Solutions Analytics" wants to develop new Data Products on a pre-existing domain "HRS". 
I will create two groups as follows:

- Names: **HRSolutionsAnalyticsHRSDataEngineersDev**, **HRSolutionsAnalyticsHRSDataEngineersDemo**, **HRSolutionsAnalyticsHRSDataEngineersTest** and **HRSolutionsAnalyticsHRSDataEngineersProd**
- Description: "This group contains DP developers from the "HR Solutions Analytics" team in the HRS domain. #witboost"
- Owners&Members: who creates the group is owner, but other owners can be added. Add all the members that will develop the Data Products (including your dedicated Data Engineer from the Enablement team, if you have one). **Attention: the people inside this group will be able to create and modify code and data.**
