---
source_id: "git-md:repo-oneplatform-pet-developer-portal-documentation-teamsystem-id-docs-developer-guide-revocation-endpoint"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/PET/developer-portal/documentation/teamsystem-id/-/blob/efd562b907329be3427ff46fc51373ad99b77195/docs/developer_guide/revocation_endpoint.md"
title: Revocation Endpoint
authority: descriptive
version_hash: "sha256:2714b135e89f91f9b9b274d7ac50dd514e960e26b37a3c9d6698e35654300b33"
body_hash: "sha256:2714b135e89f91f9b9b274d7ac50dd514e960e26b37a3c9d6698e35654300b33"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/PET/developer-portal/documentation/teamsystem-id"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/PET/developer-portal/documentation/teamsystem-id/docs/developer_guide/revocation_endpoint.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Revocation Endpoint

The revocation endpoint can be used by clients to notify the authorization server that a previously obtained token (access token (**only reference type**) or refresh token) is no longer needed. This is useful for scenarios where a client wants to ensure that a token is invalidated before its natural expiration time, such as when a user logs out or when a client application is uninstalled.

### Parameters
The revocation endpoint accepts the following parameters via a POST request with `application/x-www-form-urlencoded` content type:
- `token` (required): The token that the client wants to revoke. This can be either an access token (**only reference type**) or a refresh token.
- `token_type_hint` (optional): A hint about the type of the token being submitted for revocation. This can be either `access_token` or `refresh_token`. Providing this hint can help the authorization server to optimize the revocation process, but it is not mandatory.

### Example

```shell
curl --request POST \
  --url 'https://identity-stage.teamsystem.com/connect/revocation' \
  --header 'content-type: application/x-www-form-urlencoded' \
  --data 'token=<ACCESS_TOKEN>' \
  --data 'token_type_hint=access_token'
```

In case of a refresh token, the request would look like this:

```shell
curl --request POST \
  --url 'https://identity-stage.teamsystem.com/connect/revocation' \
  --header 'content-type: application/x-www-form-urlencoded' \
  --data 'token=<REFRESH_TOKEN>' \
  --data 'token_type_hint=refresh_token'
```

The client makes a POST request to the revocation endpoint with the required parameters. If the token is successfully revoked, the authorization server will respond with HTTP status code 200 (OK). If the token is invalid or has already been revoked, the server will still respond with HTTP status code 200, as per the OAuth 2.0 Token Revocation specification.

### Security Considerations

A malicious client may attempt to guess valid tokens on this endpoint by making revocation requests against potential token strings.
According to this specification, a client's request must contain a valid client_id, in the case of a public client, or valid client credentials, in the case of a confidential client.

### References
- [OAuth 2.0 Token Revocation (RFC 7009)](https://datatracker.ietf.org/doc/html/rfc7009)
- [OAuth 2.0 (RFC 6749)](https://datatracker.ietf.org/doc/html/rfc6749)
