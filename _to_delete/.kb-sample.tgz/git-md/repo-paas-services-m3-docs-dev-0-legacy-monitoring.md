---
source_id: "git-md:repo-paas-services-m3-docs-dev-0-legacy-monitoring"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/paas/services/m3/docs/-/blob/1a1607cdd8d49c974e61c819cb0e4f2cb8a838ce/dev/0-legacy/monitoring.md"
title: M3 — Monitoring & Observability
authority: descriptive
version_hash: "sha256:0607c78ab48fd82635f8fd18eb49ed1fe75103e5babc35022221dfae29fa75cf"
body_hash: "sha256:9f5b3ba1f8b6b1ac036cc193b2097cbeadc54d885b336e75ee8631470c9ffd14"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:paas/services/m3/docs"
index_status: pending
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/paas/services/m3/docs/dev/0-legacy/monitoring.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# M3 — Monitoring & Observability

> **Purpose:** Define the monitoring, logging, alerting, and observability standards for all M3 microservices. Every service deployed to production **must** comply with these requirements.
>
> **Last updated:** 2026-02-13

---

## Table of Contents

- [1. Health & Readiness Endpoints](#1-health--readiness-endpoints)
- [2. Structured Logging](#2-structured-logging)
- [3. Metrics](#3-metrics)
- [4. Distributed Tracing & Correlation](#4-distributed-tracing--correlation)
- [5. Centralized Log Management — ELK Stack](#5-centralized-log-management--elk-stack)
- [6. Alerting](#6-alerting)
- [7. Elasticsearch Watcher Guidelines](#7-elasticsearch-watcher-guidelines)
- [8. Dashboard Hygiene](#8-dashboard-hygiene)
- [9. Service Level Objectives (SLOs)](#9-service-level-objectives-slos)
- [10. Incident Response Tiers](#10-incident-response-tiers)
- [11. Dead Letter Queue (DLQ) Monitoring](#11-dead-letter-queue-dlq-monitoring)

---

## 1. Health & Readiness Endpoints

Every M3 service **must** expose the following Quarkus health endpoints:

| Endpoint | Purpose | Expected response |
|---|---|---|
| `/q/health` | Overall health check (liveness + readiness) | HTTP `200` with `"status": "UP"` |
| `/q/health/live` | Liveness probe — is the process alive? | HTTP `200` |
| `/q/health/ready` | Readiness probe — can it accept traffic? (DB connected, Dapr ready) | HTTP `200` |
| `/q/info` | Service metadata: version, build time, git commit SHA, environment | HTTP `200` with JSON payload |

> **Kubernetes integration:** Liveness and readiness probes in the deployment manifest must point to these endpoints.

---

## 2. Structured Logging

### 2.1 Format

All logs **must** be emitted in **structured JSON format** to enable automated parsing and analysis.

### 2.2 Required Fields

Every log entry **must** include the following fields:

| Field | Description | Example |
|---|---|---|
| `timestamp` | ISO 8601 UTC timestamp | `2026-02-12T10:30:00.123Z` |
| `level` | Log level: `TRACE`, `DEBUG`, `INFO`, `WARN`, `ERROR` | `ERROR` |
| `service` | Service name (from configuration) | `m3-smartmeter` |
| `correlationId` | Request/message correlation ID for end-to-end tracing | `req-abc-123` |
| `environment` | Deployment environment | `prod`, `test`, `dev` |
| `message` | Human-readable log message | `Failed to process consumption event` |
| `logger` | Fully qualified class name | `c.t.m3.smartmeter.adapter.in.messaging.ConsumptionConsumer` |

### 2.3 Log Level Guidelines

| Level | When to use |
|---|---|
| `ERROR` | Unrecoverable failures, exceptions that require investigation |
| `WARN` | Recoverable issues, business rule violations (discarded messages), degraded behaviour |
| `INFO` | Significant business events: message processed, subscription created, service status changed |
| `DEBUG` | Detailed diagnostic information — disabled in production by default |
| `TRACE` | Very fine-grained debugging — never enabled in production |

### 2.4 Sensitive Data

**Never log** personally identifiable information (PII), secrets, tokens, or connection strings. Mask or omit sensitive fields.

---

## 3. Metrics

Every service **must** emit metrics using **Micrometer** (built into Quarkus).

### Key Metrics to Expose

| Metric | Type | Description |
|---|---|---|
| `http_server_requests` | Timer | Latency and throughput for REST endpoints |
| `message_received_total` | Counter | Total messages received per topic/queue |
| `message_processed_total` | Counter | Successfully processed messages |
| `message_failed_total` | Counter | Failed message processing (retried or dead-lettered) |
| `db_query_duration` | Timer | Database query latency |
| `circuit_breaker_state` | Gauge | Current state of circuit breakers (`CLOSED`, `OPEN`, `HALF_OPEN`) |
| `outbox_pending_messages` | Gauge | Number of messages pending in the outbox table |

### Custom Metrics

When adding business-specific metrics, follow this naming convention:

```
m3_{service}_{domain_concept}_{metric_type}
```

Example: `m3_smartmeter_consumptions_processed_total`

---

## 4. Distributed Tracing & Correlation

| Requirement | Details |
|---|---|
| **Correlation ID propagation** | The `correlationId` **must** be propagated through all synchronous (HTTP) and asynchronous (Service Bus) calls to enable end-to-end tracing. |
| **Header name** | Use `X-Correlation-Id` for HTTP headers and `correlationId` as a Service Bus message property. |
| **Generation** | If an incoming request has no correlation ID, the first service in the chain **must** generate a UUID and attach it. |
| **Logging** | Every log entry **must** include the correlation ID (see [Section 2.2](#22-required-fields)). |

---

## 5. Centralized Log Management — ELK Stack

| Item | Value |
|---|---|
| **Platform** | [Helk (ELK Stack)](https://helk.ts-paas.com/s/oneplatform/app/home#/) — Elasticsearch, Logstash, Kibana |
| **Data view** | `oneplatform-m3-*` |
| **Retention** | Follows the platform-wide retention policy — verify with the SRE team |

### How to Search Logs

1. Open the [Helk Kibana dashboard](https://helk.ts-paas.com/s/oneplatform/app/home#/).
2. Select the `oneplatform-m3-*` data view.
3. Filter by:
   - `service.keyword`: the specific service name (e.g., `m3-smartmeter`)
   - `environment.keyword`: `prod`, `test`, or `dev`
   - `correlationId.keyword`: for end-to-end request tracing
   - `level.keyword`: `ERROR` or `WARN` for issue investigation

---

## 6. Alerting

### 6.1 Principles

| Principle | Description |
|---|---|
| **Actionable** | Every alert must have a clear action: who investigates, what to check, and how to remediate. |
| **Contextual** | Alerts must provide enough information to start diagnosis without further searching. |
| **Tuned** | Avoid alert fatigue. Use appropriate thresholds, aggregation windows, and deduplication. |
| **Documented** | Every alert must have a linked runbook or escalation procedure. |

### 6.2 Alert Configuration Standards

| Setting | Guideline |
|---|---|
| **Thresholds** | Define clear thresholds relative to normal behaviour (e.g., error rate > 5% over 5 minutes). |
| **Notification channel** | All production alerts **must** be published to the [M3 Alerts — MS Teams channel](https://teams.microsoft.com/l/channel/19%3Aed40e398fd5842aca923c98dba82b184%40thread.tacv2/%5BMetering%5D%20M3%20-%20Alerts?groupId=19dab4c8-4410-41c8-aee6-0ff1574ed608&tenantId=bb364f09-07cf-4eca-9b92-1f26a92d5f3f&ngc=true). |
| **Escalation** | When an alert fires, investigate the root cause. Notify the PO and the team with findings. |
| **Review cadence** | Periodically (at least monthly) review all dashboards and alerts to ensure relevance. |

---

## 7. Elasticsearch Watcher Guidelines

Use **Elasticsearch Watcher** to monitor critical events across M3 services. All watchers must follow these standards.

### 7.1 Naming & Scheduling

| Setting | Standard | Example |
|---|---|---|
| **Watcher name** | `m3-{error-type}` | `m3-tombstone-errors`, `m3-duplicate-events` |
| **Daily reports** | Run at 07:00 UTC — `0 0 7 * * ?` | — |
| **Critical alerts** | 15 min to 1 hour intervals | — |
| **Environment filter** | **Always** filter by environment (`prod`, `test`, `dev`) | — |

### 7.2 Time Windows

| Alert type | Window |
|---|---|
| Daily reports | Last 24 hours |
| Critical / real-time alerts | 15 minutes to 1 hour |
| Trend analysis | 7–30 days |

### 7.3 Trigger Configuration

**Required query filters:**

- Application name (e.g., `m3-consumptions-relay`)
- Log level (`ERROR`, `WARN`, `INFO`)
- Environment (`prod` for production alerts)
- Specific error message patterns (regex or keyword match)

**Threshold guidelines:**

- Set clear count thresholds (e.g., ≥ 1 occurrence, > 5 occurrences).
- Account for normal service behaviour to avoid false positives.
- Use aggregation to prevent alert spam.

### 7.4 Alert Format — MS Teams

All production watcher notifications sent to MS Teams **must** follow this template:

```
🚨 Production Alert! @channel
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Service:     {service-name}
Error:       {error-type-description}
Count:       {count} occurrences in last {time-window}
Environment: {env}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 [View logs in Helk] → {direct-filtered-link-to-oneplatform-m3-*}
📋 Runbook: {link-to-runbook-or-escalation-doc}
```

### 7.5 File Organization & Deployment

| Item | Standard |
|---|---|
| Config directory | `es-watcher/` in the infrastructure repository |
| Filename convention | `m3-{error-type}.json` (e.g., `m3-tombstone-errors.json`) |
| Deployment | Auto-deployed via CI/CD pipeline |

### 7.6 Documentation per Watcher

For each watcher, create a companion section or document covering:

- **Business impact:** What goes wrong if this alert is ignored?
- **Detection goal:** What specific failure does this watcher detect?
- **Response actions:** Step-by-step remediation instructions.
- **Escalation:** Who to contact if the issue cannot be resolved within the team.

### 7.7 New Watcher Checklist

Before deploying a new watcher, verify:

- [ ] Name follows convention: `m3-{error-type}`
- [ ] Environment filtering is configured
- [ ] Schedule and thresholds are appropriate
- [ ] MS Teams notification follows the standard template
- [ ] Helk links are functional and correctly filtered
- [ ] Tested in a non-production environment first
- [ ] Documentation includes response procedures and runbook link

---

## 8. Dashboard Hygiene

| Practice | Cadence |
|---|---|
| Review all Kibana dashboards for relevance and accuracy | Monthly |
| Verify alert thresholds against current traffic patterns | After each major release |
| Remove or archive obsolete watchers and dashboards | Quarterly |
| Validate Helk data view `oneplatform-m3-*` includes all services | When a new service is deployed |

---

## 9. Service Level Objectives (SLOs)

Every M3 service **must** define and track SLOs. These are the measurable reliability targets that the team commits to.

### 9.1 Standard SLOs

| SLO | SLI (Measurement) | Target | Window |
|---|---|---|---|
| **Availability** | `(successful_requests / total_requests) × 100` | ≥ 99.9% | 30 days rolling |
| **Latency (p50)** | 50th percentile HTTP response time | ≤ 100ms | 30 days rolling |
| **Latency (p99)** | 99th percentile HTTP response time | ≤ 500ms | 30 days rolling |
| **Message Processing** | `(messages_processed / messages_received) × 100` | ≥ 99.95% | 30 days rolling |
| **Error Rate** | `(5xx_responses / total_responses) × 100` | ≤ 0.1% | 30 days rolling |

### 9.2 Error Budget

- Each SLO has an **error budget** = `100% - target`. For 99.9% availability, the error budget is 0.1% (~43 minutes/month).
- When the error budget is exhausted: **freeze feature releases** and focus exclusively on reliability improvements.
- The tech lead and PO jointly decide when to resume feature work.

### 9.3 SLO Review

| Review | Cadence | Participants |
|---|---|---|
| SLO dashboard review | Weekly (sprint review) | Dev team |
| Error budget review | Monthly | Tech lead + PO |
| SLO target adjustment | Quarterly | Full team |

---

## 10. Incident Response Tiers

| Tier | Criteria | Response Time | Escalation |
|---|---|---|---|
| 🔴 **P1 — Critical** | Production outage, data loss risk, >50% of users affected | ≤ 15 minutes | Immediate: on-call dev → tech lead → PO. All hands if not resolved in 30 min. |
| 🟠 **P2 — High** | Degraded performance, single service down, <50% of users affected | ≤ 1 hour | On-call dev investigates. Escalate to tech lead if not resolved in 2 hours. |
| 🟡 **P3 — Medium** | Non-critical feature broken, workaround available | ≤ 4 hours | Create Jira ticket, schedule for next sprint. |
| 🟢 **P4 — Low** | Cosmetic issue, minor logging noise, non-impacting | Next business day | Create Jira ticket, prioritize in backlog. |

### Post-Incident Process

1. **Stabilize** — Fix the immediate issue
2. **Communicate** — Update MS Teams Alerts channel with status
3. **Investigate** — Root cause analysis within 48 hours
4. **Document** — Write a post-mortem (blameless) and link to the Jira ticket
5. **Prevent** — Create follow-up tickets for systemic fixes, add/update watchers

---

## 11. Dead Letter Queue (DLQ) Monitoring

Every Service Bus queue and topic subscription has a DLQ. Messages landing in a DLQ indicate processing failures that exceeded the retry limit.

### 11.1 DLQ Monitoring Rules

| Rule | Details |
|---|---|
| **Watcher required** | Every DLQ **must** have an Elasticsearch Watcher alerting when messages arrive. |
| **Alert threshold** | ≥ 1 message in DLQ → alert immediately. DLQ messages are always abnormal. |
| **Inspection process** | Use [Service Bus Explorer](https://github.com/paolosalvatori/ServiceBusExplorer) or Azure Portal to inspect DLQ messages. |
| **Resolution** | Investigate root cause → fix consumer → reprocess messages (or discard with documented reason). |
| **Metrics** | Emit `m3_{service}_dlq_messages_total` counter per queue/subscription. |

### 11.2 DLQ Alert Template

```
⚠️ Dead Letter Alert! @channel
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Service:     {service-name}
Queue/Topic: {queue-or-subscription-name}
DLQ Count:   {count} new messages
Environment: {env}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 [View in Azure Portal] → {direct-link}
📋 Runbook: {link-to-dlq-runbook}
```
