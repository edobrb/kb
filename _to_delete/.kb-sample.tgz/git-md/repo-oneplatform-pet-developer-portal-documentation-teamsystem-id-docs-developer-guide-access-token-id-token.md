---
source_id: "git-md:repo-oneplatform-pet-developer-portal-documentation-teamsystem-id-docs-developer-guide-access-token-id-token"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/PET/developer-portal/documentation/teamsystem-id/-/blob/efd562b907329be3427ff46fc51373ad99b77195/docs/developer_guide/access_token_id_token.md"
title: Access Token and ID Token
authority: descriptive
version_hash: "sha256:25424aa9293a2be60a17a41c0fd21deb14649b8ac70885d4bf20d345880627a7"
body_hash: "sha256:ad2e28b377fa0c4772191c8169f8babf4e510c192ef6de28b67f4740857d1c6a"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/PET/developer-portal/documentation/teamsystem-id"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/PET/developer-portal/documentation/teamsystem-id/docs/developer_guide/access_token_id_token.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Access Token and ID Token

### Access Token

Access tokens are the thing that applications use to make API requests on behalf of a user. The access token represents the authorization of a specific application to access specific parts of a user’s data.

An Access token contains information about the user, permissions, groups, and timeframes is embedded within one token that passes from a server to a user's device.

A typical access token holds three distinct parts, all working together to verify a user's right to access a resource.

Three key elements are included in most access tokens.

1. **Header:** Data about the token's type and the algorithm used to make it are included here.
2. **Payload:** Information about the user, including permissions and expirations, is included here.
3. **Signature:** Verification data, so the recipient can ensure the authenticity of the token, is included here. This signature is typically hashed, so it's difficult to hack and replicate.

>To learn more, refer to the site [JWT Introduction](https://jwt.io/introduction)

### ID Token

ID tokens are used in token-based authentication to cache user profile information and provide it to a client application, thereby providing better performance and experience. The application receives an ID token after a user successfully authenticates, then consumes the ID token and extracts user information from it, which it can then use to personalize the user's experience.

ID tokens follow the JSON Web Token (JWT) standard, which means that their basic structure conforms to the typical JWT Structure, and they contain standard JWT Claims asserted about the token itself, just like the **access token.**

**To obtain an access_token and id_token issued by TSID v3 by logging in from this test application (only from the TeamSystem internal network) [Stage Client](https://tsid-client-stage.teamsystem.com/)**
