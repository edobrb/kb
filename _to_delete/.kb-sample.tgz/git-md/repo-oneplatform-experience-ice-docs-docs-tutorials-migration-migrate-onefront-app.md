---
source_id: "git-md:repo-oneplatform-experience-ice-docs-docs-tutorials-migration-migrate-onefront-app"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/experience/ice-docs/-/blob/10bdeb3c4dad03814c044fb1991c730779659a29/docs/tutorials/migration/migrate-onefront-app.md"
title: "TUTORIAL: How to migrate an OneFront Application"
authority: descriptive
version_hash: "sha256:065a9d5e891b94219c4596f0b744a58553a8ca93f6f014d1273ab3c92fba7ab2"
body_hash: "sha256:065a9d5e891b94219c4596f0b744a58553a8ca93f6f014d1273ab3c92fba7ab2"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/experience/ice-docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/experience/ice-docs/docs/tutorials/migration/migrate-onefront-app.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# TUTORIAL: How to migrate an OneFront Application

This tutorial will teach you how to migrate an existing OneFront App to the new module-based OnePlatform. The migration process is simple and consists of a few steps. We are going to use the `coffee-in-cloud` app as an example.

## The `coffee-in-cloud` app

The `coffee-in-cloud` is built on top of `@1f/react-starter-sdk` and is used to manage a coffee shop/bar through 3 main pages:

- **POS**: a page that lets users manage orders and payments
- **Products**: a page that lets users manage products and categories  
- **Settings**: a page that lets users manage the app settings

### Step 1: `src/main.tsx`

Since the app is built on top of `@1f/react-starter-sdk` it will have something like this:

```ts
import { OneBox } from "@1f/react-starter-sdk";
import { PosPage } from "./pages/pos";
import { ProductsPage } from "./pages/products";
import { SettingsPage } from "./pages/products";

OneBox.run({
    settings: {
        // [...]
    },
    features: {
        // [...]
        {
            target: "$ONE_LAYOUT_ROUTE",
            handler: {
                path: "/",
                component: PosPage,
            },
        },
        {
            target: "$ONE_LAYOUT_ROUTE",
            handler: {
                path: "/admin/products",
                component: ProductsPage,
            },
        },
        {
            target: "$ONE_LAYOUT_ROUTE",
            handler: {
                path: "/admin/settings",
                component: SettingsPage,
            },
        },
        // [...]
    },
})
```

For this tutorial and to keep the code short, we put all the features definition in the above example code, but in a real app you probably have them in different files/folders and just import them. What really matters to us here is the `path` prop of the `handler` object when the `target` is `$ONE_LAYOUT_ROUTE`.

### Step 2: Create an `appConfig.ts` file inside the src

Move all the logic that you have in `src/main.tsx` here.

``` ts
import { PosPage } from "./pages/pos";
import { ProductsPage } from "./pages/products";
import { SettingsPage } from "./pages/products";

export const appConfig = {
     settings: {
        // [...]
    },
    features: {
        // [...]
        {
            target: "$ONE_LAYOUT_ROUTE",
            handler: {
                path: "/",
                component: PosPage,
            },
        },
        {
            target: "$ONE_LAYOUT_ROUTE",
            handler: {
                path: "/admin/products",
                component: ProductsPage,
            },
        },
        {
            target: "$ONE_LAYOUT_ROUTE",
            handler: {
                path: "/admin/settings",
                component: SettingsPage,
            },
        },
        // [...]
    },
}
```

Now your `src/main.tsx` should look like this:

``` ts
import { OneBox } from '@1f/react-starter-sdk'
import { appConfig } from './appConfig'

OneBox.run(appConfig).catch(console.error);
```

### Step 3: `remote-config.tsx`

1. Inside the `src` folder create a file `remote-config.tsx` and add all the configuration of your application that you want to expose as a remote config there

2. Add this line to your `.npmrc`:

    ``` shell
    @ice:registry=https://nexus.ts-paas.com/repository/ts-platform-npm/
    //nexus.ts-paas.com/repository/ts-platform-npm/:_authToken=${NEXUS_TOKEN_HERE}
    ```

3. Make sure you have these packages installed: `@module-federation/vite`, `@ice/react` and `@ice/compat-onefront`

Example below:

``` ts
import { remoteConfiguration } from '@ice/compat-onefront'
import { appConfig } from './appConfig'

const federationConfig = {
  ...appConfig,
  settings: {
    ...appConfig.settings,
    one: {
      ...appConfig.settings.one,
      rest: {
        proxy: {
          baseUrl: '/proxy',
        },
      },
    },
  },
}

export default remoteConfiguration({
    component: federationConfig
});

```

### Step 4: `vite.config.ts`

Now because we want to migrate the app to the new module-based OnePlatform, we need to change how we define the features. The new way is to use the `@ice/react`'s `remoteConfiguration` function that will let us expose the app as a Federated Module.
We won't go into the details of how to use `@ice/react`'s `remoteConfiguration` function, so we will assume that we already have a `vite.config.ts` file that is configured to expose the app as a Federated Module and it looks like this:

```ts
import { federation } from "@module-federation/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
 base: "./", // this configuration is needed to load all the assets of the project
 plugins: [
  react(),
  federation({
   name: "notification",
   filename: "remoteEntry.js",
   exposes: {
    "./remote-config": "./src/remote-config.tsx",
   },
  }),
 ],
 /* [...] */
});
```

### Step 5: Run and Test Your Application

Your application will be available at:
- **Local development**: `http://localhost:{port}`
- **Module Federation entry**: `http://localhost:{port}/remoteEntry.js`

To check that your business capability is properly exposed:

1. Open your browser and navigate to `http://localhost:{port}/remoteEntry.js`
2. You should see the Module Federation manifest
