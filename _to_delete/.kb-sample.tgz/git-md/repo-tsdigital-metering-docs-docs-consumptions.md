---
source_id: "git-md:repo-tsdigital-metering-docs-docs-consumptions"
source_type: git-md
duplicate_of: git-md:repo-paas-services-m3-docs-docs-metering-consumptions
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/metering/docs/-/blob/dea2f3652460ac7331dc5ba60bd80268f4daa476/docs/consumptions.md"
title: Gestione consumi
authority: descriptive
version_hash: "sha256:58087eff4993f08c1969c0a90e2390831f34fa9644a271c4fbfba2bd12174acf"
glossary_version: terms-bc11a0714e4d
translated_at: 2026-07-31T23:10:01Z
translation_workflow: claude-code/renormalize
translation_model: claude-opus-5
translated_from: {path: "raw/repo/paas/services/m3/docs/docs/metering/consumptions.md", version_hash: "sha256:58087eff4993f08c1969c0a90e2390831f34fa9644a271c4fbfba2bd12174acf"}
admission: refused
admission_rule: duplicate_of
admission_reason: "exact duplicate of the already-admitted canonical git-md:repo-paas-services-m3-docs-docs-metering-consumptions — elected by the duplicate detector, consumed here, not re-decided"
admission_model: rule:screen-admission@1
admission_at: 2026-07-29T22:11:01Z
body_hash: sha256:90b51841d2c84d8fc26a1a85d9087bdddea0bfb21de626d0a9afd0509b7890e9
lang: en
source_langs: [it]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/metering/docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/metering/docs/docs/consumptions.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---

# Consumption management

## Introduction

Consumptions fall into two categories: synchronous consumptions and asynchronous consumptions.
The former are consumptions organized into slots (privacy treatments, signature certificates, ecobonus dossiers, etc.) that must be present for the user to be able to use the service correctly.
The latter are consumptions that do not need to be counted in real time.
Every consumption is directly associated with the id of the package it belongs to. 

Creating a slot requires that it first be locked (LOCKED state), and consequently committed (USED state).
A slot can be put into the COOLDOWN state to make it possible to avoid the company associated with that slot being removed in order to use it on another company. A slot in the COOLDOWN state will become reusable again after 6 months. 
 
asynchronous consumptions are dequeued by a subscriber of a topic on a bus. For the management of asynchronous consumptions the following are considered: 
- the weight of the consumption: the value for counting the consumptions of a package 
- the credits: a credit can be associated with a package, and it is taken into account every time a consumption associated with a package is saved 
- exemption: at the moment only for invoicing, it makes it possible to make an item id exempt from a certain flow

## As is

### Architecture

![architettura](images/usage-architecture.png)

### usage-broker

The service exposes the various APIs for managing slots.  
It makes it possible to: 

- [Create the slot](https://metering-usage-broker-test.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/slots-controller/postSlots) putting it into the LOCKED state. To create a slot it is necessary to specify the owner of the package, the constraint on which to perform the consumption, any details of the consumption, the service feature and the resourceId of the package. The resourceId is mandatory only in the case where the service feature field is set to `TSH`, otherwise it is optional. As output of the service there are the id of the slot just created and its initial state.

Example of service input

    {
        "owner": "RSSGPP89H52B519X",
        "item": "RSSGPP89H52B519X",
        "constraint": "LOW_VALUE_FILES",
        "serviceFeature": "NIUMABONUS",
        "resourceId": null,
        "details": [
            
        ]
    }

Example of service output

    {
        "id": 166098,
        "status": "LOCKED"
    }


- [Confirm the slot](https://metering-usage-broker-test.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/slots-controller/postSlotsCommits) putting it into the USED state. It is enough simply to specify the identifier of the slot in input to proceed with the commit of the slot. In output we will have the id of the slot and its updated state.

- [Cancel the slot](https://metering-usage-broker-test.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/slots-controller/deleteSlots) putting it into the FREE state. 

It is also possible to:  

- [Create details](https://metering-usage-broker-test.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/slots-controller/postSlotsDetails) for a slot. It is possible to specify a list of key-value pairs as details of the slot. 

- [Delete details](https://metering-usage-broker-test.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/slots-controller/deleteSlotsDetail) from a slot

- [Archive the slots in cool down](https://metering-usage-broker-test.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/slots-controller/postSlotsArchive) for the list of packages specified in input. This API is invoked daily by the function app [Slot Archiver](https://slot-archiver-fn.azurewebsites.net)

- [Update the package id of the consumptions](https://metering-usage-broker-test.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/slots-controller/postSlotsPackageUpdates) in case of upgrade.The service takes in input the identifiers of the old and the new package. Once the necessary data-consistency checks have been performed, the service will proceed to update the old id of the package associated with the slot with the new one.


### met-unit-emitter

The `met-unit-emitter` module serves as a robust event handling system. Its primary function is to efficiently manage and validate events received from a subscription. Subsequently, it dispatches these validated events to a designated topic, where the `realtime-usage-collector` service awaits to process them.

#### Asynchronous Consumption APIs

For various types of asynchronous consumption, the `met-unit-emitter` provides a set of APIs, each dedicated to managing a specific type. The following are the available APIs:

- [Fatturazione](https://met-unit-emitter-test.agyo.io/swagger-ui.html#/Consumption/postSyncConsumption)
- [Invoice-trading](https://met-unit-emitter-test.agyo.io/swagger-ui.html#/Consumption/postInvoiceTradingConsumption)
- [Crisi di impresa](https://met-unit-emitter-test.agyo.io/swagger-ui.html#/Consumption/postRiskAssessmentConsumption)
- [Adempimenti agro alimentare](https://met-unit-emitter-test.agyo.io/swagger-ui.html#/Consumption/postFiscalViticultureConsumption)
- [Archive](https://met-unit-emitter-test.agyo.io/swagger-ui.html#/Consumption/postArchiveConsumption)
- [Business Credits](https://met-unit-emitter-test.agyo.io/swagger-ui.html#/Consumption/postBusinessCreditConsumption)
- [Pecmanager Space](https://met-unit-emitter-dev.agyo.io/swagger-ui.html#/Consumption/postPecmanagerSpaceConsumption)
- [Dg Signature](https://met-unit-emitter-dev.agyo.io/swagger-ui.html#/Consumption/postDgSignatureConsumption)
- [Docs Base](https://met-unit-emitter-dev.agyo.io/swagger-ui.html#/Consumption/postDocsBaseConsumption)
- [Sms](https://met-unit-emitter-dev.agyo.io/swagger-ui.html#/Consumption/postSmsConsumption)
- [Bpaas Payroll](https://met-unit-emitter-dev.agyo.io/swagger-ui.html#/Consumption/postBpaasPayrollConsumption)
- [Bpaas Accounting](https://met-unit-emitter-dev.agyo.io/swagger-ui.html#/Consumption/postBpaasAccountingConsumption)

#### Bpaas APIs Specifics

Both Bpaas APIs, namely *Bpaas Payroll* and *Bpaas Accounting*, handle the assignment of consumptions for BPAAS services. It's important to note that their implementations differ significantly. The key distinction lies in the ability to assign consumption with a specific date, referred to as `competenceDate`. This date can only belong to either the current billing cycle or previous billing cycles.

Since these APIs operate asynchronously, they do not offer real-time validation. Consequently, it is crucial for users to exercise caution when inputting dates. For instance, dates preceding the package purchase date are considered invalid and should be avoided to ensure accurate and error-free processing.

### realtime-usage-collector

This service is responsible for dequeuing events sent by the `met-unit-emitter` module and saving each received event as consumption associated with a package.

Additionally, it provides APIs for reassigning packages for various types of consumption:


- [Fatture](https://realtime-usage-collector-test.agyo.io/swagger-ui/index.html#/reassignments-controller/postInvoicesReassignmentForOwner) only with UUID 
- [Fatture](https://realtime-usage-collector-test.agyo.io/swagger-ui/index.html#/reassignments-controller/postInvoicesReassignmentForOwnerOrFiscalCode) via UUID and fiscal code
- [Ordini](https://realtime-usage-collector-test.agyo.io/swagger-ui/index.html#/reassignments-controller/postOrdersReassignmentForOwner)  
- [Corrispettivi](https://realtime-usage-collector-test.agyo.io/swagger-ui/index.html#/reassignments-controller/postReceiptsReassignmentForOwner)  
- [Documenti firmati](https://realtime-usage-collector-test.agyo.io/swagger-ui/index.html#/reassignments-controller/postSignaturesReassignmentForOwner)  
- [Consumi crisi di impresa](https://realtime-usage-collector-test.agyo.io/swagger-ui/index.html#/reassignments-controller/postRiskAssessmentsReassignmentForOwner)  
- [Consumi di banklink](https://realtime-usage-collector-test.agyo.io/swagger-ui/index.html#/reassignments-controller/postBanklinkReassignmentForOwner)  
- [Tutti i consumi di un owner](https://realtime-usage-collector-test.agyo.io/swagger-ui/index.html#/reassignments-controller/postReassignmentOwnerConsumption)

#### Reassignment Specifics

For *Fatture*, reassignment is possible using either the UUID alone or both the UUID and fiscal code. Choose the appropriate endpoint based on your requirements.

These reassignment APIs provide a flexible way to manage package allocations for different types of consumption, ensuring efficient and accurate tracking of usage.

##### Credits Flow


The only micro-service where we have the credit logic is in realtime-usage-collector. Basically, this service previously used to calculate also the credit. For the moment, this service does not handle assignment of credits; there are only a couple of methods that check the amount of credit used for a specific package.

- A key flag exists in this service, which is sumEnabled (currently this flag is true in all environments).

- If the above flag is true, Credits will calculate the sum (weight) of the consumptions for a specific package based on the credits startDate and endDate.

- If the above flag is true, Credits will count the amount of the consumptions for a specific package based on the credits startDate and endDate.

- *Note: This is the same logic as how consumptions are calculated too.

Differently from the calculation of consumption logic, in Credits, if the previous amounts are more than the limit (amount field) of a credit, it will be calculated through this limit.

Calculation of the consumption for the billing cycle:
When calculating the total of the consumptions for the billing cycle, in the current implementation, the check is made by calculating:
    total consumption amount - total credit amount

- If this calculation is less than the limit of a constraint and the absolute is true, then we proceed to send the package as 'limit reached'.

Reassignment API Logic:
When we talk about the reassignment API, it follows a similar idea. If there's some credit left during reassignment, the system resets the 'USED' field to 0.


### metering-consumptions-read

This service is primarily invoked by the metering dashboard to retrieve package usage information.

Additionally, there are [APIs](https://metering-consumptions-read-test.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Slots/getSlotSubscriptionsByItemAndService) utilized by various applications (privacy, signature, ecobonus, etc.). This API, given an item ID and a service, provides details on synchronous consumptions.

#### Slots
 - [Packages Slots](https://metering-consumption-read-dev.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Slots/getSlotsByPackages)
   - Responsible to retrieve list of packages which contains `Slots` by giving as input the id-s of the packages.
 - [Package Slots](https://metering-consumption-read-dev.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Slots/getSlotsByPackage)
     - Responsible to retrieve single package which contains `Slots` by giving as input the id of the package.

#### Consumptions
 - [Packages Consumptions](https://metering-consumption-read-dev.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumptions/getConsumptionsByPackage)
     - Responsible to retrieve list of packages which contains information about `Consumptions` by giving as input the id-s of the packages.
 - [Package Consumptions](https://metering-consumption-read-dev.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumptions/getConsumptionsByPackage_1)
     - Responsible to retrieve single package which contains information about `Consumptions` by giving as input the id of the package.
 - [Package Consumptions Statistics](https://metering-consumption-read-dev.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumptions/getConsumptionsStatisticsByPackage)
     - Responsible to retrieve single package which contains information about the statistics of `Consumptions` by giving as input the id of the package.
     - This API offers also the possibility to filter by date.
 - [Package Consumptions Raw](https://metering-consumption-read-dev.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumptions/getConsumptionsRaw)
     - Paginated API Responsible to retrieve big data information about the statistics of `Consumptions` by giving as input the id of the package.
     - This API offers also the possibility to filter by date.
 - [Company Consumptions](https://metering-consumption-read-dev.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumptions/getConsumptionsByOwner)
     -  API Responsible to retrieve  information about all the  `Consumptions` of a Companies by giving as input the owner of the company.
     - By putting the `isLastBillingCycle = true` the API retrieves all the consumptions based to the current billing cycle.
     - When needed to retrieve the consumptions of `old billing cycles` for a `specific period` of time is needed to put the `isLastBillingCycle = false` and also to add as input the desired `startDate` and `endDate` inputs.
     - When needed to retrieve the consumptions of `current billing cycles` for a `specific period` of time is needed to put the `isLastBillingCycle = true` and also to add as input the desired `startDate` and `endDate` inputs.

#### Flow Consumptions
 - [Flows Consumptions](https://metering-consumption-read-dev.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Flows/getFlowsByPackage)
     - Responsible to retrieve the `flow` of `consumptions` related to a single package.


### consumptions-dashboard

It is the React project for displaying the consumptions dashboard inside the TS Digital portal.

The codebase is available [here](https://biosphere.teamsystem.com/tsdigital/metering/consumptions-dashboard)



## To be


### Architecture
 
![architettura](images/gestione-consumi-tobe.png)

There are two services, one for writing and one for reading.
The future idea is to concentrate all the consumption write operations (slots and asynchronous) on the write service.
For asynchronous consumptions the write service should stay listening on a single listener with the business logic for validating the type of consumption and save the consumption with the associated package. 


### metering-consumption-read

The service exposes the consumption read APIs.

It is possible to [given a package ID retrieve the count of both slots and asynchronous consumptions](https://metering-consumption-read-test.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumptions/getConsumptionsByPackage_1).  

[From a list of package ids it is possible to obtain the consumption count of all the packages](https://metering-consumption-read-test.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumptions/getConsumptionsByPackage)

[Retrieve the asynchronous consumptions as they are saved on the database](https://metering-consumption-read-test.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumptions/getConsumptionsRaw)

[Retrieve the slots individually as they are saved on the database](https://metering-consumption-read-test.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Slots/getSlotsByPackage). 

[Retrieve the flows used given the id of a package](https://metering-consumption-read-test.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Flows/getFlowsByPackage): api used by the dashboard  

[Retrieve the consumptions of a package grouped by company](https://metering-consumption-read-test.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumptions/getConsumptionsStatisticsByPackage): api used by the dashboard


### metering-consumption-write

At the moment this service exposes only the APIs for deleting the consumptions [given an id](https://metering-consumption-write-test.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumption/postDelete) or [given a list of ids](https://metering-consumption-write-test.ts-paas.com/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/Consumption/postDeleteAll) which are used for archiving. 

Going forward the apis for managing slots and synchronous consumptions and the logic for dequeuing the asynchronous consumption events with their subsequent persistence should be centralized in this service.

For a simpler and more agnostic management of asynchronous consumptions one can think of having a single table with the following fields: id, owner, timestamp, package\_id, weight, payload. In the payload field the JSON of the whole event that is dequeued should be saved.
