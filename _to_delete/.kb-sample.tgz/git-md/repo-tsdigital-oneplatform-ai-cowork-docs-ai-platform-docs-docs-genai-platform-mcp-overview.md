---
source_id: "git-md:repo-tsdigital-oneplatform-ai-cowork-docs-ai-platform-docs-docs-genai-platform-mcp-overview"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/-/blob/6c617371f851e6ffa24e0fe0c27751375233fdb5/docs/genai-platform/mcp/overview.md"
title: MCP
authority: descriptive
version_hash: "sha256:474f1f862e91affbefd82bb731be0a0232f6908d3b4ffb7eb5fc7da41bef06ef"
body_hash: "sha256:474f1f862e91affbefd82bb731be0a0232f6908d3b4ffb7eb5fc7da41bef06ef"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/docs/genai-platform/mcp/overview.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# MCP

The **Model Context Protocol (MCP)** is the standard interface for building and consuming AI-powered tools on the platform. For background on the protocol itself, see the [official MCP documentation](https://modelcontextprotocol.io). Our MCP servers are built with [FastMCP](https://gofastmcp.com), a high-level Python framework for building MCP servers.

This section covers:

- **[Building an MCP Server](building-mcp-server.md)** — reference architectures and templates for building MCP servers.
- **[Deploying an MCP Server](deploying-mcp-server.md)** — end-to-end deployment and release process.
- **[Registering an MCP Server](registering-mcp-server.md)** — how to register MCP servers on the platform.
- **[Publishing an MCP Server](publishing-mcp-server.md)** - how to publish MCP servers on the platform.
- **[Evaluating MCP Tools](evaluating-mcp-tools.md)** - how to evaluate MCP tools on the platform.
- **[MCP Adoption Assistant](mcp-adoption-assistant.md)** - a conversational companion for a first-pass quality assessment of MCP servers and tools.

To guide the model on *when and how* to use your server's tools, ship one or more [Skills](skills.md) alongside them.
