---
source_id: "git-md:repo-oneplatform-pet-developer-portal-documentation-teamsystem-id-docs-developer-guide-direct-redirect-to-external-idp"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/PET/developer-portal/documentation/teamsystem-id/-/blob/efd562b907329be3427ff46fc51373ad99b77195/docs/developer_guide/direct_redirect_to_external_idp.md"
title: Direct Redirect to external provider including SPID
authority: descriptive
version_hash: "sha256:707b603a0d4e9fd3749a2dba7936d3f9d1660581549d2326f922f359512e23d6"
body_hash: "sha256:754c195a9aecb110f2df2eaa0c9bf30870f167ebc2bd1f4e063195a16f47bf2b"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/PET/developer-portal/documentation/teamsystem-id"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/PET/developer-portal/documentation/teamsystem-id/docs/developer_guide/direct_redirect_to_external_idp.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Direct Redirect to external provider including SPID

The TSID offers the opportunity for applications to bypass the TSID login screen, so that the user can be redirected directly to their IdentityProvider and continue the flow as per standard protocol.  
To be able to do this, it is necessary to pass in the query string, when the Authorization Endpoint is called, the parameter **acr_values** valued for example as follows:

**acr_values=idp:name_of_idp**

In the case of SPID, for example, the request will be:

```
https://localhost:5001/connect/authorize?response_type=code&client_id=113d6b5c-9c47-4779-8bb9-7cc4dc8f009a&redirect_uri=https://localhost:44355/account/authcallback&scope=openid%20profile%20offline_access%20roles&acr_values=idp:SPID
```

In order to use this function, the trust must be made between the external IdP and the TSID, either via the SAML2 protocol or via the OpenID/OAuth20 protocol.
