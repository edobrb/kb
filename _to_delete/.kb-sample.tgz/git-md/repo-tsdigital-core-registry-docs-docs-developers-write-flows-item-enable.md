---
source_id: "git-md:repo-tsdigital-core-registry-docs-docs-developers-write-flows-item-enable"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/core/registry/docs/-/blob/dd12fa9ace30e514bd895fe5406701978cb14293/docs/developers/write-flows/item-enable.md"
title: Item enablement Flow
authority: descriptive
version_hash: "sha256:a88fb91f2bd745be832e7474dda81737f6c16e1e42e1204d6f8b6ba29a28ba5b"
body_hash: "sha256:a88fb91f2bd745be832e7474dda81737f6c16e1e42e1204d6f8b6ba29a28ba5b"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/core/registry/docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/core/registry/docs/docs/developers/write-flows/item-enable.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Item enablement Flow

This flow allows enabling an item that was previously disabled. Disabled items cannot be used in any operation until they are re-enabled.

## Entrypoints

### REST

- `POST /api/v3/items/{itemId}/enable`
- `POST /api/v2/items/{itemId}/enable`

### Thrift (Legacy, deprecated)

`enableItem` method available on the following Thrift services:

- `/thrift/v2/binary`
- `/thrift/v2/json`
- `/thrift/v3/binary`
- `/thrift/v3/json`

## Authorization

The following users are allowed to enable an item:

- The owner of the item.
- Backoffice users with the `BACKOFFICE:enableItem` permission, if the `x-app-name` header is `BACKOFFICE`.
- M2M keys with a global `REGISTRY:enableItem` permission.

## Flow Graph

```mermaid
flowchart TD

A((START))-->B{Item exists?}
B--No -->NOTFOUND(404 Not Found)
B--Yes -->C{User can\nenable item?}
C--No -->FORBIDDEN(403 Forbidden)
C--Yes -->D[Send enable event]
```

## Item Enable Event

The flow produces an [event](../data-structures/item-event.md) with the following characteristics:

- `eventName` is `ENABLE_ITEM_START`
- the [`operation`](../data-structures/item-event.md#gdpr-tracking-fields) field is set to `U`

## Event Handling Flow

The [Registry Updater](../registry-updater.md) service listens for the `ENABLE_ITEM_START` event and processes it as follows:

```mermaid
flowchart TD

A((START))-->B[Normalize Event Data]
B-->C{Event Valid?}
C--No -->FAIL[Fail Event Processing]
C--Yes -->D{Item Exists?}
D--No -->FAIL
D--Yes -->E[Set Item as Active]
E-->F[Persist Changes]
F-->END((END))
```

### Data Normalization

The event data is normalized in the following way:

- remove all non-alphanumeric, non `-` characters from `id`

### Set Item as Active

The following changes are applied to an enabled item:

- The `active` flag is set to `true`
- The `activatedBy` and `modifiedBy` fields are set to the user who performed the enable operation
