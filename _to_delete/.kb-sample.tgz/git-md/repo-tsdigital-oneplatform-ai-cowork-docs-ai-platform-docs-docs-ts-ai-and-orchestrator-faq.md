---
source_id: "git-md:repo-tsdigital-oneplatform-ai-cowork-docs-ai-platform-docs-docs-ts-ai-and-orchestrator-faq"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/-/blob/6c617371f851e6ffa24e0fe0c27751375233fdb5/docs/ts-ai-and-orchestrator/faq.md"
title: FAQ
authority: descriptive
version_hash: "sha256:44402a5464bf88c0d5a7b5c67f042ea69a729d2ac988b66dcfc84ab754247524"
body_hash: "sha256:44402a5464bf88c0d5a7b5c67f042ea69a729d2ac988b66dcfc84ab754247524"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/docs/ts-ai-and-orchestrator/faq.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# FAQ

Frequently asked questions about the behaviour of TeamSystem virtual assistants built on the orchestrator.

## Why does the assistant reply "I can only help you with the features available in this environment"?

The full reply is:

> I'm sorry, I can't answer that question. I can only help you with the features available in this environment.

The orchestrator is a **pure router**: it has no built-in knowledge and no canned answers. Everything an assistant can do is provided by the **operations** (tools) exposed by the **MCP servers** wired to that assistant, and its capabilities are *exactly* the set of operations available **at the moment the request is processed** — nothing more.

So the assistant performs the request when it **maps to an available operation**, and replies with the message above when the request is **not covered by any available operation** (or there are no operations at all). It will not answer general-knowledge questions, opinions, or anything outside the operations it can perform — it is not a general-purpose chatbot.

The key takeaway: **this is never a "model error".** It is the deterministic fallback the assistant is told to use whenever the requested action is not represented by a currently-loaded operation. The real question is always *"why was the right operation not available for this request?"* — see the questions below.

## Is this message always a problem?

No. In the common case it is **correct and intentional**: the user asked for something the assistant genuinely cannot do.

- General knowledge, trivia, opinions, small talk ("what's the weather?", "write me a poem").
- A capability that **belongs to a different assistant** (e.g. asking an invoicing assistant to manage payroll).
- A request that is simply **out of scope** for the operations wired to that assistant.

If the message appears only with off-topic prompts while on-topic prompts work, **nothing is broken** — the assistant is doing exactly what it should.

## A request that should work returns this message — what could be wrong?

The same message appears when a request that *should* be in scope finds **no matching operation**, because the chain that resolves operations broke somewhere. That chain is:

```text
assistant id  →  servers mapped to that assistant
              →  servers actually discovered (from the gateway, at orchestrator startup)
              →  servers whose connection opened successfully for this request
              →  the operations (and their descriptions) those servers expose
```

If any link yields an empty or reduced set, an otherwise-valid request looks out of scope. The most frequent causes:

| Cause                                            | What happens under the hood                                                                                                                                                                                                                             | Typical trigger                                                         |
| ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| **Stale frontend / browser cache**               | The chat sends an **old or wrong `assistant` identifier**. An unknown assistant id resolves to **no servers**, so the assistant has zero operations.                                                                                                    | Browser serving a cached bundle after a release; hard refresh not done. |
| **Frontend or assistant-id change**              | A frontend deploy **renamed or changed the assistant identifier** sent with the request, and it no longer matches a known assistant.                                                                                                                    | New frontend version; environment/config mismatch.                      |
| **Tool (MCP) update changed names/descriptions** | The operation still exists, but its **name or description changed** in a recent MCP deploy, so the assistant no longer recognises that the user's request maps to it. Capability matching is driven by the operation descriptions.                      | An MCP server release that reworded or restructured its tools.          |
| **MCP server pod is down / unreachable**         | The connection to the MCP server **fails to open** (or listing its operations times out) for the request. That server contributes **zero operations**; if it was the only relevant one, every request looks out of scope.                               | Pod crash, restart, rollout, network/timeout, dependency outage.        |
| **Server not discovered at startup**             | The orchestrator discovers MCP endpoints **once, at startup**, from the gateway catalogue. A server **registered or brought up after** the orchestrator started, or **missing from the catalogue**, is not visible until the orchestrator is restarted. | New MCP server added recently; registration not yet reflected.          |

The same reply can therefore come from very different layers — the **frontend** (wrong/old assistant id), the **MCP server** (down, or operations reworded), or **timing** (server not yet discovered). The message text alone does not tell you which.

## The assistant greets with "there are no features available in this environment at the moment" — is that the same issue?

Yes — it is the same root cause family. When the assistant has **zero** operations available and the user merely greets it or asks "what can you do?", it replies with this variant instead:

> Hello! Unfortunately, there are no features available in this environment at the moment. Please contact the administrator to check the configuration.

Both messages mean **no usable operations** are available for the request; this greeting variant is just the version shown when there is nothing at all to offer.

## How do I diagnose it before contacting the team?

Work through the chain from the user-visible side inward:

```mermaid
flowchart TD
    A[User sees the message] --> B{Is the request actually<br/>in scope for this assistant?}
    B -->|No, it's off-topic| Z[Expected behaviour — no action needed]
    B -->|Yes, it should work| C[Hard-refresh the browser /<br/>clear cache, retry]
    C -->|Now works| Z2[Was a stale frontend / cache]
    C -->|Still fails| D{Do OTHER in-scope requests<br/>for the same assistant work?}
    D -->|Yes| E[Likely a single tool whose<br/>name/description changed in a<br/>recent MCP update]
    D -->|No, everything is out of scope| F[Likely the whole MCP server is<br/>down, unreachable, or not discovered]
    E --> G[Contact the AI Platform team<br/>with the assistant id + example prompt]
    F --> G
```

A quick **hard refresh / cache clear** is always worth trying first: it rules out the single most common cause (a stale frontend sending an old assistant id) in seconds. Before escalating, gather:

1. **The exact prompt** that triggered the message (and whether off-topic prompts behave differently).
1. The **assistant identifier** in use, and whether a **frontend release** happened recently.
1. Whether the message is **intermittent** (points to a pod restart/rollout or timeout) or **persistent** (points to discovery/config or a renamed operation).
1. Whether a **recent MCP server deploy** changed the affected operation's name or description.

## Who do I contact if it still happens?

If on-topic requests still produce the message after a cache clear, it is an **operational or configuration** issue rather than a user mistake. Contact the **AI Platform team** with the details listed above (assistant id, example prompt, timing, recent releases) so they can check server discovery, the assistant-to-server mapping, and the health of the relevant MCP server. See the [GenAI Platform help page](../genai-platform/access.md) for how to reach the team.
