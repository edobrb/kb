---
source_id: "git-md:repo-oneplatform-tsdataplatform-data-governance-ts-dataplatform-datagovernance-documentation-docs-dev-journey-1a-data-catalog-creation"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/-/blob/256aaa023d7a1968e3a84c8985dae5a7c2db39ff/docs/dev-journey-1a-data-catalog-creation.md"
title: Data catalog
authority: descriptive
version_hash: "sha256:4f7f0be881db1afc446abab4758b94a0f6c89587827cf9f3689905705e692511"
body_hash: "sha256:f4515bbdbb8d9ebde8162e1ea4c8fb8a8c3a9b0a9b9e6a1f354c18295cfefc1d"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/docs/dev-journey-1a-data-catalog-creation.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Data catalog

Teamsystem has a single metastore for all the tables in Databricks, [Unity Catalog](https://learn.microsoft.com/en-us/azure/databricks/data-governance/unity-catalog/), which is already activated in your workspace.

For each Domain, a Catalog is created named "domain_environment" and is already visible only in the corresponding environment (**domain_dev** for development, **domain_prod** for production).<br>
The Catalog uses as External Location the Blob Storage of the Domain. <br>

Inside a Catalog, you can have some Schemas, which should correspond to a Sub-domain.
In a Schema you can write your Tables and Views.

The Catalog ownership is assigned to the Data Platform team; Schemas are owned by Business Data Domain owners.

<!-- Currently any unity object is managed ONLY with users and groups in Unity Catalog, there is no sync with Azure groups (work in progress). -->

> Here you can find the official documentation for [Unity Catalog object and privileges](https://docs.databricks.com/en/data-governance/unity-catalog/manage-privileges/privileges.html)

## New Schemas in Unity Catalog

When you use a Databricks output port component in Witboost, the schema is created automatically. This applies to Databricks table, view, and metric view output port components. The schema name matches the output port name, with spaces removed.

The schema is created during the validation step, when you run a test in the "Edit and Test" section of a data product in Witboost.

**Schema Permissions by Environment**

| Environment | Developer Team Permissions   | Notes                                                                                                                        |
| ----------- | ---------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| Dev         | All permissions + Can Manage | Developers can create, manage, and modify tables and grants.                                                                 |
| Prod        | Create only (no Manage)      | Developers can create tables, but cannot modify grants. To change grants, requests must go through the Witboost Marketplace. |

## Foreign catalog

Lakehouse Federation is a feature of Unity Catalog to perform queries on external locations, using Foreign Catalogs. Foreign catalogs map an external database (SQLServer, MySQL, Postgres etc), showing all its schemas and tables. If you want to learn more about foreign catalog refer to the official [Databricks documentation](https://docs.databricks.com/aws/en/query-federation/).

Foreign catalogs can be used in the same way as any other catalog in Unity Catalog, so the Catalog creation and configuration is entirely managed by the Data Platform team.

Usually, external databases are related to a specific Domain, so foreign catalogs are named **domain*databasename*\<environment>**.\
If external databases are related to multiple domains (e.g. DWH), the data platform team will create a generic display name for the specific database, so the catalog is named **displayname*databasename*\<environment>**.

If you want to work with a foreign catalog, ask the Data Platform team for creation, permission configuration and workspace assignments.

## Unity Catalogs in different workspaces

By default, a Unity Catalog (Default or External) exists in the workspaces where it was created with Read & Write grants. If you want to make it available to other workspaces, you can assign it in the "Workspaces" tab of the catalog.

**NEVER SELECT "All Workspaces have access".**

> **NOTE:** When assigning a Catalog to a Workspace, the default permission is "read and write". Remember to change it to "read only" if required.

![Data catalog and workspaces](./images/dev_journey/dev-journeydata-catalog-assign-workspace.png)

> **ATTENTION:** Manual visibility management is only required for:
>
> - external catalogs
> - Delta Shares
> - catalogs not managed in data platform

All managed catalogs in the **same environment** are automatically bound to your workspace:

- The domain catalog is bound with **read-write** access
- All **other catalogs** in the same environment are bound with **read-only** access

> **NOTE:** The dataplatform workspaces in each environment retain _read-write_ access to all the other catalogs in the same environment to support platform services.

All existing exceptions (e.g., read-write grants or other bindings that were previously requested and approved) have already been migrated and are still in place. No action is required on your part.

## When You Still Need to Open a Request

You only need to contact the Data Platform team if you need an exception on the general binding rule above (e.g. you need _read-write access_ to another catalog).

In your request, please include:

- Your **workspace name** (e.g., `dbw-yourdomain-dev`)
- The **catalog name** you need access to (e.g., `otherdomain_dev`)
- The **type of access** needed (e.g. `read-write`)
- A brief **reason** for the exception
