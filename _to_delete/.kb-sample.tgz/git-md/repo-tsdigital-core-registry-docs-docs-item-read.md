---
source_id: "git-md:repo-tsdigital-core-registry-docs-docs-item-read"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/core/registry/docs/-/blob/dd12fa9ace30e514bd895fe5406701978cb14293/docs/item-read.md"
title: Reading Items
authority: descriptive
version_hash: "sha256:38808b596021018b2fd961cc052fb875d8119f9ad810abe7302411a95550b93f"
body_hash: "sha256:81beecb80da1b02583aef827c4cad3d73677eb8796d5d4fa08438694e984a295"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/core/registry/docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/core/registry/docs/docs/item-read.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Reading Items

This document describes the APIs for querying items in the TeamSystem master data.

## Reading a single item

Given an item's ID, you can retrieve all its information by calling this API:

> [[GET] /api/v3/items/{itemId}](https://registry-read-dev.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/rest-api-controller-v-3/getItem)

> This documentation refers to version 3 of the read APIs. V2 APIs are deprecated and should not be used for new integrations.

**Headers**

The required headers are described in the [Authentication and Headers](index.md#getting-started-authentication-and-headers) section.

The `Content-Type` must be `application/json`.

**Query Parameters**

- **packageType**: The level of detail for the item. It accepts two values: **BASE** and **FULL**. In most cases, using **BASE** is sufficient and recommended.

**Responses**

The operation succeeds only if the HTTP status code is `200`. Any other status code indicates an error.

**HTTP 200**

The item exists and the user is authorized to read it.

<details>

<summary>Response Body</summary>

```json
    {
      "items": [
        {
      	"item": {
          "base": {
            "id": "string",
            "identifier": {
              "taxId": "string",
              "taxRegion": "string",
              "vatNumber": "string",
              "govCode": "string"
            },
            "details": {
              "classifier": "string",
              "description": "string",
              "firstName": "string",
              "lastName": "string",
              "gender": "string",
              "legalClass": "string",
              "birthDate": 0,
              "addresses": [
                {
                  "streetName": "string",
                  "streetNumber": "string",
                  "city": "string",
                  "province": "string",
                  "zipCode": "string",
                  "country": "string",
                  "fullAddress": "string",
                  "types": [
                    "string"
                  ],
                  "id": "string"
                }
              ],
              "economics": {
                "rea": "string",
                "cciaa": "string",
                "capitalStock": "string",
                "liquidationState": "string",
                "registrationDate": 0,
                "taxRegime": "string",
                "soleShareholder": "string",
                "balanceSheetDate": 0,
                "economicActivities": {
                  "mainActivity": {
                    "code": "string",
                    "rootCode": "string"
                  }
                }
              },
              "contacts": [
                {
                  "type": "string",
                  "value": "string",
                  "label": "string",
                  "id": "string"
                }
              ],
              "professionalRegister": {
                "description": "string",
                "province": "string",
                "code": "string",
                "registrationDate": 0
              },
              "legalForm": {
                "code": "string",
                "description": "string"
              }
            },
            "status": {
              "active": true,
              "activatedAt": 0,
              "activatedBy": "string",
              "createdAt": 0,
              "createdBy": "string",
              "modifiedAt": 0,
              "modifiedBy": "string",
              "status": "string",
              "deleted": true,
              "deletedAt": 0,
              "deletedBy": "string",
              "ownership": "string",
              "certificationStatus": "string",
              "externallyValidated": true
            },
            "hierarchyId": "string",
            "parentId": "string",
            "holdingId": "string",
            "ncsId": "string"
          },
          "preferences": {
            "enableConsole": true,
            "invoiceRecipient": true,
            "language": "string",
            "hidden": true
          },
          "layers": [...],
          "group": {
            "businessGroups": [
              {
                "name": "string",
                "foundedAt": 0,
                "id": "string"
              }
            ],
            "holding": {...},
            "companies": [{...}],
            "companiesSize": 0,
            "companiesIterator": {},
            "businessGroupsSize": 0,
            "businessGroupsIterator": {}
          },
          "layersSize": 0,
          "layersIterator": {}
        }
      }
    ]
}
```

</details>

For more information on individual fields, see [Item Structure](item-write.md#item-structure "Item Structure").

**HTTP 400**

One or more parameters in the request are incorrect, or mandatory parameters are missing.

**HTTP 401**

The authorization token has expired, is invalid, or was not provided.

**HTTP 403**

The authorization token is valid, but the user does not have permission to read the item.

**HTTP 500**

The server encountered an unexpected error while processing the request.

**HTTP 502**

The server encountered an error while communicating with a dependency service (e.g., the auth service is unavailable).

All error responses share the following body format:

    {
      "code": "string",
      "message": "string",
      "status": "string",
      "subErrors": [
        {}
      ],
      "timestamp": "dd-MM-yyyy HH:mm:ss"
    }

- **code**: Corresponds to the returned HTTP error code (e.g., `500`).
- **message**: The error message (e.g., `Internal server error`).
- **status**: A description of the HTTP error code (e.g., `Internal Server Error`).
- **subErrors**: Any nested errors.
- **timestamp**: The date and time when the error occurred.

## Reading a list of items

Given a list of item IDs, you can retrieve all their information by calling this API:

> [[GET] /api/v3/items](https://registry-read-dev.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/rest-api-controller-v-3/findItems)

> This documentation refers to version 3 of the read APIs. V2 APIs are deprecated and should not be used for new integrations.

**Headers**

The required headers are described in the [Authentication and Headers](index.md#getting-started-authentication-and-headers) section.

The `Content-Type` must be `application/json`.

**Query Parameters**

- **idList:** A list of item identifiers.
- **packageType**: The level of detail for the item. It accepts two values: **BASE** and **FULL**. In most cases, using **BASE** is sufficient and recommended.
- **pagination.itemsPerPage:** The number of items returned per page.
- **pagination.pageNumber:** The page number of the result.
- **pagination.Unpaged:** Default is **false**. Set to true to disable pagination and get all results.

**Responses**

The operation succeeds only if the HTTP status code is `200`. Any other status code indicates an error.

**HTTP 200**

The item exists and the user is authorized to read it.

<details>

<summary>Response Body</summary>

```json
    {
      "items": [
        {
      	"item": {
          "base": {
            "id": "string",
            "identifier": {
              "taxId": "string",
              "taxRegion": "string",
              "vatNumber": "string",
              "govCode": "string"
            },
            "details": {
              "classifier": "string",
              "description": "string",
              "firstName": "string",
              "lastName": "string",
              "gender": "string",
              "legalClass": "string",
              "birthDate": 0,
              "addresses": [
                {
                  "streetName": "string",
                  "streetNumber": "string",
                  "city": "string",
                  "province": "string",
                  "zipCode": "string",
                  "country": "string",
                  "fullAddress": "string",
                  "types": [
                    "string"
                  ],
                  "id": "string"
                }
              ],
              "economics": {
                "rea": "string",
                "cciaa": "string",
                "capitalStock": "string",
                "liquidationState": "string",
                "registrationDate": 0,
                "taxRegime": "string",
                "soleShareholder": "string",
                "balanceSheetDate": 0,
                "economicActivities": {
                  "mainActivity": {
                    "code": "string",
                    "rootCode": "string"
                  }
                }
              },
              "contacts": [
                {
                  "type": "string",
                  "value": "string",
                  "label": "string",
                  "id": "string"
                }
              ],
              "professionalRegister": {
                "description": "string",
                "province": "string",
                "code": "string",
                "registrationDate": 0
              },
              "legalForm": {
                "code": "string",
                "description": "string"
              }
            },
            "status": {
              "active": true,
              "activatedAt": 0,
              "activatedBy": "string",
              "createdAt": 0,
              "createdBy": "string",
              "modifiedAt": 0,
              "modifiedBy": "string",
              "status": "string",
              "deleted": true,
              "deletedAt": 0,
              "deletedBy": "string",
              "ownership": "string",
              "certificationStatus": "string",
              "externallyValidated": true
            },
            "hierarchyId": "string",
            "parentId": "string",
            "holdingId": "string",
            "ncsId": "string"
          },
          "preferences": {
            "enableConsole": true,
            "invoiceRecipient": true,
            "language": "string",
            "hidden": true
          },
          "layers": [...],
          "group": {
            "businessGroups": [
              {
                "name": "string",
                "foundedAt": 0,
                "id": "string"
              }
            ],
            "holding": {...},
            "companies": [{...}],
            "companiesSize": 0,
            "companiesIterator": {},
            "businessGroupsSize": 0,
            "businessGroupsIterator": {}
          },
          "layersSize": 0,
          "layersIterator": {}
        }
      }
    ]
}
```

</details>

For more information on individual fields, see [Item Structure](item-write.md#item-structure "Item Structure").

**HTTP 400**

One or more parameters in the request are incorrect, or mandatory parameters are missing.

**HTTP 401**

The authorization token has expired, is invalid, or was not provided.

**HTTP 403**

The authorization token is valid, but the user does not have permission to read the items.

**HTTP 500**

The server encountered an unexpected error while processing the request.

**HTTP 502**

The server encountered an error while communicating with a dependency service (e.g., the auth service is unavailable).

All error responses share the following body format:

    {
      "code": "string",
      "message": "string",
      "status": "string",
      "subErrors": [
        {}
      ],
      "timestamp": "dd-MM-yyyy HH:mm:ss"
    }

- **code**: Corresponds to the returned HTTP error code (e.g., `500`).
- **message**: The error message (e.g., `Internal server error`).
- **status**: A description of the HTTP error code (e.g., `Internal Server Error`).
- **subErrors**: Any nested errors.
- **timestamp**: The date and time when the error occurred.

## Reading a user's item list

Given a user ID, you can retrieve all information about their items by calling this API:

> [[GET] /api/v3/items](https://registry-read-dev.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/rest-api-controller-v-3/findItems)

> This documentation refers to version 3 of the read APIs. V2 APIs are deprecated and should not be used for new integrations.

**Headers**

The required headers are described in the [Authentication and Headers](index.md#getting-started-authentication-and-headers) section.

The `Content-Type` must be `application/json`.

**Query Parameters**

- **userId:** The user's identifier.
- **fullText**: A free-text search string.
- **packageType**: The level of detail for the item. It accepts two values: **BASE** and **FULL**. In most cases, using **BASE** is sufficient and recommended.
- **pagination.itemsPerPage:** The number of items returned per page.
- **pagination.pageNumber:** The page number of the result.
- **pagination.Unpaged:** Default is **false**. Set to true to disable pagination and get all results.

**Responses**

The operation succeeds only if the HTTP status code is `200`. Any other status code indicates an error.

**HTTP 200**

The item exists and the user is authorized to read it.

<details>

<summary>Response Body</summary>

```json
    {
      "items": [
        {
      	"item": {
          "base": {
            "id": "string",
            "identifier": {
              "taxId": "string",
              "taxRegion": "string",
              "vatNumber": "string",
              "govCode": "string"
            },
            "details": {
              "classifier": "string",
              "description": "string",
              "firstName": "string",
              "lastName": "string",
              "gender": "string",
              "legalClass": "string",
              "birthDate": 0,
              "addresses": [
                {
                  "streetName": "string",
                  "streetNumber": "string",
                  "city": "string",
                  "province": "string",
                  "zipCode": "string",
                  "country": "string",
                  "fullAddress": "string",
                  "types": [
                    "string"
                  ],
                  "id": "string"
                }
              ],
              "economics": {
                "rea": "string",
                "cciaa": "string",
                "capitalStock": "string",
                "liquidationState": "string",
                "registrationDate": 0,
                "taxRegime": "string",
                "soleShareholder": "string",
                "balanceSheetDate": 0,
                "economicActivities": {
                  "mainActivity": {
                    "code": "string",
                    "rootCode": "string"
                  }
                }
              },
              "contacts": [
                {
                  "type": "string",
                  "value": "string",
                  "label": "string",
                  "id": "string"
                }
              ],
              "professionalRegister": {
                "description": "string",
                "province": "string",
                "code": "string",
                "registrationDate": 0
              },
              "legalForm": {
                "code": "string",
                "description": "string"
              }
            },
            "status": {
              "active": true,
              "activatedAt": 0,
              "activatedBy": "string",
              "createdAt": 0,
              "createdBy": "string",
              "modifiedAt": 0,
              "modifiedBy": "string",
              "status": "string",
              "deleted": true,
              "deletedAt": 0,
              "deletedBy": "string",
              "ownership": "string",
              "certificationStatus": "string",
              "externallyValidated": true
            },
            "hierarchyId": "string",
            "parentId": "string",
            "holdingId": "string",
            "ncsId": "string"
          },
          "preferences": {
            "enableConsole": true,
            "invoiceRecipient": true,
            "language": "string",
            "hidden": true
          },
          "layers": [...],
          "group": {
            "businessGroups": [
              {
                "name": "string",
                "foundedAt": 0,
                "id": "string"
              }
            ],
            "holding": {...},
            "companies": [{...}],
            "companiesSize": 0,
            "companiesIterator": {},
            "businessGroupsSize": 0,
            "businessGroupsIterator": {}
          },
          "layersSize": 0,
          "layersIterator": {}
        }
      }
    ]
}
```

</details>

For more information on individual fields, see [Item Structure](item-write.md#item-structure "Item Structure").

**HTTP 400**

One or more parameters in the request are incorrect, or mandatory parameters are missing.

**HTTP 401**

The authorization token has expired, is invalid, or was not provided.

**HTTP 403**

The authorization token is valid, but the user does not have permission to read the items.

**HTTP 500**

The server encountered an unexpected error while processing the request.

**HTTP 502**

The server encountered an error while communicating with a dependency service (e.g., the auth service is unavailable).

All error responses share the following body format:

    {
      "code": "string",
      "message": "string",
      "status": "string",
      "subErrors": [
        {}
      ],
      "timestamp": "dd-MM-yyyy HH:mm:ss"
    }

- **code**: Corresponds to the returned HTTP error code (e.g., `500`).
- **message**: The error message (e.g., `Internal server error`).
- **status**: A description of the HTTP error code (e.g., `Internal Server Error`).
- **subErrors**: Any nested errors.
- **timestamp**: The date and time when the error occurred.

## Searching for items

You can search for items by `taxId`, `vatNumber`, or free text by calling this API:

> [[GET] /api/v3/items](https://registry-read-dev.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/rest-api-controller-v-3/findItems)

> This documentation refers to version 3 of the read APIs. V2 APIs are deprecated and should not be used for new integrations.

**Search by fiscal identifiers**

This section describes how to search for an item using its fiscal identifiers.

**FindItem**

Set the following parameters:

- `identifier.taxId` or `identifier.vatNumber`
- `identifier.taxRegion`
- `packageType`: **BASE**

> You can search by fiscal code (CF) or VAT number (PIVA).

### Caching Rules

Once you retrieve a company ID, you can safely cache it only if it is a UUIDv4, as it will not change. The fiscal code, however, can change due to rectification events.

Initially, due to migration, you will find a mix of ID formats.

If the ID is the same as the fiscal code, we recommend caching it for a few hours (24/48 hours recommended) to avoid unnecessary load on the master data APIs, but you should refetch it when the cache expires.

If the ID is a UUIDv4 (or has a length > 20, which is longer than the Italian fiscal code format (16) + office characters "-XXX" (4)), you can save it permanently, knowing it will not change.

**Headers**

The required headers are described in the [Authentication and Headers](index.md#getting-started-authentication-and-headers) section.

The `Content-Type` must be `application/json`.

**Query Parameters**

- **identifier.taxId:** The item's tax ID (codice fiscale).
- **identifier.vatNumber:** The item's VAT number (partita iva).
- **identifier.taxRegion:** The item's tax region.
- **fullText**: A free-text search string.
- **packageType**: The level of detail for the item. It accepts two values: **BASE** and **FULL**. In most cases, using **BASE** is sufficient and recommended.
- **pagination.itemsPerPage:** The number of items returned per page.
- **pagination.pageNumber:** The page number of the result.
- **pagination.Unpaged:** Default is **false**. Set to true to disable pagination and get all results.

**Responses**

The operation succeeds only if the HTTP status code is `200`. Any other status code indicates an error.

**HTTP 200**

The item exists and the user is authorized to read it.

<details>

<summary>Response Body</summary>

```json
    {
      "items": [
        {
      	"item": {
          "base": {
            "id": "string",
            "identifier": {
              "taxId": "string",
              "taxRegion": "string",
              "vatNumber": "string",
              "govCode": "string"
            },
            "details": {
              "classifier": "string",
              "description": "string",
              "firstName": "string",
              "lastName": "string",
              "gender": "string",
              "legalClass": "string",
              "birthDate": 0,
              "addresses": [
                {
                  "streetName": "string",
                  "streetNumber": "string",
                  "city": "string",
                  "province": "string",
                  "zipCode": "string",
                  "country": "string",
                  "fullAddress": "string",
                  "types": [
                    "string"
                  ],
                  "id": "string"
                }
              ],
              "economics": {
                "rea": "string",
                "cciaa": "string",
                "capitalStock": "string",
                "liquidationState": "string",
                "registrationDate": 0,
                "taxRegime": "string",
                "soleShareholder": "string",
                "balanceSheetDate": 0,
                "economicActivities": {
                  "mainActivity": {
                    "code": "string",
                    "rootCode": "string"
                  }
                }
              },
              "contacts": [
                {
                  "type": "string",
                  "value": "string",
                  "label": "string",
                  "id": "string"
                }
              ],
              "professionalRegister": {
                "description": "string",
                "province": "string",
                "code": "string",
                "registrationDate": 0
              },
              "legalForm": {
                "code": "string",
                "description": "string"
              }
            },
            "status": {
              "active": true,
              "activatedAt": 0,
              "activatedBy": "string",
              "createdAt": 0,
              "createdBy": "string",
              "modifiedAt": 0,
              "modifiedBy": "string",
              "status": "string",
              "deleted": true,
              "deletedAt": 0,
              "deletedBy": "string",
              "ownership": "string",
              "certificationStatus": "string",
              "externallyValidated": true
            },
            "hierarchyId": "string",
            "parentId": "string",
            "holdingId": "string",
            "ncsId": "string"
          },
          "preferences": {
            "enableConsole": true,
            "invoiceRecipient": true,
            "language": "string",
            "hidden": true
          },
          "layers": [...],
          "group": {
            "businessGroups": [
              {
                "name": "string",
                "foundedAt": 0,
                "id": "string"
              }
            ],
            "holding": {...},
            "companies": [{...}],
            "companiesSize": 0,
            "companiesIterator": {},
            "businessGroupsSize": 0,
            "businessGroupsIterator": {}
          },
          "layersSize": 0,
          "layersIterator": {}
        }
      }
    ]
}
```

</details>

For more information on individual fields, see [Item Structure](item-write.md#item-structure "Item Structure").

**HTTP 400**

One or more parameters in the request are incorrect, or mandatory parameters are missing.

**HTTP 401**

The authorization token has expired, is invalid, or was not provided.

**HTTP 403**

The authorization token is valid, but the user does not have permission to read the items.

**HTTP 500**

The server encountered an unexpected error while processing the request.

**HTTP 502**

The server encountered an error while communicating with a dependency service (e.g., the auth service is unavailable).

All error responses share the following body format:

    {
      "code": "string",
      "message": "string",
      "status": "string",
      "subErrors": [
        {}
      ],
      "timestamp": "dd-MM-yyyy HH:mm:ss"
    }

- **code**: Corresponds to the returned HTTP error code (e.g., `500`).
- **message**: The error message (e.g., `Internal server error`).
- **status**: A description of the HTTP error code (e.g., `Internal Server Error`).
- **subErrors**: Any nested errors.
- **timestamp**: The date and time when the error occurred.

## Checking if an item exists

Given a `taxId`, `vatNumber`, and `taxRegion`, you can check if an item with these characteristics exists by calling this API:

> [[HEAD] /api/v3/items](https://registry-read-dev.agyo.io/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/rest-api-controller-v-3/itemExists)

> This documentation refers to version 3 of the read APIs. V2 APIs are deprecated and should not be used for new integrations.

**Headers**

The required headers are described in the [Authentication and Headers](index.md#getting-started-authentication-and-headers) section.

The `Content-Type` must be `application/json`.

**Query Parameters**

- **identifier.taxId:** The item's tax ID (codice fiscale).
- **identifier.vatNumber:** The item's VAT number (partita iva).
- **identifier.taxRegion:** The item's tax region.

**Responses**

The operation succeeds only if the HTTP status code is `200`. Any other status code indicates an error.

**HTTP 200**

The item exists.

Response Body:

    {}

**HTTP 400**

One or more parameters in the request are incorrect, or mandatory parameters are missing.

**HTTP 401**

The authorization token has expired, is invalid, or was not provided.

**HTTP 403**

The authorization token is valid, but the user does not have permission to perform this check.

**HTTP 404**

The item was not found.

**HTTP 500**

The server encountered an unexpected error while processing the request.

**HTTP 502**

The server encountered an error while communicating with a dependency service (e.g., the auth service is unavailable).

All error responses share the following body format:

    {
      "code": "string",
      "message": "string",
      "status": "string",
      "subErrors": [
        {}
      ],
      "timestamp": "dd-MM-yyyy HH:mm:ss"
    }

- **code**: Corresponds to the returned HTTP error code (e.g., `500`).
- **message**: The error message (e.g., `Internal server error`).
- **status**: A description of the HTTP error code (e.g., `Internal Server Error`).
- **subErrors**: Any nested errors.
- **timestamp**: The date and time when the error occurred.
