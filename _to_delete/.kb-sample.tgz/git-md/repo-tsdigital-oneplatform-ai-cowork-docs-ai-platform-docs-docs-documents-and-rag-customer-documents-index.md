---
source_id: "git-md:repo-tsdigital-oneplatform-ai-cowork-docs-ai-platform-docs-docs-documents-and-rag-customer-documents-index"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/-/blob/6c617371f851e6ffa24e0fe0c27751375233fdb5/docs/documents-and-rag/customer-documents/index.md"
title: Customer Documents
authority: descriptive
version_hash: "sha256:fade99cf88b774bc89ba989d3a22578e7ae0aad6a3eca59c15555f7dffd91eb0"
body_hash: "sha256:fade99cf88b774bc89ba989d3a22578e7ae0aad6a3eca59c15555f7dffd91eb0"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/oneplatform/ai/cowork/docs/ai-platform-docs/docs/documents-and-rag/customer-documents/index.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Customer Documents

## Overview

Customer documents covers documents uploaded by or on behalf of a specific customer/workspace (PEC mailboxes, invoices, contracts, etc.) via **TS Documents**. Content is workspace-scoped: ingested through the K-Hub Ingestion Service, indexed with semantic embeddings, and searchable only by authorized users via policy-enforced access control.

**For legacy DocStore integrations,** see [Legacy: DocStore Integration](./legacy-docstore.md).

## Getting Started

### How Developers Integrate

Developers access TS Documents through the **TS AI Orchestrator**, which knows how to call the TS Documents MCP server. You do not call the MCP tool directly—the orchestrator handles authentication, workspace isolation, and access control transparently.

**Integration path:** Business Capability Developer → **TS AI Orchestrator** → **TS Documents MCP** → MCP tools (e.g., `semantic_document_search`, document retrieval)

**Example orchestrator call (pseudo-code):**

```python
# Your code calls TS AI Orchestrator with a request
result = await orchestrator.search_documents(
    query="Email addresses for client ABC?",
    resourceType="pec-manager",
    numResults=5,
)
# Orchestrator internally: calls TS Documents MCP tool with your context
# Returns: [chunk1, chunk2, ...] with scores and metadata
# Only content you are authorized to read
```

**Flow:**

1. You call TS AI Orchestrator with a search query and Resource Type
1. Orchestrator calls TS Documents MCP tool with your identity context (JWT, workspace)
1. MCP tool searches indexed documents and enforces access control
1. Results returned only for documents you're authorized to access

**You don't need to:** Write OAuth flows, manage JWT tokens, or handle authorization—the orchestrator and MCP server handle it transparently.

### Onboarding a New Resource Type

When a Business Unit needs semantic search for a new document category (HR documents, invoices, etc.), follow the phases below:

| Step              | Owner              | Action                                                                                                            |
| ----------------- | ------------------ | ----------------------------------------------------------------------------------------------------------------- |
| **Initiation**    | BU + Team Adoption | Define use case name, document types, visibility requirements                                                     |
| **Pre-config**    | TS Documents       | !!! warning "OPEN POINT" Pre-configuration before onboard? Contact TS Documents Team (<v.giudice@teamsystem.com>) |
| **Metadata**      | BU                 | Design document attributes for filtering                                                                          |
| **Ingestion**     | Team Adoption      | Set up the K-Hub pipeline and its ingestion configuration (see [Ingestion Service](./ingestion/index.md))         |
| **Configuration** | Team Adoption      | Configure Semantic Search Service and OPA access policies                                                         |
| **Testing**       | Team Adoption      | Validate search results and access control                                                                        |
| **Live**          | —                  | Use case available via TS Documents MCP tool                                                                      |

End-to-end workflow:

![Customer Documents Resource Type Onboarding Workflow](./semantic-search-service/workflow.mmd)

## Technical Details

- **[Ingestion Service](./ingestion/index.md)** — Document extraction, chunking, embedding, and indexing pipeline
    - [Configuration Reference](./ingestion/configuration.md) — Full YAML parameter reference for use-case setup
    - [Integration Guide](./ingestion/integration.md) — Onboarding and event publishing
    - [Publishing a Use Case](./ingestion/publishing.md) — Deployment operational guide
- **[Semantic Search Service](./semantic-search-service/index.md)** — Vector search over ingested documents for RAG applications (integrated in TSDocuments MCP)
    - [Implementation Details](./semantic-search-service/details.md) — API reference, configuration schema, policy examples

## Getting Help

| Question                                       | Contact                                                                            |
| ---------------------------------------------- | ---------------------------------------------------------------------------------- |
| How do I integrate TS Documents into my agent? | Team Adoption                                                                      |
| How do I configure a new use case?             | Team Adoption                                                                      |
| How do I define OPA access policies?           | Business Capability developers/PO + TS Documents Team (<v.giudice@teamsystem.com>) |
| Where do I report search quality issues?       | Team Documents AI — <t.scardoni@teamsystem.com>                                    |

!!! warning "OPEN POINT"

    **Developer communication channel** — How developers are contacted about ingestion status or failures is **not yet documented**. Clarify with TS Documents Team.
