---
source_id: "git-md:repo-oneplatform-tsdataplatform-data-governance-ts-dataplatform-datagovernance-documentation-docs-solution-witboost-whatis-solution-wb"
source_type: git-md
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/-/blob/256aaa023d7a1968e3a84c8985dae5a7c2db39ff/docs/solution-witboost/whatis-solution-wb.md"
title: Soluton in Witboost
authority: descriptive
version_hash: "sha256:b5cebaadc73b969589b885b537f6ffe73564e8489f174e32a1f3e2dc14a903ed"
body_hash: "sha256:7f6a10861fafeb4b8703f401e55cf4def5169e1b90f1014825b997fa4e37652d"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/tsdataplatform/data-governance/ts-dataplatform-datagovernance-documentation/docs/solution-witboost/whatis-solution-wb.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Soluton in Witboost

## 1. What is a Solution ?

A Solution represents a module of business application (a commercialized Product) that generates data and potentially consumes from other solutions data.

Many of these applications over the years have developed several roles and features, making many tools "one hammer for all nails" becoming cross-domain. In the context of the DataPlatform, a Solution is a Source System which can host one and only one Hermes Producer instance.

### 1.1 What is a Solution within the Data Platform ?

In the Data Platform powered by Witboost, a Solution represents a specific **Source System** for a given domain.

As for the other systems (source systems or Dataproducts), every instance of a Solution **belongs to a business domain**. It could be composed by specific component types (at writiing time only Hermes Producers).

### 1.2 What a Solution is used for

A **Solution** is used to:

* mapping (metadata) TeamSystem Solution concepts to Data Platform entities, one foreach defined business domain
* making Solution components discoverable and governed
* building up the topic names and thus improving consistency with the Data Platform's Hermes Topics feature  already release - Hermes Outputports template supports the selection of the Solution from a drop down of all available Solution for that domain
* building up the target topic prefix of the Hermes Producer

### 1.3 Behavior and characteristics

A Solution:

* **does not produce side effects once provisioned or unprovisioned** - as for now it has a metadata only purpose
* **there will be one Solution instance foreach domain it has to be operate in** - a specific TeamSystem's Solution concept will be decomposed in one Solution foreach domain
* > ❗ **The Solution Name must be chosen accurtely** becasue the **solution infix** in the non-legacy topic names and related target prefixes of producers are derived from it by applying the following **normalization** approach:
  * to lowercase
  * no spaces
  * remove other chars than alphanumeric

## 2. Development Guidelines 

### 2.1 Getting Started

To start working with Solutions, Witboost's ** Solution Template (Use Case)** should be picked up.

Please, Refer to the [Witboost templates page](https://witboost-ui.dataoneplatform.teamsystem.cloud/templates?category=all&filters%5Bgenerates%5D=systemtype%3Adefault%2Fsourcesystem&filters%5Btags%5D=solution&filters%5Buser%5D=all&filters%5Bkind%5D=template&limit=20) to instantiate a Solution project. You can find the template within the *Source System* section.

### 2.2 How to use a Solution

> Please check out the Solution's project doc in the related `Docs` tab of the Solution project once created, for more info.
![Solution doc tab sample](solution-doc-sample.png)

### 2.3 Policies and Check

> Please check out the Solution's project doc in the related `Docs -> Policies and Checks` tab of the Solution project once created, for more info.

#### Fixed contraints

* **kind** property: fixed to `sourcesystem`
* **projectKind** property: fixed to `system`
* **sourceName** property: fixed to `Solution`

#### Semantic constraints

* **producer arity limit**: at most one producer component type foreach Solution (# producers <= 1)

### 2.4 Handling backward Solution names consistency

A number of Hermes Topics (Outputport components) have already been provisioned within the Data Platform prior the introduction of the "Solution" concept as a Source System.

For those managed by Witboost (non-legacy), users used to introduce a free text as the solution name infix (e.g. public.com.teamsystem.streaming.tax.`fic`.entity.f24.v1).

To ensure backward compatibility and consistency between esisting Hermes Topics managed by Witboost, the data Platform itself enforces a naming convention to minimise exceptions: the topic's solution name as infix should be the related 
> *solution name, in lowercase, with no spaces, alphanumeric characters only*.

The (only 2) pre-existing exceptions are listed below. these have been added to a whitelist to allow the creation of topics for these Solutions in line with the existing conventions with no disruption for the end users:

* **payment-obligations**
* **reference-implementation**
