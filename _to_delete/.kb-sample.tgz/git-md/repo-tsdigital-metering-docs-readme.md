---
source_id: "git-md:repo-tsdigital-metering-docs-readme"
source_type: git-md
duplicate_of: git-md:repo-paas-services-m3-docs-readme
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/tsdigital/metering/docs/-/blob/dea2f3652460ac7331dc5ba60bd80268f4daa476/README.md"
title: Getting started
authority: descriptive
version_hash: "sha256:0fd4d23f06bae67d6266a7ad322b1e092d96d04fdfce4f8860c18cd669a2e23b"
admission: refused
admission_rule: duplicate_of
admission_reason: "exact duplicate of the already-admitted canonical git-md:repo-paas-services-m3-docs-readme — elected by the duplicate detector, consumed here, not re-decided"
admission_model: rule:screen-admission@1
admission_at: 2026-07-29T22:11:01Z
body_hash: "sha256:0fd4d23f06bae67d6266a7ad322b1e092d96d04fdfce4f8860c18cd669a2e23b"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:tsdigital/metering/docs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/tsdigital/metering/docs/README.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
## Getting started

This repo is managed by [Develop Portal](https://developers.teamsystem.com/).
Use this repo to explain the general documentation of project M3.

## Collaborate with your team

To change the documentation create a new PR and wait for approval from another team member.
All commit **must** use a subset of conventional commit. Then use:

- **docs**: to change or add the documentation.
- **typo**: to fix grammar or vocabulary errors.
- **chore**: for all technical change required by backstage.

## Resources

- [Develop Portal](https://developers.teamsystem.com/)
- [Backstage Docs](https://backstage.io/docs/overview/what-is-backstage)
- [Mkdocs Docs](https://www.mkdocs.org/user-guide/writing-your-docs/)
- [Markdown Guide](https://www.markdownguide.org/)
- [Conventional Commit](https://www.conventionalcommits.org/en/v1.0.0/)
