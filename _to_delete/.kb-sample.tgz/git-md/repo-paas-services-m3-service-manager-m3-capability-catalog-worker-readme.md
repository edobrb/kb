---
source_id: "git-md:repo-paas-services-m3-service-manager-m3-capability-catalog-worker-readme"
source_type: git-md
duplicate_of: git-md:repo-paas-services-m3-service-manager-m3-capability-catalog-read-readme
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/paas/services/m3/service-manager/m3-capability-catalog-worker"
title: Project
authority: descriptive
version_hash: "sha256:aef8e3e045924bd16fa584c0ae896bd27f561d23af029457aacd7767db15a348"
admission: refused
admission_rule: duplicate_of
admission_reason: "exact duplicate of the already-admitted canonical git-md:repo-paas-services-m3-service-manager-m3-capability-catalog-read-readme — elected by the duplicate detector, consumed here, not re-decided"
admission_model: rule:screen-admission@1
admission_at: 2026-07-29T22:11:01Z
body_hash: "sha256:aef8e3e045924bd16fa584c0ae896bd27f561d23af029457aacd7767db15a348"
lang: en
source_langs: [en]
fetched_at: "2026-07-24"
ingested_from: "git-md-connector:paas/services/m3/service-manager/m3-capability-catalog-worker"
index_status: pending
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/paas/services/m3/service-manager/m3-capability-catalog-worker/README.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
# Project

This project is a boilerplate for a microservice that uses Quarkus, the Supersonic Subatomic Java Framework, Kotlin, Maven and Hexagonal Architecture.

## Prerequisites

- JDK 21 or later
- Maven 3.9.0 or later
- Docker env or equivalent(ex: Podman with docker compatibility)
- Quarkus CLI 3.13.0 or later
- Node.Js installed on your system

## Related Guides

- Kotlin ([guide](https://kotlinlang.org/docs/home.html)): Write your services in Kotlin
- Maven ([guide](https://maven.apache.org/)): Build your project with Apache Maven
- Quarkus ([guide](https://quarkus.io/guides)): Quarkus offers a full-stack framework (RESTEasy, Hibernate Validator, Netty, SmallRye Config, SmallRye OpenAPI, SmallRye Health, SmallRye Metrics, Eclipse Vert.x, and many others) tailored for GraalVM and OpenJDK HotSpot.
- Hexagonal Architecture ([wiki](https://en.wikipedia.org/wiki/Hexagonal_architecture_(software))): The hexagonal architecture, or ports and adapters architecture, is an architectural pattern used in software design. It aims at creating loosely coupled application components that can be easily connected to their software environment by means of ports and adapters. [[guide 1](https://jmgarridopaz.github.io/content/hexagonalarchitecture.html)][[guide 2](https://netflixtechblog.com/ready-for-changes-with-hexagonal-architecture-b315ec967749)]

## Prepare the project

Give execute permission to the script `install-hooks.sh` and run it to install the git hooks.

```shell script
chmod +x install-hooks.sh
./install-hooks.sh
``` 
### Git Hook: `commit-msg`

This script is a Git hook that runs after a commit message is created but before the commit is actually recorded. The purpose of this hook is to validate the commit message using `commitlint`. The commit message must follow the [conventional commit](https://www.conventionalcommits.org/en/v1.0.0/) format. If the commit message does not follow the format, the commit will be rejected.

### Git Hook: `pre-commit`

This script is a Git hook that runs before a commit is made. The purpose of this hook is to ensure that the code adheres to the project's formatting standards by using the `spotless:check` Maven goal.

### Git Hook: `prepare-commit-msg`

This script is a Git hook that runs before the commit message editor is opened but after the default message is created. The purpose of this hook is append to the commit message the string `[SKIP CI]` if the commit contains only file .md, .yml or .json. This will prevent the CI/CD pipeline from running for commits that only change documentation or configuration files.

## Running the application in dev mode

You can run your application in dev mode that enables live coding using:

```shell script
mvn quarkus:dev
```

> **_NOTE:_** Quarkus now ships with a Dev UI, which is available in dev mode only at http://localhost:8080/q/dev/.

## Upgrade Project

To upgrade the project to the latest version of Quarkus, run the following command:

```shell script
quarkus upgrade
```

## Prepare new Project

Create a new folder for the new project and copy the contents of this project to the new folder with all hidden files and folders except the `.git` folder.

```shell script
mkdir new-project
cp -r * new-project
cp -r .mvn/ new-project
cp -r .quarkus/ new-project
cp -r .githooks/ new-project
```
execute the script `ìnstall-hooks.sh` to install the git hooks.

```shell script
chmod +x install-hooks.sh
./install-hooks.sh
```

Open the `pom.xml` file and change the `artifactId` from `base` to the new project name and propagate the changes to the other files.
Next you need to remove all the modules that are not necessary for the new project.
Next, you need to change namespace `boilerplate` with the new project namespace. When you complete these steps, you can start developing your new project and remove this section from readme file.


## Add Githooks to an existing project

In case you want to add githooks to an existing project you need to copy both the following folder and file in your project's root directory

- /.githooks
- install-hooks.sh

Then remove .gitlab-ci.yml file from the .githooks folder

```shell script
rm .githooks/.gitlab-ci.yml
```
After that, proceed by executing `install-hooks.sh`

```shell script
chmod +x install-hooks.sh
./install-hooks.sh
```
