---
source_id: "adr:repo-oneplatform-adrs-platform-adr0008-hermes-architecture"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0008_hermes_architecture.md"
title: "ADR0008 Hermes: Kappa Architecture"
authority: binding
version_hash: "sha256:b63ce2f1a45ba6905a5ab3ba643e5c1428713b4a21fbacbc48681d5059c4b32e"
body_hash: "sha256:e6ab45be467a5d00f73d25bc59d3c7810e423ed5cd6c1e0dae87278876bd638c"
lang: en
source_langs: [en]
last_modified: "2025-10-13"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0008_hermes_architecture.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 806256725 -->
<!-- confluence-space-key: CTO -->

# ADR0008 Hermes: Kappa Architecture

### Status

Accepted.

## Summary

This ADR introduces the adoption of **Kappa Architecture
** in TeamSystem. This ADR makes clear the role of Hermes within TeamSystem's enterprise data architecture.

### Key Concepts

#### Hub-and-Spoke Pattern

In the hub-and-spoke pattern, all event streams publish data to a central hub, while all consumers retrieve it from there. This approach centralizes data flow management, simplifying integration and improving system scalability.

![Hub and Spoke](./resources/ADR0008_hermes_architecture_hub_and_spoke.png)

#### Convergence

In the Kappa Architecture, convergence refers to the unification of real-time and batch processing into a single layer. Unlike the Lambda Architecture, which separates these concerns into distinct pipelines, Kappa Architecture processes all data as a continuous stream.

Hermes is used for both for the following purposes (using the same resources/topics):

- operational integration between applications
- feed data products of analytical purposes

#### Immutability and Single Source of Truth

Hermes, as a central component of the Kafka-based Kappa Architecture, adopts an immutability model. Each message published to a Kafka topic is immutable, ensuring data integrity and allowing reprocessing when necessary. This model of event storage in append mode, rather than using a CRUD approach, makes Hermes function as an "immutable commit log."

In this way, Hermes becomes the single source of truth for real-time data processing. By centralizing all data streams, it ensures consistency and reliability throughout the system, eliminating discrepancies that may arise from multiple data sources. As a result, all downstream systems and data products can rely on Hermes for accurate and up-to-date information.

#### Data reprocessing and backfill

In our context, the Kappa Architecture does not imply retaining the entire historical dataset in Kafka. Instead, it involves maintaining a sufficiently large persistence window to ensure effectiveness while allowing data to be reloaded from the data lake,without process or transformation, if reprocessing is required.
_For further details, refer to the ADR on Retention._

### Issue

The Kappa architecture addresses several issues commonly encountered in data processing systems:

1. **Complexity of Maintaining Separate Batch and Stream Processing Pipelines**  
   Traditional Lambda architecture requires maintaining two separate data flows for batch and stream processing, leading to increased complexity and potential inconsistencies. Kappa architecture simplifies this by using a single stream processing pipeline and ensuring eventual consistency.

2. **Real-Time Data Processing Needs**  
   Many modern applications require real-time insights and decisions. Kappa architecture is designed to handle continuous data streams, enabling near real-time processing and analytics.

3. **Scalability Challenges**  
   By leveraging distributed stream processing frameworks, Kappa architecture can scale horizontally to handle large volumes of data efficiently. Furthermore, it allows to easly plug and play additional data consumers to support further use cases.

4. **Data Latency**  
   Batch processing in Lambda architecture introduces latency due to periodic batch jobs. Kappa architecture eliminates this latency by processing data as it arrives.

5. **Operational Overhead**  
   Maintaining and synchronizing batch and stream systems in Lambda architecture increases operational overhead. Kappa architecture reduces this by unifying the ingestion model and potentially enabling common data stream processing.

6. **Error Handling and Reprocessing**  
   Kappa architecture allows for easier reprocessing of data by replaying the event log, which is particularly useful for debugging and recovering from errors.

7. **Adaptability to Evolving Requirements**  
   With a single processing pipeline, Kappa architecture is more adaptable to changes in business requirements or data processing logic. By having a single offloading flow from the sources, it's easier to propagate any changes to the event payload to all downstream systems with minimal effort, compared to a Lambda architecture where multiple processing paths might require more complex updates.

These advantages make Kappa architecture a suitable choice for systems requiring simplicity, scalability, and real-time processing capabilities.

### Decision

Adopt the **Kappa Architecture
** as the foundational approach to manage both real-time and batch data processing. This decision is driven by its alignment with the project's objectives of simplicity, consistency, scalability, and low-latency processing.

## Details

### Assumptions

- Real-time data processing is a core requirement.
- The system must scale horizontally to handle increasing data volumes and number of consumer data systems.
- It's desirable to lower the costs of data integration and maitenance.

### Considered Alternatives

1. **Lambda Architecture**  
   Pros: Established pattern, supports batch and stream processing.  
   Cons: Increased complexity, higher operational overhead, higher risk of data inconsistency.
