---
source_id: "adr:repo-oneplatform-adrs-platform-adr0012-serverless-protection-guidelines"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0012_serverless_protection_guidelines.md"
title: ADR0012 Serverless Internet-Facing Services Protection Guidelines
authority: binding
version_hash: "sha256:06858e6765ad8e3e75385d78769871cba0f985c9a58eb9142db94a4661ffde04"
body_hash: "sha256:fb37cc16130684e4d0bc9b3e1191a8b48de9445995150278bd51ef0d0c1efb1d"
lang: en
source_langs: [en]
last_modified: "2025-10-13"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0012_serverless_protection_guidelines.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 805765262 -->
<!-- confluence-space-key: CTO -->

# ADR0012 Serverless Internet-Facing Services Protection Guidelines

### Status

Accepted.

## Summary

This Architectural Decision Record establishes mandatory security and cost control measures for any serverless service exposed to the internet. All such services must configure maximum concurrency (or equivalent cost limits), apply rate limiting mechanisms, and be protected by a Web Application Firewall (WAF) to mitigate risks such as DDoS attacks. The guideline aims to ensure operational stability, security, and predictable cost management for critical, publicly accessible workloads.

### Issue

Serverless architectures (e.g., AWS Lambda, Azure Functions, GCP Cloud Functions) enable highly scalable and event-driven applications but expose organizations to specific risks when services are accessible from the public internet:

- Cost explosion in case of traffic spikes or malicious floods.

- Service disruption due to uncontrolled concurrent execution.

- Security vulnerabilities through HTTP-based or volumetric attacks.

Without a standard, there is inconsistency in how services handle these risks, resulting in a fragile, high-risk system landscape.

### Decision

All serverless services exposed to the public internet must adhere to the following mandatory controls:

- **Concurrency or Cost Limit**

    - Set a maximum concurrency limit (e.g., reserved concurrency for AWS Lambda) or enforce alternative mechanisms to cap overall cost exposure.

    - The limit must be aligned with expected legitimate peak traffic + acceptable buffer.

- **Rate Limiting**

    - Implement rate limiting at API Gateway, Load Balancer, or service level to control incoming request rates.

    - Rate limits must be tuned to typical usage patterns, factoring in security margins to absorb natural fluctuations without service degradation.

- **Web Application Firewall (WAF) Protection**

    - All internet-facing endpoints must be protected behind a WAF capable of detecting and mitigating common web attacks (e.g., SQLi, XSS) and volumetric anomalies (e.g., HTTP floods).

    - WAF rules should be kept updated and tuned according to service characteristics.

## Details
