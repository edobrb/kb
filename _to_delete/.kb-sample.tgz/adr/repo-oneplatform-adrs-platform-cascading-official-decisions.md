---
source_id: "adr:repo-oneplatform-adrs-platform-cascading-official-decisions"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/cascading-official-decisions.md"
title: "ADR: Cascading Official Decisions"
authority: binding
version_hash: "sha256:f073220a85684d19e7f6bbd55a0857d8504c3176d0505143cfaed4561c6d4717"
body_hash: "sha256:f073220a85684d19e7f6bbd55a0857d8504c3176d0505143cfaed4561c6d4717"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/cascading-official-decisions.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1386479620 -->
<!-- confluence-space-key: CTO -->
# ADR: Cascading Official Decisions

### Status

Proposed (2026-01-23) — Open to discussion. Applies to R&D Teams.

## Summary

### Issue

Platform and governance committees periodically make decisions that affect multiple teams (e.g., platform deprecations, new standards, tooling changes). Today, communication is inconsistent across teams and channels, and is often passed down by word of mouth causing unclear "source of truth" and unclear deadlines.

### Decision

We will use a single, repeatable cascade process for **official committee decisions**, using the Development Portal as the single source of truth, an official Teams channel for announcements, and POs/Engineering Managers for people cascade.

## Details

### Assumptions

- POs and Engineering Managers are the right cascade points to reach all R&D team members.
- The Development Portal is accessible to all impacted teams and can serve as the single source of truth.
- An official read-only Teams channel can be set up with restricted posting rights.

### Constraints

- The official Teams channel must be **read-only for announcements** (posting restricted to designated publishers).
- Questions and discussion happen via replies/threads under the announcement.
- Portal pages must include: what changed, why, effective date, impacted teams, required actions (if any), and links to related resources. If required actions are present, all needed information to complete them must be included.
- Teams posts must include: a short summary + portal link + effective date (if any).

### Positions

**Cascade channels (in order):**

1. **Development Portal (single source of truth):** one page per decision/change with the information teams need to understand and act.
2. **One official Teams channel (R&D-wide):** a short announcement that links to the portal page.
3. **People cascade:** all **POs** and **Engineering Managers** cascade to their reports and collect questions and drive adoption.
4. (optional) **Monthly Platform newsletter:** recap of the month's announcements, linking back to the portal pages.
5. (optional) **Targeted email to POs and Engineering Managers:** use for high urgency/high impact items that must not wait for the newsletter.

**Roles:**

- **Decision owner:** accountable for content accuracy and follow-ups.
- **Comms publisher:** publishes to portal + Teams + newsletter.
- **POs + Engineering Managers:** responsible for cascading to their teams and driving adoption.

### Argument

- Always explain the rationale ("why") and the intended benefit.
- Avoid forcing disruptive changes without a clear motivation.
- A single repeatable process reduces ambiguity around source of truth and deadlines.

### Implications

**Updates and corrections:**

- Minor clarifications: update the portal page and reply in the original Teams thread.
- Major changes (timeline, scope, required actions): update the portal page and publish a new Teams announcement that links back to the original decision. Update the old post to indicate it has been superseded.

## Related

### Related Decisions

_None identified yet._

### Related Requirements

_None identified yet._

### Related Artifacts

_None identified yet._

### Related Principles

_None identified yet._

## Notes

**Open questions (TBD):**

- How to track adoption/compliance per team?
- How to track blockers or issues to the adoption?
- When does an update require a new announcement vs a page-only update?
- Is it possible to automate parts of this process (e.g., Teams posting)?
- How to handle notifications/reminders for effective dates, if needed?

**Open items (TBD):**

- Name of the official Teams channel.
- Who owns the monthly Platform newsletter and distribution list.
- Templates for channel and email announcements.
- Templates for decision pages on the Development Portal.
