---
source_id: "adr:repo-oneplatform-adrs-platform-adr0023-runtime-enrollment-client-credentials"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0023_runtime_enrollment_client_credentials.md"
title: ADR0023 Runtime Enrollment Client Credentials
authority: binding
version_hash: "sha256:9f3e1750047f726aba176eda51999a1fae37d901d9b9e890ce127ccd85828e32"
body_hash: "sha256:b640a9ea5f1f511312a9013000376cfac82f22cb4ad4613f3189439085e4d2d6"
lang: en
source_langs: [en]
last_modified: "2026-06-28"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0023_runtime_enrollment_client_credentials.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1789591609 -->
<!-- confluence-space-key: CTO -->

<!-- confluence-page-id:  -->
<!-- confluence-space-key: CTO -->
<!-- synchronized: false -->

# ADR0023 Runtime Enrollment Client Credentials

*(Extension of ADR0010 – Client Credentials & Token Management)*

## Status

Permanent – this ADR extends the scope of ADR0010 to Runtime Enrollment scenarios.

## Summary

This ADR extends ADR0010 to cover scenarios where an application obtains a `clientId` and `clientSecret` through Runtime Enrollment.

Runtime Enrollment is responsible only for creating a new technical identity.

The resulting credentials can be used with the OAuth2 `client_credentials` flow to authenticate the client and obtain an access token.

Authentication and authorization are separate concerns.

Access to protected resources depends exclusively on the policies assigned to the `clientId` through Policy Manager and not on possession of the `clientSecret` or the access token itself.

Assigning policies requires an identity that is authorized to manage permissions for the company (Item). This role may be performed by Digital Technical Keys or by any other identity that has been granted the same administrative permissions.

### Issue

ADR0010 defines the machine-to-machine identity model based on OAuth2 Client Credentials and Policy Manager.

With Runtime Enrollment, an application can dynamically obtain a new technical identity (`clientId`, `clientSecret`).

It must be clarified that such identities follow the same model defined by ADR0010 and that the enrollment process does not alter the separation between:

- Identity provisioning
- Authentication
- Authorization

### Decision

This ADR does not introduce a new authorization model.

Clients generated through Runtime Enrollment are subject to the same rules defined in ADR0010:

- Runtime Enrollment generates a new technical identity (`clientId`, `clientSecret`).
- OAuth2 `client_credentials` enables authentication of that identity.
- An access token represents an authenticated identity but does not grant permissions.
- Permissions must be explicitly assigned by associating one or more policies to the `clientId`.
- Policy Manager remains the authoritative authorization system.
- Associations between `clientId` and policies are performed through the Identity Profile `add-permission` APIs.
- Assigning policies requires an identity that holds administrative permissions on the company (Item).
- In OnePlatform, the Item represents the unique identifier of a company.
- Digital Technical Keys may perform this administrative role, as well as any other identity authorized to manage company permissions.

## Details

### Assumptions

- The OAuth2 `client_credentials` model defined in ADR0010 remains unchanged.
- Runtime Enrollment is a legitimate mechanism for automated technical identity provisioning.
- Policy Manager is the platform authorization system.
- Identity Profile exposes the APIs required to manage authorization assignments.

### Constraints

- Runtime Enrollment does not grant permissions.
- Authentication does not grant permissions.
- Permissions must be explicitly associated with a `clientId`.
- Possession of a `clientSecret` does not grant application privileges.
- Possession of an access token does not grant application privileges.
- Policy assignment requires explicit administrative permissions on the company.

### Argument

This ADR does not introduce new authentication or authorization mechanisms.

Its sole purpose is to clarify that identities created through Runtime Enrollment must be treated exactly like any other machine-to-machine identity within the platform.

Runtime Enrollment creates a new technical identity represented by a `clientId` and a `clientSecret`.

OAuth2 `client_credentials` allows that identity to authenticate and obtain an access token.

The access token proves the identity of the authenticated client.

Authorization is a separate and subsequent process. Access to protected resources is determined exclusively by the policies associated with the `clientId`.

Assigning policies requires an identity that has permission to manage company-level authorizations. In OnePlatform, this role may be performed by Digital Technical Keys or by any other identity authorized to manage permissions for the company.

```text
┌──────────────────────────────────────────┐
│            TECHNICAL IDENTITY            │
└──────────────────────────────────────────┘

Runtime Enrollment
        ↓
clientId + clientSecret
        ↓
OAuth2 Client Credentials
        ↓
Authentication
        ↓
Access Token


┌──────────────────────────────────────────┐
│              AUTHORIZATION               │
└──────────────────────────────────────────┘

Identity with
"Assign Permissions"
permission on the
Company (Item)

(e.g. Digital Technical Keys)

        ↓
add-permission
        ↓
clientId → Policy
        ↓
Authorization
        ↓
Access to Protected Resources
```

This model maintains a clear separation between:

- Identity provisioning
- Authentication
- Authorization

In accordance with Zero Trust principles, no privilege is implicitly derived from obtaining credentials or an access token. Privileges are determined exclusively by the policies assigned to the `clientId`.

## Related

### Related Decisions

- [ADR0010 – Client Credentials & Token Management](./ADR0010_client_credentials.md)

### Related Requirements

- Policy Manager as the single authorization system
- Explicit `clientId → policy` binding
- Separation of authentication and authorization

### Related Artifacts

- 20250611 – Architecture Review – M2M Process

### Related Principles

- Zero Trust
- Least Privilege
- Separation of Duties

## Notes

ADR0023 shall be considered an extension of ADR0010 and not a variation of it.

All principles, constraints, and mechanisms defined in ADR0010 remain unchanged and apply equally to clients created through Runtime Enrollment.
