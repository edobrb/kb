---
source_id: "adr:repo-oneplatform-adrs-platform-adr0002-data-store-tiers"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0002_data_store_tiers.md"
title: ADR0002 Data Store Tiers
authority: binding
version_hash: "sha256:623cb9b0353ff609ada4c25d424a01a05725921af89c05f7c451e94ff8ff1ef5"
body_hash: "sha256:3e3b9e955ba1a18eb0a5835c20b689ec9245b38f6abd8f3eca46f2f7e1779165"
lang: en
source_langs: [en]
last_modified: "2026-05-21"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0002_data_store_tiers.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 805634236 -->
<!-- confluence-space-key: CTO -->

# ADR0002 Data Store Tiers

### Status

Deprecated. No longer relevant.

## Summary

This ADR describes 4 tiers of Service Agreement for data-store systems employed by OnePlatform services.

### Issue

Storing data is tricky. Could be highly expensive or very volatile.

We need a simple way to establish what is the Service Agreement that a specific data store must implement.

### Decision

We divide our data-store service agreements in tiers:

- **Tier 3:** Business Critical - data must always be available
- **Tier 4:** Source of Truth - data must not be lost
- **Tier 5:** Expensive Cache - data should be restored
- **Tier 6:** Commercial Cache - data can be reconstructed
- **Tier 7:** Volatile Cache - data can be lost

🔥 Whenever a Product Team needs to create a new Data Store, they are required to produce a Product ADR to describe such decision, and associate it with a Service Tier as described in this document 🔥

> 🧐 Why 4, 5, 6?
>
> The most important reason is Star Wars movies. The first blockbuster enterprise to apply Open/Closed principle to Hollywood!
>
> But then there is Open/Closed principle. We may want to introduce upper leverls (High Availability?) in the future

## Details

👉 Refer to [Notes / Implementation](#notes--implementation) for details.

### Constraints

- Design To Cost: we can't blindly choose high availability services when not
  needed

### Related Principles

- Design To Cost

## Notes / Implementation

### Tier 3 - Data Must Always Be Available

This tier represents BUSINESS CRITICAL SOURCE OF TRUTH for our system and should be highly available:

- Data is geo replicated
- Data is has built-in redoundancy

Requirements:

- The data-store must provide PIT recovery capabilities
- The data-store must provide full data audit logs
- The data-store must provide performances monitoring services
- The data-store must provide automatic PIT data-recovery strategy

🔥 High Availability should be provided in the SLA of the service 🔥

🔥 We should NOT be directly responsible for those 🔥

### Tier 4 - Data Must Not Be Lost

This tier represents SOURCE OF TRUTH for our system and should be highly reliable:

- Data is business-critical
- Data can not be rebuilt from other sources

Requirements:

- The data-store must provide PIT recovery capabilities
- The data-store must provide full data audit logs
- The data-store must provide performances monitoring services
- The data-store must provide automatic PIT data-recovery strategy

> High Availability should not be required here as not all our services have legal requirement on HA. Shall we need it, should become Tier3 (or Tier0).

These data-store services should be purchased as fully maintained services fromt the Cloud Provider or external supplier.

🔥 We should NOT be directly responsible for those 🔥

👉 These data-stores should work mostly in append-only mode as so to optimize performances and disk management.

👉 These data-stores should be small and domain-centric as so to better exploit the in-memory caching capabilities that almos any implementation offers.

👉 These data-stores should choose establised and reliable tech. We should avoid at all costs relatively new and cool systems for this tier.

### Tier 5 - Data Should be Restored

This tier represents a cache layer that is:

- business-critical
- expensive to rebuild from the source of truth

Requirements:

- All the data strored in this tier can be re-created starting from the tiers above
- All data stored in this tier can be lost without causing business discontinuity
- The data-store must provide PIT recovery capabilities
- The data-store must provide automatic data-recovery strategy

### Tier 6 - Data Can Be Reconstructed

This tier represents a cache layer that is:

- business-critical
- **not expensive to rebuild** from the source of trut

Requirements:

- All the data strored in this tier can be re-created starting from the tiers above
- All data stored in this tier can be lost without causing business discontinuity
- Importand downtime in the system (while rebuilding, up to 24h?) must not cause business discontinuity
- The system must employ automatic self-healing mechanics
- The self-healing mechanic must be documented and consented by the Architects
- The self-healing mechanic must be periodically tested

### Tier 7 - Data Can Be Lost

This tier represents a volatile cache layer that is:

- not business-critical
- not expensive to rebuild

Requirements:

- All the data strored in this tier can be re-created starting from the tiers above
- Importand downtime in the system (while rebuilding, up to 7d?) must not cause business discontinuity
- The system SHOULD employ automatic self-healing mechanics
- The self-healing mechanic must be documented and consented by the Architects
- The self-healing mechanic must be periodically tested
