---
source_id: "adr:repo-oneplatform-adrs-platform-adr0003-application-token-envelope"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0003_application_token_envelope.md"
title: ADR0003 Application Token Envelope
authority: binding
version_hash: "sha256:eee8eb74ffa6c336a3138a3d77c5ccd108801d8096a9bfe0c81f71c7eabbd48c"
body_hash: "sha256:2cfb37ad15b16f50a963292eca1ef219f265d96279285759951650cfb2405ac2"
lang: en
source_langs: [en]
last_modified: "2022-05-05"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0003_application_token_envelope.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 805372066 -->
<!-- confluence-space-key: CTO -->

# ADR0003 Application Token Envelope

### Status

**Deprecated — as of 2025-04-14**: it refers to the old login app that is deprecated

## Summary

This ADR describes how the OnePlatform Application Token works, and how to validate it.

### Issue

We currently use the TSID Application Token as mean of Authentication across all TeamSystem services.

There are a few security concerns about this approach

- TSID AT represents a User devoid of any contextual information
- TSID AT lacks of ways to decorate contextual informations such as scope, issuer, ...
- Using TSID AT exposes the entire pool of services to be a uniform surface of attack (XSS, Token spoofing, ...)

### Decision

- OnePlatform is the only client to the TSID Authentication service
- OnePlatform handles the RefreshToken server-side
- OnePlatform provides authorized Apps with a Bearer Token (opaque) used to generate enveloped Access Tokens
- OnePlatform rotates the Bearer Token at every exchange
- OnePlatform signs the Enveloped Access Token with JWKs certificates
- OnePlatform exposes an OAuth2 compatible API for the remote verification of an Access Token
- OnePlatform extends the TSID Access Token with scoped claims
- OnePlatform control the TTL of its own Access Token, such TTL can be randomic

## Details

👉 Refer to [Notes / Implementation](#notes--implementation) for details.

### Assumptions

Most of our existing services trust the TSID and can validate its Access Token using JWKS standard APIs.

### Constraints

We can't ask existing services to radically change the Access Token verification mechanism.

### Implications

With the extended claims, each issued Access Token will be decorated with _scope
claims_ such as the AppID that has claimed it.

🔥 A target backend serivice can apply early ACL by denying any request from AppIDs that are not allowed, even before formally validating the token 🔥

## Related

## Notes / Implementation

- The scoped claims are stored under the `https://teamsystem.com/one-platform/jwt/claims` key.

### Backward Compatibility

🔥 **Existing services must be able to progressively adopt the Enveloped Access Token** 🔥

Initially, _OnePlatform JWKS will concatenate
TSID's_. This way, an existing service needs to just change the URL where to fetch such keys for validation.

By introspecting the successful JWKS key, the verifier will know whether an Access Token was released by TSID or OnePlatform. And act accordingly.

Existing services will simply ignore the OnePlatform claims, they can take the necessary steps to improve their Authorization layer, on their own roadmap.

For this reason, OnePlatform claims MUST be considered always optional during a transition phase.

### Transition Period

We can keep the transition period open for as long as we want.

The only drawback is that we (OnePlatform) can't use the Enveloped claims as must have.

> I strongly suggest for an as short as possible transition period, as so to be able to implement compartimentalized ACL as soon as possible.
