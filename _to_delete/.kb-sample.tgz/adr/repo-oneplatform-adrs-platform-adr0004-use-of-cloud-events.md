---
source_id: "adr:repo-oneplatform-adrs-platform-adr0004-use-of-cloud-events"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0004_use_of_cloud_events.md"
title: ADR0004 Cloud Events Adoption
authority: binding
version_hash: "sha256:005a8e831a4a9804c3c3c771ceb054b670bea31517b7b176aa02a11aa3521153"
body_hash: "sha256:5ff4f267239d19164717506eea6f37c8c44ce1df12955e67b27f8b6d9dec1296"
lang: en
source_langs: [en]
last_modified: "2022-05-11"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0004_use_of_cloud_events.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 805273720 -->
<!-- confluence-space-key: CTO -->

# ADR0004 Cloud Events Adoption

### Status

Accepted.

## Summary

This ADR describes the adoption of Cloud Events for the events that transit through Hermes.

### Issue

We need to uniform the way application exchange events using a common format;

### Decision

CloudEvents is a specification for describing event data in a common way.\
With its adoption the developers would no longer have to worry about how to deal with various events coming from different systems and platforms.\
CloudEvents provides SDKs for Go, JavaScript, Java, C#, Ruby, PHP, PowerShell, Rust, and Python\

## Details

[See: Notes / Implementation](#notes--implementation)

### Assumptions

Most of the teams are using a language supported by the SDK.

### Constraints

Collaborative platform talking through commong language;

Design to maintain: adopting a CNCF standard, well documentend, simplify onboarding or ownership handover;
