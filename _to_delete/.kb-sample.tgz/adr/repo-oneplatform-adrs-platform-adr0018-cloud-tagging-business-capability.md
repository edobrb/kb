---
source_id: "adr:repo-oneplatform-adrs-platform-adr0018-cloud-tagging-business-capability"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0018_cloud_tagging_business_capability.md"
title: ADR0018 Cloud Tagging Update for Business Capability Cost Allocation
authority: binding
version_hash: "sha256:44c8de17970a991711990b79cac0a86f40972e84a9de1ff9a7d056387c391d82"
body_hash: "sha256:73c6548caf4128bea36c7e127a4386b6eb3eae508d0b4499b5b09dc6b46edfd5"
lang: en
source_langs: [en]
last_modified: "2026-02-19"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0018_cloud_tagging_business_capability.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1233682447 -->
<!-- confluence-space-key: CTO -->

# ADR0018 Cloud Tagging Update for Business Capability Cost Allocation

### Status

Accepted.

## Summary

### Issue

[ADR0006](ADR0006_cloud_naming_tag_convention.md) defines cloud resource tags including `domain` and `service`.
This model is no longer aligned with current cost allocation needs because cost ownership must be mapped primarily to Business Capabilities.

### Decision

This ADR updates `ADR0006` by:

- removing the `domain` and `service` tags;
- adding `business_capability` and `component` tags.

#### Updated mandatory tags

- `business_capability`: the name of the Business Capability that owns the resource. The value **must** match one of the names listed in the "Name" column of the [Development Portal Catalog](https://development.teamsystem.com/catalog). Note that this list includes entries other than Business Capabilities. This tag is the primary key used to allocate cloud costs to a Business Capability;
- `component`: an optional free-form label chosen by the development team that owns the Business Capability, used to further subdivide costs within a single Business Capability. The development team can communicates this value to the Platform team during resource provisioning;

All other tags and naming conventions defined in `ADR0006` remain valid unless explicitly overridden by this ADR.

#### Migration note

For existing resources, `domain` and `service` should be progressively replaced by `business_capability` (mandatory) and `component` (optional) according to platform rollout priorities.

## Details

### Assumptions

- Business Capability is the correct financial ownership dimension for cloud cost allocation.
- Teams can identify and provide a valid catalog value for `business_capability`.

### Constraints

- `business_capability` values must be aligned with the Development Portal Catalog names.

### Positions

- Keep tagging simple and actionable for cost governance.
- Allow optional granularity through `component` without creating a rigid taxonomy.

### Argument

Replacing `domain` and `service` with `business_capability` and `component` improves cost attribution quality and aligns the cloud tagging model with the current organizational ownership structure.

### Implications

- Provisioning templates and governance checks must enforce the new `business_capability` tag.
- Cost reporting can use `business_capability` as aggregation key.
- Teams may optionally use `component` to refine internal chargeback/showback views.

## Related

### Related Decisions

- [ADR0006 Cloud Naming Tag Convention](ADR0006_cloud_naming_tag_convention.md)
- [ADR0014 Standardization of Business Capability features](ADR0014_business_capability_standardization.md)

### Related Artifacts

- [Development Portal Catalog](https://development.teamsystem.com/catalog)

### Related Principles

- Cost governance by clear ownership.
- Standardization of platform metadata.

## Notes

This ADR supersedes only the tag subset (`domain`, `service`) in `ADR0006`.
