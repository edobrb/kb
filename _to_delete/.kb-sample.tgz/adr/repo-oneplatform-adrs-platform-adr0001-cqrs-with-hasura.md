---
source_id: "adr:repo-oneplatform-adrs-platform-adr0001-cqrs-with-hasura"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0001_cqrs_with_hasura.md"
title: ADR0001 CQRS With Hasura and Postgres
authority: binding
version_hash: "sha256:9fb24eee79bf7fa4ab33f07249f56640999d4b55e6944edfa4d3661c4ca2d618"
body_hash: "sha256:09ce8ec3e6766de48c7724cd5fbdd05d96c32544085b2a16cc2729b7b715b109"
lang: en
source_langs: [en]
last_modified: "2022-05-05"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0001_cqrs_with_hasura.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 805208211 -->
<!-- confluence-space-key: CTO -->

# ADR0001 CQRS With Hasura and Postgres

### Status

**Deprecated — as of 2025-06-01**  
Hasura is no longer part of the company-approved technology stack for new developments. This ADR must not be adopted for new projects.

> **NOTE:
** this is ONE POSSIBLE APPROACH, if you use other technologies or don't like this approach, write an ADR and propose your solution.

## Summary

This ADRS presents **ONE POSSIBLE
** approach to implement [CQRS][cqrs] using [Hasura][hasura] and [PostgreSQL][pg] as backend-for-frontend.

> **NOTE:
** this is ONE POSSIBLE APPROACH, if you use other technologies or don't like this approach, write an ADR and propose your solution.

### Issue

- We need **to uniform** the way different teams implement [CQRS][cqrs].
- We need **to decouple
  ** the CQRS Client from the backend that carries on the commands and updates the read-only data store.
- We need **to unentangle
  ** teams communication, the team that builds a Client should not depends on the team that builds the Server counterpart (and the other way around)

### Decision

- We use [PostgreSQL][pg] _Annotation Tables_ to store Commands and Responses
- The Client uses [Hasura][hasura] as interface to query for commands and statuses
- The data migration from _Annotation Tables_ to a queue mechanism can be delegated to:
    - [Debezium][debezium]
    - [Hasura Events][hasura-events]
    - Postgres Triggers to [Fetchq][fetchq]
- _Annotation Tables_ are _INSERT
  ONLY_ and partitioned by time in order to guarantee linear I/O performances (we can use [Timescale][timescale])

## Details

[See: Notes / Implementation](#notes--implementation)

### Assumptions

- Most of the Client teams (internal or external) are already familiar with a simple relational schema
- A Backend team is not affected by this choice as they will receive the data in a data-stream managed by [Debezium][debezium] (or similar approach), completely unentangled by this implementation, and such stream can be easily materialized in a task-based workflow

### Constraints

- Design To Cost
    - the Client environment does NOT require any complex system to communicate with the Backend
    - the Client team can easily create Backend mocks that implement mocked responses to issued commands
    - complete unentanglement between Client/Backend **removes communication** costs

### Argument

- Occam's Razor
    - this solution doesn't require new tools / knowledge in the Client team
    - this solution uses tools that are already in place (relational databases such PostgreSQL or SQL Server)
    - this solution does not imply any Backend constraint on technology or architecture

### Implications

- The _Annotation DB_ is source of truth and must be managed as [Tier 4][db4] databases in our system

## Related

### Related Decisions

This ADR is related to the higher level decision of using CQRS and Queues to manage asynchronous data management and non-blocking user interfaces in OnePlatform.

NOTE: such ADR does not exists yet, as soon we write it, we will link it here.

## Notes / Implementation

### Naming

- Annotation Tables: hypertable composed by a `commands` and `responses` time-partitioned data tables
- Command Name: identifies the implementation (eg. "issue_invoice")
- Command ID: identifies a specific issued command

### Annotation Tables

Each command, or family of commands, is represented by 2 annotation tables:

- commands
- responses

#### Commands Table

| field      | type      | description                    |
|------------|-----------|--------------------------------|
| * cmd_id   | uuid      | command identifier             |
| cmd_name   | text      | command name                   |
| created_at | timestamp | used for data partitioning     |
| payload    | json      |                                |
| tenant_id  | ?         |                                |
| user_id    | ?         |                                |
| client_id  | ?         | client that issues the command |

NOTE: `tenand_id`, `user_id`,
`client_id` are support fields needed [to query the command table and rebuild open commands](#client-commands-status-management) in the Client, centralizing that competence into the support table.

#### Responses Table

| field        | type      | description                    |
|--------------|-----------|--------------------------------|
| * cmd_id     | uuid      | command identifier             |
| * created_at | timestamp | used for data partitioning     |
| data         | json      | successful response payload    |
| error        | json      | unsuccessful response payload  |
| status       | json      | status advance payload         |
| tenant_id    | ?         |                                |
| user_id      | ?         |                                |
| client_id    | ?         | client related to the response |

### Command's Payload Schema

A command's payload is just JSON.

- It is responsibility of the Client to issue a correct payload
- It is responsibility of the Backend to validate such payload before accepting the command

👉 Such schemas should be released into the micro-domain's Schema Registry.

> We may decide to implement a [pre-command server logic](#pre-command-serverlogic) that applies the schema to the incoming commands, effectively and sinchronously blocking any unpublished commands schema.

### Hasura ACL

We can use [Hasura ACL][hasura-acl] to control write-only/read-only access to the _Annotation Tables_:

- A Client role writes to the `commands` table and reads from the `responses` table
- A Backend role writes to the `responses` table
- A Connector role (Debezium) reads from `commands` *

(*) This is likely not needed as it would work at a lower level tracking the database's WAL.

Also, informations such as `tenant_id` and
`user_id` can be fetched from the Hasura Session to simplify the command structure and increase the overall system security.

### Pre-Command ServerLogic

There may be cases in which **some** server-side validation logic could be beneficial to the overall performances.

> It is something that must be carefully evaluated, for it will increase complexity and entanglement of the solution

Nevertheless, there are a few ways this could be neatly implemented:

- Triggers: a WHOLE LOT of logic could be implemented as _Postgres Server
  Functions_ and applied as PRE-INSERT triggers directly from the SQL solution
- [Hasura Actions][hasura-actions]: Issuing a command could be wrapped into an Action that is implemented into a micro-service (not the way I would like to go, though)

👉 For extremely advanced cases, we can imagine to create customized _Annotation
Tables_ that serve only one specific command_name.

### Client Commands Status Management

One very complex aspect of CQRS is keeping a consistent reprenstational state in the Client.

The Client usually polls an outdated dataset, and merges it with _Open Command_ payloads to produce an _optimistic
updated view_, or a _Row Lock View_.

> Synchronizing multiple Clients (eg. multiple tabs or devices) can be daunting and often requires a support data structure where to save ongoing commands.

👉 This approach solves this problem thanks to the _Annotation
Tables_ that can be easily queried without much impact on performances.

- The Client can fetch all commands and responses for a specific
  `tenant_id`, and merge it locally in order to minimize the Database's workload
- The Database could provide a View that joins commands with their latest available update, in order to minimize the Client's logic

### Commands Timeout

The Client can manage a logical timeout the way it wants, unlocking the target entity, or reverting its local state.

Queries to the Database COULD implement a generic timeout where the `responses` table implement a rule such as
`WHERE created_at > NOW() - INTERVAL '1h'` as so to avoid to query beyond 1-2 data partitions top.

### Data Retention

With time-based table paritioning, we can safely drop outdated partitions. Partitions who's creation time is older than the [general timeout](#commands-timeout).

👉 Dropping data partitions is unexpensive and doesn't lock resources on the DB 👈

### Client Updates

Once the Client issues a command, it receives the
`cmd_id` and should eventually receive some status updates to such command, until the command resolves.

#### Polling

This is the easiest and by far simplest possible implementation.   
I strongly vauch for this way.

- Polling is implemented in most GraphQL libraries ([Apollo Client](https://www.apollographql.com/docs/react/), [React Query](https://react-query.tanstack.com/))
- Polling does not have any scalability issue on the infrastructure layer (sockets, firewalls)
- With proper time-based partitioning and indexing, polling the latest response for a command has an extremely low impact on the database resources

#### Long Polling

It is possible to implement an [Hasura Action][hasura-action] as Client polling wrapper, and implement long polling here.

The implementation could:

- simply implement server-side polling, which would already provide some networking benefit
- implement server side data subscription
    - via [Hasura Subscriptions][hasura-subscriptions]
    - via Postgres data subscriptions

#### Hasura Subscriptions

[Hasura Subscriptions][hasura-subscriptions] implement client/server socket-based communication.

Basically, we can receive new data-points in real-time more or less as it happens with Firebase or similar real-time databases.

Although this seems an appealing solution, it may result heavy on the infrastructure and should be carefully considered.

---

[hasura]: https://hasura.io/

[hasura-events]: https://hasura.io/docs/latest/graphql/core/event-triggers/index/

[hasura-acl]: https://hasura.io/docs/latest/graphql/core/auth/authorization/basics/

[hasura-actions]: https://hasura.io/docs/latest/graphql/core/actions/index/

[hasura-subscriptions]: https://hasura.io/docs/latest/graphql/core/databases/postgres/subscriptions/index/

[pg]: https://www.postgresql.org/

[cqrs]: https://docs.microsoft.com/en-us/azure/architecture/patterns/cqrs

[debezium]: https://debezium.io/

[timescale]: https://www.timescale.com/

[fetchq]: https://fetchq.com/
