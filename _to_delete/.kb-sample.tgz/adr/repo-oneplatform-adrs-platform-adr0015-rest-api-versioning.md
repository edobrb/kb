---
source_id: "adr:repo-oneplatform-adrs-platform-adr0015-rest-api-versioning"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0015_rest_api_versioning.md"
title: ADR0015 Uniform REST API Versioning and Governance Strategy
authority: binding
version_hash: "sha256:34e2a34a0517a1019be50a434882f43f2c3776aa78295d8721f8f630e03b6280"
body_hash: "sha256:bd16c357d24f16ca00ab20576618b2206d5d680a02d1570f33b0f38bf71b1202"
lang: en
source_langs: [en]
last_modified: "2025-12-10"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0015_rest_api_versioning.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1085931747 -->
<!-- confluence-space-key: CTO -->

# ADR0015 Uniform REST API Versioning and Governance Strategy

### Status

Accepted.

## Summary

### Issue

**Objective:** Define a uniform strategy for REST API versioning, managing the evolution of Business Capabilities, ensuring **backward compatibility**, communicating **deprecation/EOL**, and establishing observability across all **Business Capabilities (BC)** on the platform.

The platform exposes diverse Business Capability services that continually evolve with new features, hardening, and fixes. A uniform standard ensures:

* **Controlled Evolution:** Allows evolution without breaking existing consumers.
* **Lifecycle Management:** Permits the temporary co-existence of multiple versions.
* **Simple Observability:** Guarantees uniform metrics and caching.
* **Predictable Developer Experience (DX):** Ensures repeatable contracts, recurring examples, and a better DX.

**Out of Scope (Reference):** Implementation details for gateway routing and deployment specifications will be governed in a dedicated specification.

### Decision

Api versioning follow semantic rules major versioning. A coherent way to handle deprecation and end of life of previous version must be put in place. 

#### Versioning Rules

Api versioning follow semantic rules major versioning.

| Type of Change | Action | Example |
| :--- | :--- | :--- |
| **Additive** (backward-compatible) | Same major version | Adding an optional field |
| **Breaking** | **New major version** | Removing a field, changing a type |
| **Minor/Patch** | Invisible in the URI | Bug fix, optimizations |

#### Additive Change (Backward-Compatible) ✅

**Definition:** A modification that does not require updates to correctly implemented existing clients (**tolerant reader**) and does not alter the contract's semantics or obligations.

**Allowed Patterns in the Same Major Version:**

* Adding **optional** fields to requests/responses.
* Adding new endpoints or **optional** query parameters.
* Extending enums with new values.
* Adding error codes while keeping the schema unchanged.
* Increasing maximum limits while keeping defaults unchanged.

#### Breaking Change ❌

**Definition:** A modification that can break existing clients (even well-implemented ones) because it changes the contract's obligations, semantics, or shape.

**Patterns Requiring a New Major Version:**

* Removing/renaming existing fields.
* Changing the type or meaning of fields.
* Making a previously optional field **mandatory**.
* Changing defaults, ordering (**sort**), or pagination.
* **Restricting enums** by removing values.
* Changing ID/date format or *Content-Type*.
* Removing endpoints or modifying the path.

#### Quick Heuristics (Decision Tree)

**Decision Checklist:**

1.  **Are you adding something optional?** → ✅ **Additive** (same major).
2.  **Are you removing/renaming/changing type or meaning?** → ❌ **Breaking** (new major).
3.  **Are you changing defaults, ordering, or restrictive validations?** → ❌ **Breaking** (or make it *opt-in* with a new parameter).

**Rule for Clients:**

* Clients must implement the **Tolerant Reader Pattern**: ignore unknown fields and treat unknown enum values as `UNKNOWN`/`OTHER`.

---

#### Lifecycle Communication

##### Deprecation Header (RFC Standard)

When **v2** is released, add the following headers to **all v1 responses**:

```http
HTTP/1.1 200 OK
Deprecation: true
Sunset: Tue, 30 Jun 2026 23:59:59 GMT  // Actual EOL Date
Link: [https://developer.example.com/deprecations#orders-v1](https://developer.example.com/deprecations#orders-v1); rel="deprecation"
Link: </v2/orders/{id}>; rel="successor-version"
````

##### Post-EOL (After Sunset)

After the *Sunset* date, the API must respond with **`410 Gone`**.

```http
GET /v1/orders/o1
410 Gone
{
  "code": "API_VERSION_EOL",
  "message": "Orders API v1 has reached end-of-life. Please migrate to /v2.",
  "details": [{ 
    "doc": "[https://developer.example.com/migrate/orders-v2](https://developer.example.com/migrate/orders-v2)" 
  }]
}
```

#### Observability and Metrics

##### Mandatory Tags

All metrics must include:

  * `api.version` (e.g., "v1", "v2")
  * `api.endpoint` (e.g., "orders", "customers")
  * `api.method` (e.g., "GET", "POST")

##### Transition Monitoring

  * **New Version Adoption:** Traffic percentage by `version tag`.
  * **Deprecation Readiness:** % traffic still on deprecated versions.
  * **Error Tracking:** `410 Gone` rate post-EOL.

##### New Major Release Checklist

  * ✅ Publish `openapi-v{N+1}.yaml` + examples.
  * ✅ Update gateway/routing for `/v{N+1}/*`.
  * ✅ Apply **`Deprecation`/`Sunset`** headers on `/vN/`.
  * ✅ Publish migration guide.
  * ✅ Monitor adoption via `api.version` tag.
  * ✅ At *Sunset* → activate **`410 Gone`** on `/vN/`.

##### Typical Transition Window

  * **Parallel Run:** 12 months
  * **Communication:** 3 months before *Sunset*
  * **Grace Period:** 1 month post-*Sunset* (for emergencies)


#### Implementation Details

##### Versioning Models (Path / Header / Query)

The platform acknowledges three technical mechanisms for expressing the API version:

1. **Version in the path** (recommended – platform standard)
2. **Version in a header** (allowed, but not suggested)
3. **Version in query string** (strongly discouraged)

The normative stance of the platform is:

- Path-based versioning is the **default and recommended** model for all Business Capabilities.
- Header-based versioning is **allowed** only in justified scenarios and **must not** be offered as the general default.
- Query-string-based versioning is **strongly discouraged** and **MUST NOT** be used for new APIs.

###### 1. Version in the path ✅ (RECOMMENDED)

**Example**

```http
GET /api/v1/customers/123
GET /customer-management/v1/customers/123
GET /order-processing/v2/orders/987
```

**Pros**

- Highly **readable**: the version is immediately visible in the URL.
- **Uniform** for all kinds of clients (browser, legacy systems, B2B integrations).
- Very **simple to route** on API Gateway / reverse proxy (`/v1/`, `/v2/`).
- **Documentation-friendly**: OpenAPI/Swagger examples match actual URLs.

**Cons**

- Each major version introduces a new set of endpoints (`/v1/...`, `/v2/...`).
- Risk of accumulating legacy versions if deprecation is not enforced.

**Platform stance**

- This is the **standard versioning mechanism** for all REST APIs exposed by Business Capabilities.
- All **external-facing contracts** MUST use path versioning for the major version:  
  `/{capability}/v{major}/...`.

###### 2. Version in header ⚠️ (ALLOWED BUT NOT SUGGESTED)

**Example**

```http
GET /api/customers/123
X-Api-Version: 2
```

```http
GET /customer-management/customers/123
X-Api-Version: 2
```

**Pros**

- Keeps **URIs stable** across versions: `/customers/123` does not change.
- Useful where the platform fully controls clients and SDKs.

**Cons**

- Version is **not visible** in the URL (lower discoverability).
- Requires stricter **tooling and discipline** on clients (easy to forget or misconfigure headers).
- Some proxies/tools may not use custom headers for routing out-of-the-box.

**Platform stance**

- **Allowed only** for specific, justified use cases (e.g., large partners, migration variants) and **subject to architecture approval**.
- MUST NOT be advertised as a generic alternative to path versioning.
- When used, it MUST be clearly documented in the API contract and migration guides.

###### 3. Version in query string ⛔ (STRONGLY DISCOURAGED)

**Example**

```http
GET /api/customers/123?api-version=1
GET /api/customers/123?api-version=2024-09-01
```

```http
GET /customer-management/customers/123?api-version=1
GET /customer-management/customers/123?api-version=2024-09-01
```

**Pros**

- Allows changing version without modifying path.
- Sometimes convenient for quick manual testing.

**Cons**

- Produces **less clear URLs**: technical and business parameters get mixed.
- Creates **ambiguity** between functional query parameters and versioning concerns.
- Higher risk of client errors (missing parameter, wrong name, typos).
- Leads to **lower consistency** across Business Capabilities.

**Platform stance**

- **MUST NOT** be used for new APIs as a versioning mechanism.
- Existing APIs that use query-string versioning are considered **legacy** and should be gradually migrated to the path-based model.
- No new occurrence of `api-version` (or equivalent) in query string is allowed in newly designed REST APIs.

---

  * **Path Structure (External Contract):**  
    *All external REST APIs exposed by Business Capabilities MUST use path-based major versioning* with a mandatory root:  
    `/vN/` (e.g., `/v1/`, `/v2/`), combined with the capability name:  
    `/{capability}/v{major}/...`.

  * **Separate OpenAPI:**  
    Use separate specifications per major version (e.g., `openapi-v1.yaml`, `openapi-v2.yaml`).

  * **Gateway Routing:**  
    API Gateway and reverse proxies MUST route traffic based on the path prefix (`/v1/*`, `/v2/*`), and MAY additionally use header-based variants where explicitly approved.

---

## Details

### Assumptions
- **Standardization reduces integration costs** and improves developer experience.  

### Constraints
- **Mandatory for all new REST APIs**.  
- **Progressive refactoring required** for existing REST APIs.

### Positions 
- A **single platform contract** simplifies governance and auditing.

### Argument
Without **common rules**, BCs risk introducing **custom conventions**, leading to **higher integration costs, fragmented governance, and lower productivity**.  

## Implications
- **Positive**: predictable developer experience, faster integration, centralized governance.  
- **Negative**: initial alignment effort, **reduced freedom for ad-hoc API design**.  
- **Mitigation**: exceptions handled through dedicated ADRs.

## Related

### Related Decisions
- [Standardization of Business Capability features](ADR0014_business_capability_standardization.md)

### Related Requirements
This document is the **central list of MUST and SHOULD requirements** for BCs.

### Related Artifacts
- Internal Guidelines  
- Reference Implementation

### Related Principles
- API First  
- Consistency over flexibility  
- Developer Experience as a platform asset
