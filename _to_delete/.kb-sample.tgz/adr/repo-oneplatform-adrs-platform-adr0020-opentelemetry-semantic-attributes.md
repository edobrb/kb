---
source_id: "adr:repo-oneplatform-adrs-platform-adr0020-opentelemetry-semantic-attributes"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0020_opentelemetry_semantic_attributes.md"
title: ADR0020 OpenTelemetry Semantic Attributes for Platform Context
authority: binding
version_hash: "sha256:b517b5b4318528509affb84b49c07afe8c854f64c81d479e545e2a10c8652b32"
body_hash: "sha256:8d0f99d2bb24f7d748482d945f4a3cc5c4bec101e0a837c912b5006eda93c031"
lang: en
source_langs: [en]
last_modified: "2026-05-22"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0020_opentelemetry_semantic_attributes.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1729363987 -->
<!-- confluence-space-key: CTO -->

# ADR0020 OpenTelemetry Semantic Attributes for Platform Context

### Status

Accepted.

This ADR supersedes [ADR0011 Well-known log type](ADR0011_well_known_log_type.md).

## Summary

### Issue

ADR0011 standardizes a JSON log schema for HELK/Beats, but [ADR0019](ADR0019_opentelemetry_adoption.md) standardizes OpenTelemetry and OTLP as the platform observability model.

Keeping a platform-specific log-only schema creates duplicated names, inconsistent context between logs and traces, and migration friction for services adopting OpenTelemetry.

### Decision

Use **OpenTelemetry Semantic Conventions** as the primary telemetry naming model for platform services.

In addition to standard OpenTelemetry attributes, services MUST add the following platform context attributes when the value is available for the current operation:

| Attribute | Type | Requirement | Usual source | Notes |
|-----------|------|-------------|--------------|-------|
| `user.id` | string | Required when available | TSID JWT `sub` claim | Use the authenticated user identifier only; never emit the JWT token. |
| `workspace.id` | string | Required when available | `X-Workspace-ID` HTTP header | Platform-defined attribute for the selected workspace context. |
| `item.id` | string | Required when available | `X-Item-ID` HTTP header | Platform-defined attribute for the business item/resource context. |

#### MUST

- Use OpenTelemetry Semantic Conventions for attribute names and meanings whenever an official convention exists.
- Attach `user.id`, `workspace.id`, and `item.id` to spans and log records generated for the same request or operation when the values are available.
- Keep these attribute values as strings.
- Treat these identifiers as sensitive contextual data: do not emit tokens, credentials, or unvalidated authorization material.
- For new instrumentation, do not use ADR0011 legacy field names as the platform standard (`customer.ts_id`, `customer.workspace_id`, `customer.item_id`, `user`).

#### SHOULD

- Read `user.id` from the authenticated TSID JWT `sub` claim.
- Read `workspace.id` from `X-Workspace-ID` when the request carries a workspace context.
- Read `item.id` from `X-Item-ID` when the request carries an item context.
- Validate header-derived values against authentication, authorization, or business rules before treating them as authoritative.
- Propagate these attributes across asynchronous work when the work is causally related to the original request.
- During migration, emit legacy ADR0011 fields only for backward compatibility with existing dashboards or indexes.

#### MAY

- Add these attributes to metric data points only when the owning team has explicitly accepted the cardinality and cost impact.
- Omit an attribute when the source is absent, the operation is anonymous, the value cannot be validated, or security policy forbids emitting it.

## Details

### Assumptions

- Platform services are migrating to OpenTelemetry according to ADR0019.
- W3C Trace Context propagation is handled according to ADR0017.
- Some existing services will continue to emit ADR0011-shaped logs during the migration window.

### Constraints

- `workspace.id` and `item.id` are platform-defined attributes because they are not OpenTelemetry registry attributes.
- These attributes can be high-cardinality, especially `item.id`; they are required by default on spans and logs, not on metrics.
- Consumers must tolerate missing attributes when the context is not present or cannot be safely emitted.

### Positions

**Adopt OpenTelemetry-first naming** - selected to align logs, traces, metrics, and future telemetry with the platform observability standard.

**Keep ADR0011 log schema** - rejected for new instrumentation because it is log-only, HELK/Beats-specific, and duplicates OpenTelemetry conventions.

### Argument

OpenTelemetry provides a shared semantic model across telemetry signals. Using it as the default avoids maintaining a separate platform log vocabulary and makes correlation easier across logs and traces.

The three platform context attributes keep the operational value of ADR0011 while using a smaller and signal-neutral convention:

- `customer.ts_id` and `user` map to `user.id`.
- `customer.workspace_id` maps to `workspace.id`.
- `customer.item_id` maps to `item.id`.

### Implications

- **Positive**: logs and traces share the same context attributes.
- **Positive**: new services follow ADR0019 without implementing a separate HELK-specific schema.
- **Negative**: existing dashboards, alerts, and index templates that depend on ADR0011 fields need migration.
- **Mitigation**: existing services may emit both legacy ADR0011 fields and ADR0020 attributes during the migration window.

## Related

### Related Decisions

- [ADR0011 Well-known log type](ADR0011_well_known_log_type.md)
- [ADR0017 W3C Trace Context](ADR0017_trace-context.md)
- [ADR0019 Adoption of OpenTelemetry as Standard Observability Protocol](ADR0019_opentelemetry_adoption.md)

### Related Artifacts

- [OpenTelemetry Semantic Conventions](https://opentelemetry.io/docs/specs/semconv/)
- [OpenTelemetry User Attributes](https://opentelemetry.io/docs/specs/semconv/registry/attributes/user/)
- [OpenTelemetry Naming Guidelines](https://opentelemetry.io/docs/specs/semconv/general/naming/)
