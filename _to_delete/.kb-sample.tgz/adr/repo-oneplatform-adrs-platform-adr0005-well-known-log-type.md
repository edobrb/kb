---
source_id: "adr:repo-oneplatform-adrs-platform-adr0005-well-known-log-type"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0005_well_known_log_type.md"
title: ADR0005 Well-known log type
authority: binding
version_hash: "sha256:593dd601fcc4f7b1f80a97e0533cb243466e0c7a8e665c4fde67a83f2d397264"
body_hash: "sha256:84d1e48b750d7c6efa668b8b736a54cb40566c85352fcf2c90ea9f2740c39961"
lang: en
source_langs: [en]
last_modified: "2022-06-23"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0005_well_known_log_type.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 805699698 -->
<!-- confluence-space-key: CTO -->

# ADR0005 Well-known log type

### Status

**Outdated - as of 2025-02-08 see [ADR0011_well_known_log_type](ADR0011_well_known_log_type.md).**

## Summary

This ADR describes how well know log format for OnePlatform Application.

### Issue

- Elasticsearch is the standard engine for log search, it like JSON;
- A standard must be provide to help comprension durign debugging, often, under pressure;
- Index in Elasticsearch are strongly typed, during a cross search field must be in the same format to avoit currupted result (to give an example - a service A wrote log objects that had an integer in the timestamp property, while a service B wrote it with a string in the timestamp property.)

### Decision

A decision was made to use JSON as format standars for logs.
Logs will be written to stdout and shipped to HELK via beats.
In HELK logs will be validated according to the defined structure using [index template](https://www.elastic.co/guide/en/elasticsearch/reference/current/index-templates.html).

The mandatory log format is the following:

| FIELD NAME                                     | TYPE    | EXAMPLE                                                     | REQUIREMENTS   |
|------------------------------------------------|---------|-------------------------------------------------------------|----------------|
| timestamp                                      | date    | 2016-05-23T08:05:34.853Z                                    | mandatory      |
| client.ip                                      | ip      |                                                             | mandatory      |
| client.hostname                                | text    |                                                             | mandatory      |
| server.ip                                      | ip      |                                                             | mandatory      |
| server.hostname                                | text    |                                                             | mandatory      |
| business\_unit                                 | keyword | digital, enterprise, tspaas, studio                         | mandatory      |
| app.name                                       | keyword | service name                                                | mandatory      |
| app.version                                    | keyword | 1.0, 1.1, 2.0, ....                                         | mandatory      |
| app.stack                                      | keyword | java, node, python                                          | mandatory      |
| [customer.id](http://customer.id/)             | keyword | C.F./P.IVA                                                  | mandatory      |
| customer.ts\_id                                | keyword | ts\_id code                                                 |                |
| [correlation.id](http://correlation.id/)       | keyword | uuid attacched to a full transaction or event chain         | mandatory      |
| log.retention                                  | integer | 15, 30, 60, 180                                             | mandatory      |
| log.level                                      | keyword | info, error, debug                                          | mandatory      |
| environment                                    | keyword | dev, test, prod                                             | mandatory      |
| user                                           | text    | tech user or user id                                        | mandatory      |
| cloud.provider                                 | keyword | az, aws, gcp                                                | filled by beat |
| cloud.region                                   | keyword | westeurope, eu-west-1                                       | filled by beat |
| cloud.service                                  | keyword | aks, ec2, ecs                                               | filled by beat |
| [cloud.instance.id](http://cloud.instance.id/) | keyword | instance uuid                                               | filled by beat |
| event.message                                  | text    | NO base64, documenti                                        | mandatory      |
| event.duration                                 | long    | Duration of the event in nanoseconds                        | mandatory      |
| http.response.status\_code                     | long    | 200, 400, 500, ...                                          | mandatory      |
| http.request.method                            | keyword | get, post, put                                              | mandatory      |
| http.request.bytes                             | long    | Total size in bytes of the request                          | mandatory      |
| error.type                                     | keyword | java.lang.NullPointerException                              | mandatory      |
| error.message                                  | text    |                                                             | mandatory      |
| error.stack\_trace                             | keyword |                                                             | mandatory      |
| retention.status                               | boolean | true, false(default)                                        | mandatory      |
| retention.period                               | keyword | a = keep forever ,b = six moths, c = 1 year , d = 10 years  | mandatory      

if retention.status is true |
| tags | keyword | | mandatory |

## Details
