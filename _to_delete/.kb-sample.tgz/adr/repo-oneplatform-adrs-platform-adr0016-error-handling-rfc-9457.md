---
source_id: "adr:repo-oneplatform-adrs-platform-adr0016-error-handling-rfc-9457"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0016_error_handling_RFC_9457.md"
title: ADR0016 Error Handling — Problem Details (RFC 9457)
authority: binding
version_hash: "sha256:f5427c79644c067c0923116a5478ebdbc8fa161eed5cc9f598996379e41c910f"
body_hash: "sha256:896d52f137d2ba12666447cc1a8a4ed29551b7223f4d3c15df0a93fb11070810"
lang: en
source_langs: [en]
last_modified: "2025-12-10"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0016_error_handling_RFC_9457.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1089863765 -->
<!-- confluence-space-key: CTO -->

# ADR0016 Error Handling — Problem Details (RFC 9457)

### Status

Accepted.

## Summary

We standardize HTTP error representation for all platform Business Capabilities (BCs) using **Problem Details for HTTP APIs (RFC 9457)** with **Content-Type `application/problem+json`**, extendable with additional fields useful for controlled debugging and correlation (e.g., `errors[]`, `traceparent`). The goal is to ensure end-to-end consistency, interoperability, and observability.

### Issue

Heterogeneous APIs expose different error formats (free-form strings, proprietary wrappers). This causes:

- More complex client/UI integrations.
- Difficulty correlating errors, logs, and telemetry.
- Security risks (infrastructure detail leakage).
- Fragmented developer experience (exception handling, examples, guidelines).

### Decision

#### MUST

- **Media type**: all **4xx/5xx** responses must use `Content-Type: application/problem+json`.
- **Core fields** always present: `type`, `title`, `status`, `detail`.
- **`instance`**: include it, preferably as an absolute URI of the resource/operation.
- **`status` consistency**: the JSON `status` must mirror the HTTP status code.
- **Type documentation**: `type` must be a stable URI; when it’s a URL, it must point to an internal HTML page describing the problem.
- **Client robustness**: clients must ignore unknown fields (for forward compatibility).
- **Security**: do not expose stack traces, internal hostnames, credentials, tenant IDs, or personal data.

#### SHOULD

- **Validation**: use `errors[]` with field-specific entries that include at least `path` (JSON Pointer RFC 6901), `code`, `message`.
- **Localization**: `title` may be localized based on `Accept-Language`; **`detail`** remains specific to the occurrence.
- **Trace Context**: if the client sends `traceparent`, preserve it and align `correlationId` and `requestId` to the related `trace-id` and `parent-id`.
- **Consistent semantics**: reuse `type` for recurring error classes (e.g., `validation-error`, `conflict`, `not-authorized`, `rate-limited`).

#### MAY

- Additional extensions (e.g., `hint`, `remediation`, `supportUrl`, `timestamp`, `cause`) when they improve client corrective action without revealing sensitive details.
- Use `instance` as an opaque ID when an absolute URI is not appropriate.

## Details

### Assumptions

- Standardization reduces integration costs and improves DX/UX.
- RFC 9457 is supported by a broad ecosystem and established patterns.

### Constraints

- Mandatory for **all new APIs** and **new versions**.
- Progressive migration for existing APIs; wrappers or gateway-side mapping where needed.

### Positions

- **One standard, plus extensions**: RFC 9457 + minimal, platform-wide coherent extensions.
- **Observability by design**: every error is correlatable and investigable end-to-end.

### Argument

Without a single standard, each BC invents its own schema: client parsing branches proliferate, interpretation errors increase, and security decreases. Problem Details offers a minimal, extensible, and readable contract, with low lock-in.

### Specification & Examples

#### 1) Minimal headers

```
HTTP/1.1 422 Unprocessable Entity
Content-Type: application/problem+json
X-Correlation-Id: t5y6u7i8
X-Request-Id: a1b2c3d4
Traceparent: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01
```

#### 2) Base payload (validation)

```json
{
  "type": "https://errors.acme.dev/validation-error",
  "title": "Validation failed",
  "status": 422,
  "detail": "One or more fields failed validation.",
  "instance": "https://api.acme.dev/v1/invoices",
  "errors": [
    { "path": "/total/amount", "code": "min", "message": "Value must be >= 0" }
  ]
}
```

- `type`: stable, documented URI; avoid `about:blank` except for generic cases.
- `errors[].path`: **JSON Pointer (RFC 6901)** to the failing property.

#### 3) Examples for common error classes

* **404 Not Found**

```json
{
  "type": "https://errors.acme.dev/not-found",
  "title": "Resource not found",
  "status": 404,
  "detail": "Invoice 12345 was not found.",
  "instance": "https://api.acme.dev/v1/invoices/12345"
}
```

* **409 Conflict (OCC ETag)**

```json
{
  "type": "https://errors.acme.dev/conflict",
  "title": "Edit conflict",
  "status": 409,
  "detail": "The invoice was modified by another process. Retry with latest ETag.",
  "instance": "https://api.acme.dev/v1/invoices/12345",
  "hint": "Resend with If-Match: \"etag-xyz\""
}
```

* **429 Too Many Requests**

```json
{
  "type": "https://errors.acme.dev/rate-limited",
  "title": "Rate limit exceeded",
  "status": 429,
  "detail": "You have exceeded your rate limit. Try again later.",
  "instance": "https://api.acme.dev/v1/invoices",
  "remediation": "Reduce request rate or contact support to increase limits."
}
```

(The **X-RateLimit-*** headers remain the source of truth for limits and reset.)

#### 4) Required mapping at Gateway/BC

- Set `Content-Type: application/problem+json` on all 4xx/5xx.
- Propagate `traceparent`/`tracestate` when present.
- Normalize internal exceptions into standard Problem Details (no stack traces).

#### 5) Contract for `errors[]` (validation)

- `path` *(string, JSON Pointer)* — e.g., `/items/0/quantity`
- `code` *(string)* — e.g., `required`, `min`, `format`, `unique`
- `message` *(string, human-readable)* — ready for UI/telemetry

#### 6) Content guidelines

- **`detail`**: help corrective action; do not include infrastructure details.
- **Extensions**: allowed if stable and documented (linked from the `type` page).
- **Stability**: `type` and `code` must not change across compatible releases.

#### 7) Migration example from actual platform error format

Current custom JSON format:

```json
{
  "status": "NOT_FOUND",
  "code": "404",
  "timestamp": "12-07-2024T14:36:52.000",
  "message": "Resource with id 9b47809b-1ddc-4529-81bd-a5a4355af1c4 not found"
}
```

Minimal RFC 9457 format as an example:

```json
{
  "type": "https://errors.acme.dev/not-found",
  "title": "Resource not Found",
  "status": 404,
  "detail": "Resource with id 9b47809b-1ddc-4529-81bd-a5a4355af1c4 not found",
  "instance": "https://api.acme.dev/v1/resources/9b47809b-1ddc-4529-81bd-a5a4355af1c4"
}
```

### Security & Privacy

- No stack traces, hostnames, file paths, environment variables.
- Mask PII/secrets.
- Validate/lint error payloads in CI against a shared schema.
- Correlator identifiers must be non-predictable and free of sensitive data.

### i18n & l10n

- `title` may be localized (via `Accept-Language`).
- `detail` optionally localized if the target UI requires it; by default, APIs use neutral English.
- `code` remains **constant** and suitable for UI/i18n mapping.

### Observability & Correlation

- Structured logs must include correlators (e.g. `parentId`, `traceId`, `correlationId`, `requestId`), HTTP `status`, `type`, `errors[].code`.
- Dashboards and alerting hook series on `type` and `status`.

### Backwards Compatibility

- Existing APIs may adopt gateway-level adapters that convert legacy formats into Problem Details.
- Migration should occur progressively through minor versions until old formats are deprecated.
- Feature flags may be used for transitional dual-format support.

### Implications

**Positive**

- Cohesive DX/UX, simplified client-side parsing and correlation.
- Reduced risk of sensitive information leakage.

**Negative**

- Requires initial migration effort and documentation of error types.
- Needs compliance tests and CI validation.

**Mitigation**

- Provide shared middleware and client libraries.
- JSON Schemas and contract tests in CI.
- Maintain a central catalog of type URIs and approved extensions.

## Related

### Related Decisions

- [Standardization of Business Capability features](ADR0014_business_capability_standardization.md)
* **ADR0015 HTTP Methods & Status Codes** 
- [Well-known log type](ADR0011_well_known_log_type.md)

### Related Principles

- API First
- Consistency over flexibility
- Observability by default
- Least disclosure

### Related Artifacts

- RFC 9457 Problem Details for HTTP APIs: [https://www.rfc-editor.org/rfc/rfc9457.html](https://www.rfc-editor.org/rfc/rfc9457.html)
