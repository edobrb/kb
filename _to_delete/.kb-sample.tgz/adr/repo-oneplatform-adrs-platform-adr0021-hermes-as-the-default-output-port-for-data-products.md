---
source_id: "adr:repo-oneplatform-adrs-platform-adr0021-hermes-as-the-default-output-port-for-data-products"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0021_hermes_as_the_default_output_port_for_data_products.md"
title: ADR0021 Hermes as the Default Output Port for Data Products
authority: binding
version_hash: "sha256:03543538579f2015eb87126b78976052541b46736b2eecf16e81b1a0447c5324"
body_hash: "sha256:63f14f9c4c7c2d02fdfd5f1d5beccc0b909a6306542150b6bc6f73ffa42350d4"
lang: en
source_langs: [en]
last_modified: "2026-05-28"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0021_hermes_as_the_default_output_port_for_data_products.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1728905274 -->
<!-- confluence-space-key: CTO -->

# ADR0021 Hermes as the Default Output Port for Data Products

### Status

Accepted.

## Summary

Data products have output ports that other services can consume, and input ports that the data product itself consumes. Hermes is the Platform service for streaming async events. Data products can both consume data from Hermes topics as input ports and publish data to Hermes topics. Data products have also OLAP tabular output ports on Databricks (Unity Catalog tables). These tables are fed by data engineering pipelines that can read both from Hermes topics and from source OLTP databases.

This ADR determines when

- a Data Product must have output ports on Hermes
- the OLAP tabular output ports should read data from the Hermes output port itself

### Issue

- it is not clear for data engineers why they should develop data lakes ETL based on Hermes as input source
- not having Hermes as output ports limits the possibility to quick-start near-real time and async integrations

### Decision

Every data product must have an output port on Hermes **unless**

  - the data product refers to corporate data (eg. internal finance and sales)
    - they are not product-related data and, as a consequence, they are not integrated in OnePlatform making the integration to Hermes per se less relevant
  - the data product is consumer-aligned (eg. ML/insights that computes KPIs)
    - the usual output of these data products is thought for OLAP accesses that often do not use streaming platforms

We recommend that the tabular OLAP output port reads data **from** the Hermes topic itself. However, the dev team may think that this approach is not convenient in some scenarios. If this happens, the dev team will share the decision and the motivations with the Data Platform team. These scenarios will help the platform team to get feedback on the overall design or may suggest blueprints that can simplify the approach.

Regardless of the architecture, the data published on Hermes should be eventually consistent with the data available in the tabular OLAP port.

These tables make a quick summary of the decision.

| Scenario                                   | Hermes Output Port | Notes |
|--------------------------------------------|------------------------------|-------|
| Standard data product                      | **Mandatory**                | Every data product must have a Hermes output port by default. |
| Corporate data (e.g., finance, sales)      | **Optional**                 | Corporate data products are exempt from the Hermes requirement. |
| Consumer-aligned data product (e.g., ML insights, KPIs) | **Optional** | These data products do not need a Hermes output port. |

| Databricks table fed by Hermes?                            | Requirement | Notes |
|--------------------------------------------|------------------------------|-------|
| OLAP output port reads from Hermes          | **Recommended**              | The OLAP output port should ideally read data from the Hermes topic. |
| OLAP port does **not** read from Hermes     | **Exception**                | The dev team must justify this decision in a Federated Governance meeting. |

## Details

Simple illustration of both scenarios.

![architecture](./resources/ADR0021_architecture.png)

### Assumptions

There is hidden value in forcing data products publishing data on Hermes.

1. this strategy pushes the adoption of One Platform
2. we create an asset that enables future asynchronous data integration between products and services

We expect the following advantages in feeding in sequence the Hermes output port and the OLAP output port:

1. re-use the same flow for offloading the OLTP database or app
2. eventual consistency between the two ports should be achieved with lower effort
3. having a standard to way to bring data to data lake reduces overall complexity

### Constraints

Messages on Hermes topics are fully consumable by TS products **if** the publisher is integrated to OnePlatform and the events has reference to Workspace or Company Registry.

### Positions

Decision proposed by Alberto Zitti, Antonella Bifolchi (Hermes), Marco Santoni (Data Platform), Fabio Giustiniani (Data Governance)

### Argument

Not applicable.

### Implications

Teams working on source databases should make the effort to publish data to Hermes to feed the data product. Exceptions are possible, but events on a Hermes topic should still be published at least by data pipelines writing to Databricks.

## Related

### Related Decisions

Not applicable.

### Related Requirements

Not applicable.

### Related Artifacts

Not applicable.

### Related Principles

Not applicable.

## Notes

Not applicable.
