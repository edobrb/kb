---
source_id: "adr:repo-oneplatform-adrs-platform-adr0019-opentelemetry-adoption"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0019_opentelemetry_adoption.md"
title: ADR0019 Adoption of OpenTelemetry as Standard Observability Protocol
authority: binding
version_hash: "sha256:4b079831a0296ddc5adb39907e56732bb7b97021ff6c01914711702a205a6bdc"
body_hash: "sha256:a64c160abc375cf7f2d370813220c25f76e1ad502de53d910d726e53973dcdff"
lang: en
source_langs: [en]
last_modified: "2026-02-24"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0019_opentelemetry_adoption.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1239810290 -->
<!-- confluence-space-key: CTO -->

# ADR0019 Adoption of OpenTelemetry as Standard Observability Protocol

### Status

Accepted.

## Summary

### Issue

Observability is fragmented across the organization:
- Some products use OpenTelemetry, legacy systems use Metricbeat/Filebeat/Azure Service Bus agents
- No unified correlation despite legacy correlation header propagation (`X-Request-Id` / `X-Correlation-Id`)
- Inconsistent observability and duplicated effort
- No end-to-end tracing capability
- Vendor lock-in risk

### Decision

Adopt **OpenTelemetry** (SDKs + semantic conventions) with **OTLP** as the default export protocol for emitting traces, metrics, and logs, and establish a company-managed **OpenTelemetry Collector** layer as the mandatory ingestion and control plane.

Adopt **tail-based sampling at the Collector** as the default trace sampling strategy (with policies that retain error/slow/critical-flow traces); head-based sampling in SDKs may be used only as an additional cost-control mechanism where justified.

## Details

### Assumptions

- Services will adopt OpenTelemetry SDKs for instrumentation
- A centralized company collector layer will be operated as shared platform capability
- ICE framework can be extended to support OpenTelemetry instrumentation

### Constraints

- Backward compatibility with legacy correlation headers (`X-Request-Id`, `X-Correlation-Id`) must be maintained during transition
- Performance overhead from instrumentation must be minimized (sampling strategies required)
- Team-based data isolation and authorization must be enforced consistently

### Positions

**Adopt OpenTelemetry** — Selected as the CNCF-backed industry standard with broad vendor support.

### Argument

**Vendor Neutrality:** OpenTelemetry is CNCF-backed and supported by all major vendors. No lock-in at instrumentation layer; freedom to switch collector and telemetry visualization tools.

**Unified Telemetry Model:** One standard for traces, metrics, and logs with consistent semantic conventions.

**Context Propagation:** This ADR builds upon [ADR0017 W3C Trace Context](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/1088651509/ADR0017+W3C+Trace+Context), which defines the migration from legacy headers to the W3C standard (`traceparent`/`tracestate`). OpenTelemetry uses W3C Trace Context as its default propagator.

**Collector-First Architecture:** Services export telemetry to the company collector, not directly to a vendor backend. The collector becomes the stable control point for routing, enrichment, filtering, sampling, and backend switching.

**Collector Topology (Cluster-local + Platform):** We adopt a two-tier collector architecture to balance resilience, performance, and centralized governance.

**Cluster-local / Private Collector (per Kubernetes cluster):** Each Kubernetes cluster runs its own private collector (scoped to that cluster) as the first hop for services.
- **Buffer if the platform collector is unavailable:** Prevent telemetry loss during temporary platform outages by queuing/retrying locally.
- **Enrich, filter, and compress on egress:** Add Kubernetes/environment metadata, drop noisy signals early, and compress OTLP before leaving the cluster.
- **Reduce cross-cluster dependencies and egress cost:** Keep the service → collector path local and stable, and minimize outbound traffic volume.

**Platform-level Collector (shared ingestion/control plane):** Services (via the cluster-local collector) export telemetry to the platform-managed collector layer.
- **Buffer if the backend is unavailable:** Decouple ingestion from vendor/backend availability (e.g., when the observability backend is degraded).
- **Tail-based sampling (default):** Apply tail sampling centrally with consistent policies (retain error/slow/critical-flow traces) across teams and services.
- **Centralized governance:** Enforce required attributes (e.g., `team`, `deployment.environment`, `service.name`), routing.

![OTel Collector Architecture](./resources/ADR0019_otel_collectors_architecture.png)

**Sampling Strategy (Tail-based):** Tail-based sampling is applied at the Collector to make sampling decisions after the full trace is observed. This enables keeping 100% of error traces and traces exceeding latency thresholds, while sampling down healthy traffic to manage cost.

**Frontend Instrumentation (ICE Framework):** Instrument once at framework level, report web metrics, and forward errors with trace correlation so all applications benefit.

**Frontend Telemetry Ingestion Path (ICE → API GW → Collector):** ICE (frontend framework) sends telemetry to the **API Gateway** over HTTPS **without end-user authentication** (i.e., telemetry ingestion must not depend on interactive user login). The API Gateway applies **rate limiting** to mitigate the internet-facing attack surface, then forwards the telemetry to the **platform-managed OpenTelemetry Collector**.

**Required Attributes:**
- `team`: owning team identifier and tenancy key used for telemetry visibility and access control
- `deployment.environment`: `dev` | `test` | `prod`
- `service.name`: logical service name

**Optional Attributes:**
- `service.namespace`: logical domain/group
- `service.instance.id`: unique instance identifier (when available)
- `correlation_id`: legacy correlation identifier (for backward compatibility)


### Implications

**Benefits:**
- Single observability standard across all products
- End-to-end distributed tracing
- Reduced complexity (retire Beats agents)
- Vendor neutrality at instrumentation layer
- Easier backend/provider switching through collector-level reconfiguration

**Costs:**
- Migration effort for existing services
- Team learning curve for OpenTelemetry concepts

**Risks:**
- Performance impact and platform cost: mitigate with sampling; the platform collector can sample a subset of traces/metrics/logs to minimize overhead while preserving diagnostic value.
- Collector resource requirements: tail-based sampling requires buffering/processing complete traces; this increases Collector capacity and HA requirements.

## Related

### Related Decisions

- [ADR0017 W3C Trace Context](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/1088651509/ADR0017+W3C+Trace+Context)
- [ADR0015 Uniform REST API Versioning and Governance Strategy](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/1085931747/ADR0015+Uniform+REST+API+Versioning+and+Governance+Strategy)

### Related Requirements

- Additional attributes defined in [ADR0015 Observability and Metrics](https://teamsystem.atlassian.net/wiki/spaces/CTO/pages/1085931747/ADR0015+Uniform+REST+API+Versioning+and+Governance+Strategy#Observability-and-Metrics)

### Related Artifacts

- [OpenTelemetry Specification](https://opentelemetry.io/docs/specs/otlp/)
- [W3C Trace Context](https://www.w3.org/TR/trace-context/)
- [OpenTelemetry Context Propagation](https://opentelemetry.io/docs/concepts/context-propagation/)
- [OpenTelemetry Collector](https://opentelemetry.io/docs/collector/)
- [OTel Collector Architecture Diagram](./resources/ADR0019_otel_collectors_architecture.png)

### Related Principles

- Adoption of open and consolidated standards (CNCF, W3C)
- Vendor neutrality at instrumentation layer
- Unified observability model across the organization

## Notes

- This ADR does not mandate a specific observability vendor or UI; it standardizes the emission protocol and telemetry model
- This ADR does not redefine trace header propagation; see ADR0017 for `traceparent`/`tracestate` migration rules
- Detailed sampling policies, collector topology, and dashboard conventions to be defined in implementation guidance
