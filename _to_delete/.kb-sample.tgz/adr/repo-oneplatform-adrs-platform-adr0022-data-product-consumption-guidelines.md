---
source_id: "adr:repo-oneplatform-adrs-platform-adr0022-data-product-consumption-guidelines"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0022_data_product_consumption_guidelines.md"
title: ADR0022 Data Product Consumption by Application or Business Capability
authority: binding
version_hash: "sha256:1dbda9c2266ce6a58f082a5b25f290ae587cd340c7bbf0cdb70660f814301771"
body_hash: "sha256:0110a93fa5ef961709673f86996b11e1d94c182bb862e2b9251376293e6c5998"
lang: en
source_langs: [en]
last_modified: "2026-05-28"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0022_data_product_consumption_guidelines.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1729396772 -->
<!-- confluence-space-key: CTO -->

# ADR0022 Data Product Consumption by Application or Business Capability

## Status

Accepted.

## Summary

Consumer-aligned data products expose data through two possible output port types: event streams on Hermes (Kafka) and OLAP tabular ports (Delta Lake table format) on the Data Lake (Databricks). Per [ADR0021](./ADR0021_hermes_as_the_default_output_port_for_data_products.md), the Hermes output port is optional for consumer-aligned data products, while the Databricks OLAP port is always present.

```mermaid
graph LR
    A["Business Capability A"] -->|feeds| B["Data Product A"]
    C["Business Capability B"] -->|feeds| D["Data Product B"]
    B -->|consumes| E["Consumer-Aligned Data Product"]
    D -->|consumes| E
    E -->|exposes| F["Business Capability C"]
```

Consumer-aligned data products are not limited to BI-oriented outputs such as KPIs and aggregations. They can also encapsulate calculations, data enrichment, and domain-specific logic (e.g. eligibility scoring, risk classification). The nature of the output and who consumes it determines the right channel, not the type of transformation applied.

A growing number of application and business capabilities are integrating with consumer-aligned data products to consume enriched data and leverage it in their own logic. It is important to establish clear guidelines on which output port to use for application integration, to ensure consistency and minimize integration debt across the platform.

This ADR guides the decision on which port to expose and consume, and under what conditions.

### Issue

It is unclear to development teams which output port of a data product they should consume from a transactional application integration:

- Using the OLAP tabular port for application integration can introduce tight coupling and reliability risks.
- Without a clear decision framework, teams can make inconsistent choices that increase the overall integration debt.

### Decision

The choice of consumption channel depends on the nature of the consumer:

| Consumer Type | Preferred Channel | Rationale |
|---|---|---|
| **Application / service** (transactional, near-real-time) | **Hermes**, but see table below 👇 for criteria to be evaluated | Minimal latency, schema evolution handled by the platform, push semantics enable reactive integrations, and broader reusability across capabilities. |
| **Analytical workload** (BI reporting, AI/ML, KPIs, aggregations) | **Databricks** | OLAP queries are the natural fit for aggregations and historical analysis; these outputs are often domain-specific and unlikely to have other event consumers. |

Specifically, for application / service, the following criteria can be used to guide the decision:

| Criterion | Hermes | Databricks |
|---|---|---|
| **Decoupling** | Schema evolution is managed by the Hermes platform forcing the publisher to adhere to the contract, the consumer is not impacted by upstream changes. | The OLAP table is formally exposed via a contract. However, there is no technical enforcement of the contract. If the data product owner decides not to respect the contract, the consumer may be exposed to schema changes in the OLAP table. |
| **Integration complexity** | One async channel with push mechanism, no query layer to maintain. | Manage JDBC/ODBC connections, SQL queries, and polling logic. |
| **Read performance** | Millisecond event delivery; however, data must be replicated locally in the downstream application for low-latency reads. | Query latency ranges from hundreds of milliseconds to seconds; no local replication needed. |
| **Reusability of the data** | Higher reusability with push semantics: other capabilities can subscribe to the same topic with no additional effort from the producer. | Data is reusable, but there is no push mechanism; other consumers must independently query the table. |
| **Data product refresh pattern** | Not a differentiating factor. | Not a differentiating factor. |

## Details

### Assumptions

- Consumer-aligned data products always expose an OLAP tabular output port on Databricks.
- An Hermes output port on a consumer-aligned data product is optional (per ADR0021) and should be added only when the criteria in this ADR justify it.
- Hermes events are most effective when an integration with OnePlatform is in place and events carry a reference to Workspace or Company Registry, enabling full platform-level compatibility across capabilities.

### Constraints

- Access to Hermes: consumer credential ticket required; authorization currently managed manually.
- Access to Databricks tables via an Azure Service Principal: authorization automated via Witboost.
- Data segmentation (per-tenant filtering) on Databricks is implemented via row-level security (RLS) function creation in Witboost. On Hermes, segmentation is not automated and needs custom development.

### Positions

This ADR was driven by two concrete use cases:

**ITR (Invoice Trading) - prefer Hermes.**  
ITR needs to consume from a consumer-aligned data product that holds invoice-level detail enriched with eligibility calculations. Although the data product is consumer-aligned, the enriched invoice data is reusable across other platform capabilities and the consumer is an operational application. Hermes is preferred, see the detail table below.

| Criterion | Decision |
|---|---|
| **Decoupling** | Hermes - It is preferred that ITR stays isolated from changes in the schema of the data product. |
| **Integration complexity** | No preference - ITR can manage both Hermes subscribers and databricks SQL integration. |
| **Read performance** | No preference - ITR requires daily batch updates to eligibility data and ad-hoc requests on single customers; higher latency on ad-hoc requests can be tolerated |
| **Reusability of the data** | Hermes - enriched invoice data with eligibility information is likely valuable to other capabilities on the platform. |

**Customer Hub - prefer Databricks.**  
Customer Hub exposes a consumer-aligned data product with pre-aggregated customer data to power a dashboard inside the business management system. The aggregations are specific to this dashboard and unlikely to be reused elsewhere. Even though the consumer is an application, Databricks is more suited here because the access pattern is OLAP-style, not transactional, see the detail table below.

| Criterion | Decision |
|---|---|
| **Decoupling** | No preference - the data product and the dashboard evolve together. |
| **Integration complexity** | No preference - both Hermes subscribers and databricks SQL integration can be managed by the application. |
| **Read performance** | Databricks - the dashboard runs analytical queries over pre-aggregated data; OLAP latency is acceptable. |
| **Reusability of the data** | Databricks - the pre-aggregations are specific to this dashboard; no other capability is expected to subscribe to these events. |

Decision proposed by Alberto Zitti, Antonella Bifolchi (Hermes), Marco Santoni (Data Platform).

### Argument

The consumer type alone (application vs. analytical tool) is not always sufficient to determine the channel. As shown by the Customer Hub case, an application can legitimately need OLAP-style access. The criteria table in the Decision section should be applied together to reach the right choice.

### Implications

- Teams building application integrations should request Hermes consumer credentials and subscribe to the relevant topics.
- Teams building BI or ML workloads should request access to Databricks tables via Witboost.
- Teams that choose Databricks for an application integration must document and justify the rationale.

## Related

### Related Decisions

- [ADR0008 Hermes Architecture](./ADR0008_hermes_architecture.md) - describes the Hermes platform and its event streaming model.
- [ADR0021 Hermes as the Default Output Port for Data Products](./ADR0021_hermes_as_the_default_output_port_for_data_products.md) - governs Hermes output port requirements for source-aligned data products (mandatory) and consumer-aligned ones (optional).

### Related Requirements

Not applicable.

### Related Artifacts

Not applicable.

### Related Principles

Not applicable.

## Notes

Not applicable.
