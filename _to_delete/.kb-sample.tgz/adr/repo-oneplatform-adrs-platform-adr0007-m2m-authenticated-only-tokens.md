---
source_id: "adr:repo-oneplatform-adrs-platform-adr0007-m2m-authenticated-only-tokens"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0007_m2m_authenticated_only_tokens.md"
title: ADR0007 Machine to Machine (M2M) Authenticated-Only Tokens
authority: binding
version_hash: "sha256:4bb5c2a9347cc98e6606dba764bba781576fb990e6f7962e8ca6bf7ee7dabba7"
body_hash: "sha256:7961aa9cd3db20cd042a80bbf54c16827b88a3e03d18307eb78f08f3682e47e2"
lang: en
source_langs: [en]
last_modified: "2023-12-20"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0007_m2m_authenticated_only_tokens.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 804782202 -->
<!-- confluence-space-key: CTO -->

# ADR0007 Machine to Machine (M2M) Authenticated-Only Tokens

### Status

**Deprecated — as of 2025-05-21. See [ADR0010](ADR0010_client_credentials.md) for the current M2M token and client credentials approach.**

## Summary

### Issue

The problem arises from the need to access common data from utility or standard code services. In this context:

* Authorization or tenant data isolation is not required.
* Authenticated identification and call tracking are essential.

### Decision

To address this issue, the M2M tokens created following the JWT standard do not contain any claims or information that can be used to authorize access. The absence of claims or permissions within the token has been considered a prudent solution, aligning with the principle of least privilege. This automatically excludes the token from authorization mechanisms that must require at least one claim or role within the token.

These types of tokens have a name generated through a specific naming convention. The convention involves using an UUIDv4, that is also the uid of the token, concatenated with a brief human-readable name of the service as a suffix. (eg. b67edc97-44f8-4b6a-886f-f57eaaa91af1-ACCOUNTING-ASYNC-SCHEDULER)

To keep an easy management, actually each calling service should possess one and only one token. The variation in permissions within the token is acceptable.

## Details

### Assumptions

Every authorization mechanism inside the platform must require at least one claim or permission that can guarantee access to and only to the requested resources, based on the principle of least privilege access.

### Implications

The current M2M token creation implementation requires developers to correctly provide token IDs and manually check that another token for the same service exists.
