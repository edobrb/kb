---
source_id: "adr:repo-oneplatform-adrs-platform-adr0014-business-capability-standardization"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0014_business_capability_standardization.md"
title: ADR0014 Standardization of Business Capability features
authority: binding
version_hash: "sha256:adf62b8651d669f236168a7f110f22b2d021255155308a33e7860f80198c979a"
body_hash: "sha256:29f3a197ea3f451bc9f736c20dd1982bbac381f530bd183468d6e09ebbcca621"
lang: en
source_langs: [en]
last_modified: "2025-10-13"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0014_business_capability_standardization.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1089699989 -->
<!-- confluence-space-key: CTO -->

# ADR0014 Standardization of Business Capability features

### Status

To be re-evaluated after Jun 1st, 2026.

## Summary

### Issue

Business Capabilities (BCs) within the platform expose **non-standardized APIs**, which causes:

- **Interoperability issues** between BCs and consumers (UIs, internal integrations, third parties).
- **Inconsistent governance** (security, logging, rate/quote, telemetry, audit).
- **Fragmented developer experience** (contracts, UX, examples).

### Decision

All new Business Capabilities **must comply with the following platform standard** to ensure **consistency,
interoperability, and governance**:

**MUST**

- **API style**:
    - **RESTful, domain-oriented resources** (nouns), **standard HTTP methods** (GET, POST, PUT, PATCH, DELETE).
        - URI naming: **plural + kebab-case** (`/customers`, `/sales-orders/{id}`).
        - Content negotiation: **Accept: application/json**.
        - Errors: **application/problem+json (RFC 9457).** [See dedicated ADR.](ADR0016_error_handling_RFC_9457.md)
        - Pagination: **cursor-based by default**; offset-based **only in specific non-critical cases**.
        - Partial updates: **PATCH with JSON Merge Patch (RFC 7396)**; **PUT** for full replacement.
        - Domain actions: prefer **sub-resources** (`/invoices/{id}/payments`); use
          `/commands` when not mappable 1:1 to CRUD (`/invoices/{id}/commands/cancel`).
        - Versioning: **major version in the path** (`/v1/...`). Each BC must manage **versioning (major/minor/patch),
          EOL, and breaking changes.** [See dedicated ADR.](ADR0015_rest_api_versioning.md)
    - **GraphQL**
    - **gRPC**
- **Messaging**: [publish in **CloudEvents format**.](ADR0004_use_of_cloud_events.md)
- **Timestamps**: **ISO-8601/RFC3339 UTC** (`createdAt`, `updatedAt`).
- **Money/decimal**: amounts as **decimal strings + ISO-4217 currency**.
- **Idempotency**: **Idempotency-Key for non-safe/critical POST requests**.
- **Platform headers**: **X-Request-Id** (correlation), **X-RateLimit-***.
- **Application logging**: [compliant with dedicated ADR.](ADR0011_well_known_log_type.md)

**SHOULD**

- **Concurrency**: **ETag + If-Match** for Optimistic Concurrency Control (OCC).
- **Caching**: **ETag, Cache-Control, Last-Modified** (where applicable).

## Details

### Assumptions

- **Standardization reduces integration costs** and improves developer experience.
- This standard serves as the **baseline for all BCs**.

### Constraints

- **Mandatory for all new APIs**.
- **Progressive refactoring required** for existing APIs.

### Positions

- **REST + established RFCs** = interoperability and predictability.
- A **single platform contract** simplifies governance and auditing.

### Argument

Without **common rules**, BCs risk introducing **custom conventions**, leading to **higher integration costs, fragmented
governance, and lower productivity**.  
This set of MUST and SHOULD ensures **consistency across the ecosystem**.

## Implications

- **Positive**: predictable developer experience, faster integration, centralized governance.
- **Negative**: initial alignment effort, **reduced freedom for ad-hoc API design**.
- **Mitigation**: exceptions handled through dedicated ADRs.

## Related

### Related Decisions

- [Cloud Events Adoption](ADR0004_use_of_cloud_events.md)
- [Well-known log type](ADR0011_well_known_log_type.md)
- [Rest API versioning](ADR0015_rest_api_versioning.md)
- [Error handling (RFC 9457)](ADR0016_error_handling_RFC_9457.md)

### Related Requirements

This document is the **central list of MUST and SHOULD requirements** for BCs.

### Related Artifacts

- Internal Guidelines
- Reference Implementation

### Related Principles

- API First
- Consistency over flexibility
- Developer Experience as a platform asset

## Notes

This ADR acts as an **index**: each MUST/SHOULD item has a **dedicated ADR with details**.  
It defines the **minimum enforceable baseline** for BC interoperability, **not an exhaustive specification**.
