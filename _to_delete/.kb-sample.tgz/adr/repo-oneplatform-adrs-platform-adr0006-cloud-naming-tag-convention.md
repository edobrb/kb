---
source_id: "adr:repo-oneplatform-adrs-platform-adr0006-cloud-naming-tag-convention"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0006_cloud_naming_tag_convention.md"
title: ADR0006 Cloud Naming Tag Convention
authority: binding
version_hash: "sha256:df896f82fd67f0a7ab514db36573d284f9cff66753fd91b0e9eddca474894134"
body_hash: "sha256:d129cf462e48891e903a7aba2b65644da80b923044f6b0ca6fc07263f800eb2e"
lang: en
source_langs: [en]
last_modified: "2022-06-28"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0006_cloud_naming_tag_convention.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 804749437 -->
<!-- confluence-space-key: CTO -->

# ADR0006 Cloud Naming Tag Convention

### Status

**Outdated — as of 2022-06-28. See [ADR0018](ADR0018_cloud_tagging_business_capability.md) for the current cloud tagging convention.**

## Summary

This ADR describes how teh cloud resources must be named and tagged

### Issue

- we have hundreds of cloud resources, and it difficult to identify the scope and the owner
- A standard must be provide to help comprension;

### Decision

#### Tags

At least every resource musta have that tags:

- env: name of the environment that can be dev, test, demo or prod;
- ref_po: email address of the product owner;
- ref_tech: email address for a technical reference of the project;
- tfmanaged: true or false to indicate if the resource is managed by terraform;
- domain: define the name of the product family (ex TS Digital or TS Studio);
- service: define the service functions (ex Invoice for TS Digital);
- app_name: TS Digital app name convention (for example: ts010 for TSE)
- technology: OS system (linux vs windows) for VM or database type for DB resourcer (elastic, mongodb, pgsql, timescale, ...)

#### Naming convention

##### VM

examples:

- Alyante VM on Azure North Europe: vm-ts010-az-ne-demo-0027
- Bilancio SaaS VM on Azure West Europe:  vm-ts260-az-we-prod-0100
- Lynfa (Studio) VM on AWS Milano:  vm-ts500-aws-mi-dev-0001
- Easylex VM on AWS Frankfurt:  vm-ts900-aws-fk-prod-0002

vm-[app name code]-[cloud provider: aws | az ][dev | test | demo | prod]-[location, max 2 characters. ne north europe | mi milano | we west europe | fk frankfurt | du dublin ]-[number, incremental from 0000]

##### DB PaaS

examples:

- Alyante DB on Azure North Europe: db-ts010-az-ne-demo-0027
- Bilancio SaaS DB on Azure West Europe:  db-ts260-az-we-prod-0100
- Lynfa (Studio) DB on AWS Milano:  db-ts500-aws-mi-dev-0001
- Easylex DB on AWS Frankfurt:  db-ts900-aws-fk-prod-0002

db-[app name code]-[cloud provider: aws | az ][dev | test | demo | prod]-[location, max 2 characters. ne north europe | mi milano | we west europe | fk frankfurt | du dublin ]-[number, incremental from 0000]

##### Storage PaaS

examples:

- Alyante storage on Azure North Europe: ts010aznedemo0027
- Bilancio SaaS storage on Azure West Europe:  ts260azweprod0100
- Lynfa (Studio) storage on AWS Milano:  ts500awsmidev0001
- Easylex storage on AWS Frankfurt:  ts900awsfkprod0002

[app name code][cloud provider: aws | az ][dev | test | demo | prod][location, max 2 characters. ne north europe | mi milano | we west europe | fk frankfurt | du dublin ][number, incremental from 0000]

For this kind of resource separator are not allowed by the cloud provider

## Details

The app_name code now mantained by TS Digital L2 support must be promoted as offical internal code and available via GitLab or Nexus artifact as CSV.
