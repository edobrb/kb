---
source_id: "adr:repo-oneplatform-adrs-platform-adr0013-centralized-npm-repository"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0013_centralized_npm_repository.md"
title: ADR0013 Centralized npm repository
authority: binding
version_hash: "sha256:28dbed6b706468c0de0748d28edb9c58701a1df9a9877c976437c064c1f07fd3"
body_hash: "sha256:2a4d0f8f78826bf427041abd2febe6bb9535580761fa4498df0636dcd95edf94"
lang: en
source_langs: [en]
last_modified: "2025-10-13"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0013_centralized_npm_repository.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 1088749825 -->
<!-- confluence-space-key: CTO -->

# ADR0013 Centralized npm repository

### Status

Accepted.

## Summary

### Issue

We currently maintain multiple npm registries, each tied to a specific package namespace (e.g., `@1f/*` pointing to
`nexus.ts-paas.com/repository/ts-one-front-npm-repo` and `@fortawesome/*` pointing to
`npm.fontawesome.com`). This setup causes configuration drift, onboarding friction, and manual license and secret management for FontAwesome packages.

### Decision

We will adopt a single, unified npm registry named **ts-platform-npm
**. It will host all internal namespaces, proxy the public npmjs registry, and proxy
`@fortawesome` licensed packages without per-project license entries. All projects will update their
`.npmrc` to use only `ts-platform-npm` and remove namespace-specific registry entries.

## Details

### Assumptions

- ts-platform-npm can reliably proxy both public and private npm registries.
- CI/CD pipelines and developer environments can be updated without major downtime.
- Centralized license management will reduce manual rotation and compliance risk.

### Constraints

- Must maintain uninterrupted access to all existing packages during migration.

### Positions

- Development teams favor reduced `.npmrc` complexity and fewer secrets.
- DevOps will own the registry’s availability, scaling, and monitoring.
- Security and legal require centralized visibility into license usage.

### Argument

Centralizing all package resolution and licensing under ts-platform-npm streamlines configuration, lowers the cognitive load on developers, and reduces misconfiguration risks. Proxying
`@fortawesome` removes per-project license overhead, while a single audit trail improves compliance. Although this introduces a single point of failure and potential performance bottlenecks, these can be mitigated via high-availability architecture, caching layers, and robust monitoring.

### Implications

- Every repository’s `.npmrc` must be updated to reference `https://npm.ts-platform.com/`.
- Legacy registries will be decommissioned three months after full adoption.
- ts-platform-npm requires HA deployment, load testing, and alerting for outages or latency spikes.
- Documentation and onboarding guides must be revised to reflect the new registry.

## Related

### Related Decisions

None.

### Related Requirements

None.

### Related Artifacts

None.

### Related Principles

None.

## Notes

None.
