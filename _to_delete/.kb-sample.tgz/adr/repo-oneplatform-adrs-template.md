---
source_id: "adr:repo-oneplatform-adrs-template"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/TEMPLATE.md"
title: ADRXXXX Title of the Decision
authority: binding
version_hash: "sha256:66ba26bdef353f8681dc37a16cdd0e1fbff9d21b3dd74ff4036ae97ba1e9bf6a"
body_hash: "sha256:66ba26bdef353f8681dc37a16cdd0e1fbff9d21b3dd74ff4036ae97ba1e9bf6a"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/TEMPLATE.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 804585597 -->
<!-- confluence-space-key: CTO -->
<!-- synchronized: false -->

---
status: proposed
date: YYYY-MM-DD
related: [ADR0000, ADR0000]
---

# ADRXXXX Title of the Decision

### Status

Proposed. *(Update to: Accepted / Deprecated / Outdated)*

## Summary

### Issue

Present the problem or gap this ADR addresses. Be specific: what breaks or degrades without this decision?

### Decision

**One-sentence summary of the decision.**

#### MUST

- Rule 1 — mandatory requirement with no exceptions.
- Rule 2 — use RFC 2119 language: MUST, MUST NOT.

#### SHOULD

- Rule 1 — strongly recommended; exceptions require justification.

#### MAY

- Rule 1 — optional; left to implementor discretion.

## Details

### Assumptions

*(Omit section if none.)*

### Constraints

*(Omit section if none.)*

### Positions

Alternatives considered and why they were rejected.

### Argument

Why this decision is the right one given the constraints.

### Implications

- **Positive**: ...
- **Negative**: ...
- **Mitigation**: ...

## Related

### Related Decisions

*(Link to ADRs using `[ADR0000](ADR0000_filename.md)`. Omit section if none.)*

### Related Requirements

*(Omit section if none.)*

### Related Artifacts

*(Omit section if none.)*

### Related Principles

*(Omit section if none.)*
