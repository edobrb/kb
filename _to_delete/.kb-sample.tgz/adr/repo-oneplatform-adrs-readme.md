---
source_id: "adr:repo-oneplatform-adrs-readme"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/README.md"
title: Architecture Decision Records
authority: binding
version_hash: "sha256:a04a963c416f233bc806913939229d229f688912533e1459a0d985d68288f762"
body_hash: "sha256:25512cd8c0516a4fbe56b665d0ca304ff1cf0067fa9312a75f48692b0e6e9462"
lang: en
source_langs: [en]
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/README.md
taxonomy_origins: "authority=convention_default, lang=measured, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 804880489 -->
<!-- confluence-space-key: CTO -->
# Architecture Decision Records

### What the heck is an ADR anyway?

An [ADR](https://adr.github.io/) is a simple way to document a decision. GitHub people came up with this bright idea, so it must be good.

At its core, an ADR is just a [Markdown](https://www.markdownguide.org/) file that follows a Template of questions.
You document your decisions by answering those questions.

👉 The goal is to remember HOW and WHY a decision was made 👈

### ADR Template

We follow our [ADR Template](./TEMPLATE.md) to document our decisions. Any time you document a new decision, copy our template and answer the questions there.

It may happen that a question does not apply to a particular decision. Fear not! You can just answer:

```
Not applicable
```

### ADR Hierarchy

All ADRs are collected in this central **monorepo**.
ADRs are organized into folders representing **Business Capability Domains** or **Business Units**.

The `Platform/` folder serves as the root for company-wide architectural decisions that apply globally.

Example:
- `Platform/`
- `Finance/`
- `HR/`

### ADR Inheritance

1. **Platform ADRs** (in `Platform/`) apply to all domains and projects.
2. **Domain-level ADRs** apply to all projects within that specific domain.
3. Inheritance follows the **Liskov Substitution Principle**: Child ADRs can specialize or restrict parent decisions but **must not contradict** them.
4. 👉 You can strictly define "HOW" a parent principle is applied, but you cannot change "WHAT" the principle is 👈

### ADR File Name

1. An ADR should be given an identifier that allows explicitly referring to it within its own context
2. An ADR should expose a brief and meaningful readable title

Example:

```
ADR0014_business_capability_standardization.md
```

# ADR Workflows (Top-Down and Bottom-Up)

## Workflow States

* **Draft**
* **In Core Review**
* **In Extended Review**
* **Approved**
* **Superseded**
* **Deprecated**

---

# Top-Down ADR Workflow

### **1. Authoring & Internal Review**

**State: Draft**
Core Architects create and refine the ADR within the Biosphere Git repository. This phase shapes the proposal before any formal evaluation.

### **2. Core Architectural Review**

**State: In Core Review**
The ADR undergoes formal assessment by the Core Architects to validate design soundness, platform alignment and potential impact. The ADR is published to Confluence and the Developer Portal.

### **3. Extended Architects Review**

**State: In Extended Review**
Once it passes the core review, the ADR is shared with the Extended Architects Team for broader feedback, refinement and cross-domain alignment.

### **4. Architecture Review Presentation**

**State: Approved**
After completing all review cycles, the ADR is considered approved. It is presented in the Architecture Review meeting solely for visibility and communication.

---

# Bottom-Up ADR Workflow

### **1. Team Proposal Submission**

**State: Draft**
Developer Teams propose an ADR through their Engineering Manager, who opens a merge request in the Biosphere ADR repository and engage the Core Architects for a review.

### **2. Core Architectural Intake**

**State: In Core Review**
The ADR undergoes formal assessment by the Core Architects to validate design soundness, platform alignment, architectural coherence and potential blockers. The ADR is published to Confluence and the Developer Portal.

### **3. Extended Architects Review**

**State: In Extended Review**
Once it passes the core review, the ADR is shared with the Extended Architects Team for broader feedback, refinement and cross-domain alignment.

### **4. Architecture Review Presentation**

**State: Approved**
After completing all review cycles, the ADR is considered approved. It is presented in the Architecture Review meeting solely for visibility and communication.


---

# Flow Diagram

```mermaid
graph TD
A["Start"] --> B{Top-Down?}
B -- Yes --> C["Core Architects Draft & Review"]
C --> D["Publish to Confluence & Developer Portal"]
D --> E["Extended Architects Review & Feedback"]
E --> F["Refined ADR and final approval"]
F --> G["Architecture Review \n(Informationl Only)"]
G --> H["End"]

B -- No --> I["Teams & EMs Propose ADR \n (MR opened in Biosphere)"]
I --> C
```
