---
source_id: "adr:repo-oneplatform-adrs-platform-adr0010-client-credentials"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0010_client_credentials.md"
title: ADR0010 Client Credentials and Token Management for M2M and User Access
authority: binding
version_hash: "sha256:cff7cb3480aca5732a0d47132333fa6681bad3c134eaa53197d1d4bdda569668"
body_hash: "sha256:6f0210d75cde4826be8f3a90f1c8078aee280bd069265f4819173ed4cc13e2ee"
lang: en
source_langs: [en]
last_modified: "2025-05-21"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0010_client_credentials.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 805961883 -->
<!-- confluence-space-key: CTO -->

# ADR0010 Client Credentials and Token Management for M2M and User Access

### Status

Accepted.

## Summary

### Issue

This adr outlines the process for obtaining, using, and managing JSON Web Tokens (JWT) for both machine-to-machine communication and user-driven requests, following OAuth 2.0 standards. The process involves three key perspectives: the Caller application, the Census/Policy Management function, and the Called Service (API Endpoint). The central Identity Provider (IDP) is referred to as "TSID".

### Decision

Implement a process leveraging TSID as the central Identity Provider (IDP) and a Policy Management function for authorization decisions, with responsibilities distributed among the Caller application, Census/Policy Management, and the Called Service.

## Details

### Assumptions

* TSID is available as a secure and compliant Identity Provider.
* All stakeholders are familiar with OAuth 2.0 and JWT standards.

### Constraints

* Tokens must adhere to OAuth 2.0 and JWT standards.
* Sensitive credentials must be stored securely, avoiding hardcoding.
* The solution must support both user-driven and M2M interactions.

### Process

```mermaid
flowchart TD
A[Start] -->|Caller: Identify the data you want| B{Are you accessing public data?}
A -->|Census: Inventory callers and policies| ZB[Identify resources to protect]
A -->|Called: Identify your data| BB{Are you exposing public data?}

subgraph Caller[" "]
B -->|YES| C[Call API without token]
B -->|NO| D{Do you have a user session?}
D -->|YES| Q[Add token to http header<br/> Authorization: Bearer]
D -->|NO| F{Can you create a user session?}
F -->|YES| G[Create user session via authorization_code flow]
F -->|NO| H{Do you already have an M2M client_credentials token?}
G --> Q
H -->|YES| N{Is the token expired?}
H -->|NO| J[Register client on IDP for client_credentials]
J --> L[Communicate client ID to the called service for policy enforcement]
N -->|YES| O[Refresh token with client_credentials]
N -->|NO| P[Use existing token]
O --> Q
P --> Q
Q --> R[Execute API call]
C --> R
end

subgraph Called[" "]
BB -->|YES| CC[Configure endpoint without authentication]
BB -->|NO| DD[Configure protected API]
DD --> EE[Implement token validation]
EE --> FF{Resource type?}
FF -->|Authentication only| GG[Verify token validity]
FF -->|Authentication + Authorization| HH[Verify token and permissions]
FF -->|Tenant-specific authorization| II[Verify token, permissions, and tenant]
CC --> JJ{Do you want to track calls?}
JJ -->|YES| KK[Accept optional token for traceability]
JJ -->|NO| LL[Implement anonymous logging]
GG --> MM[Configure 401 response if token is invalid]
HH --> MM
II --> MM
MM --> NN[Configure 403 response if authorization is missing]
end

subgraph Census[" "]
ZB --> ZC[Classify by type:<br/>public<br/>authenticated<br/>authorized<br/>tenant-specific]
ZC --> ZD[Create granular policies in the policy manager]
ZD --> ZE{Token type?}
ZE -->|User token| ZF[Configure policies for end user attributes]
ZE -->|M2M token| ZG[Configure policies for M2M user, potentially in addition to those already applied for end users, based also on the client_id]
ZF --> ZI[Document policies for future reference]
ZG --> ZI
ZI --> ZJ[Implement periodic review processes]
end

KK --> OO[End]
LL --> OO
NN --> OO
L -.->|Team communication| ZG
R -.->|API call| EE
ZJ -.->|Updated policies| EE
```

#### 1. Perspective of the Caller (Client Application)

**Responsibility:** Ensure proper authentication and token usage when accessing API resources. This includes securely managing credentials, obtaining/refreshing tokens via TSID as necessary, and selecting the correct token type (User or M2M) based on the context.

**Initial Setup (Prerequisite for M2M):**
* **M2M Client Registration:** Before making M2M calls, the client application must be registered on the TSID. This process involves providing necessary application details and results in the issuance of a `client_id` and `client_secret`.
* **Secure Credential Storage:** The obtained `client_secret` must be stored securely by the caller application, following best practices to prevent exposure (e.g., using secure vaults, environment variables, or managed identity solutions). Do *not* embed secrets directly in code or insecure configuration files.
* **Client ID Communication:** During or after registration via TSID, the `client_id` is made known to the Census/Policy Management function to allow for policy configuration associated with this specific M2M client or profiling it matching existing ones.

**Runtime Steps:**

1.  **Identify Data Needs:** Determine the specific API endpoint and data required.
2.  **Check Resource Protection Level:** Review API documentation (potentially provided via developer portal or metadata endpoint) to understand if the target resource is public or protected.
3.  **Accessing Public Data:** If the data is public, the API can be called directly without a token.
4.  **Accessing Protected Data:** If the data is protected, the caller must determine the appropriate authentication context:

    * **Is there an active User Session?** (e.g., a user is interacting with the caller application)
        * **Yes:**
            * Obtain the User JWT associated with the user's session (typically acquired via an OAuth 2.0 flow like `authorization_code` involving user interaction with TSID).
            * Ensure the User JWT is valid (not expired). If necessary and possible (depending on session management), refresh the user session/token via TSID.
            * Proceed to API Call using the User JWT.
        * **No (or M2M context required):** The interaction is purely application-to-application. Proceed to M2M token handling.

    * **M2M Token Handling:**
        * **Check for Existing M2M Token:** Does the caller have a non-expired M2M JWT for the required API/scope?
            * Tokens are JWTs. Check the `exp` (expiration) claim within the token payload.
            * **Yes, and Valid:** Use the existing M2M JWT. Proceed to API Call.
            * **Yes, but Expired or Missing:** Obtain/refresh the M2M token.
                * **Token Acquisition/Refresh:** Use the **OAuth 2.0 `client_credentials` grant type**. Make a request to TSID's token endpoint, authenticating using the caller's `client_id` and securely stored `client_secret`. Request the necessary scopes for the target API.
                * **Handle TSID Errors:** Implement robust error handling for the token request (e.g., network issues, invalid credentials, TSID unavailability) including retry logic where appropriate.
                * **Store New Token:** Securely cache the newly obtained M2M JWT for subsequent requests until it nears expiry.
                * Proceed to API Call using the new M2M JWT.
        * **(Setup Issue) No M2M credentials configured:** If the caller hasn't been registered on TSID or lacks its credentials, it cannot obtain an M2M token. This indicates a setup/configuration problem that needs addressing (see Initial Setup).

5.  **API Call:**
    * Add the valid JWT (either User or M2M) to the HTTP `Authorization` header: `Authorization: Bearer <JWT_TOKEN>`.
    * Execute the API call to the Called Service.

#### 2. Perspective of the Census (Client ID Inventory and Policy Management)

**Responsibility:** Manage the access configuration of M2M clients, classify resources accurately, define granular access policies within the policy management system, maintain up-to-date documentation, and conduct periodic reviews to enforce security effectively.

**M2M Client Onboarding:**
* **Inventory Management:** Maintain an inventory of registered M2M clients (`client_id`s) and their owners/purposes.

**Resource Classification:**
* Identify resources (API endpoints/data) to protect. Classify them based on criteria such as:
    * **Public:** Accessible without any token.
    * **Authenticated:** Requires a valid token (User or M2M) issued by TSID, verifying identity only.
    * **Authorized (User):** Requires a valid User JWT with specific claims (e.g., roles, permissions, group memberships) matching the policy.
    * **Authorized (M2M):** Requires a valid M2M JWT associated with a specific `client_id` and potentially specific `scope` claims matching the policy.
    * **Tenant-specific:** Requires a valid token containing tenant information, restricting access based on tenant context (can apply to both User and M2M tokens).
    * *Note: Categories can overlap (e.g., Authorized and Tenant-specific).*

**Policy Creation:**
* Utilize policy manager tools.
* Define granular access control policies based on resource classification.
* **For User access:** Configure policies based on user attributes.
* **For M2M access:** Configure policies for M2M user, potentially in addition to those already applied for end users, based also on the `client_id`.
* Link policies to specific API endpoints, resources and actions.

**Policy Documentation, Maintenance, and Lifecycle:**
* Document all policies clearly for reference by developers and security teams.
* Implement a periodic review process (e.g., quarterly) involving relevant stakeholders to ensure policies are effective, up-to-date with business needs and security standards.
* Define a process for **decommissioning** M2M client registrations and retiring associated policies within the Policy Manager when applications are retired or access is no longer needed.

#### 3. Perspective of the Called Service (API Endpoint)

**Responsibility:** Protect resources by **acting as a Policy Enforcement Point (PEP)**. This involves validating incoming JWTs (Authentication) issued by TSID, **calling the central Policy Authorizer (PDP) for authorization decisions**, enforcing those decisions, handling errors correctly, and implementing secure logging/tracking. The service must handle both User and M2M JWTs.

**Exposing Public vs. Protected Data:**
* Configure endpoints serving public data to *not* require the `Authorization` header.
* Optionally, allow (but don't require) tokens on public endpoints for traceability if needed. Log calls appropriately.
* Configure endpoints serving protected data to *require* a valid JWT in the `Authorization: Bearer` header.

**Token Validation (Authentication - Performed by PEP):**
* **Receive Token:** Extract the JWT from the `Authorization: Bearer` header.
* **Perform JWT Validation:** Before checking permissions, validate the JWT according to RFC 7519 and OAuth 2.0 standards (Zero Trust principle: always verify):
    * **Signature:** Verify the JWT's signature using TSID's public keys (obtained securely from TSID's JWKS endpoint and cached).
    * **Issuer (`iss`):** Verify the `iss` claim matches TSID's issuer URI.
    * **Audience (`aud`):** Verify the `aud` claim includes an identifier for *this* API/service.
    * **Expiration (`exp`):** Verify the token is not expired.
    * *(Optional but Recommended)*: Check `nbf` (Not Before) claim if present.
* **If JWT validation fails:** Reject the request immediately with a `401 Unauthorized`. Do not proceed to authorization check.

**Policy Enforcement (Authorization - PEP Interaction with PDP):**
* **Prepare Authorization Context:** Once the JWT is validated (Authentication successful), gather the necessary context for the authorization decision. This includes:
    * Validated claims from the JWT (e.g., `sub`, `client_id`, `scope`, roles, tenant info).
    * Information about the resource being accessed (e.g., API endpoint, HTTP method, target data).
* **Call Policy Authorizer (PDP):** The Called Service (PEP) makes a request to the central **Policy Authorizer (PDP)** component of the Policy Manager, sending the authorization context.
* **Receive Decision:** The PDP evaluates the context against the centrally managed policies (defined by Census) and returns an authorization decision (e.g., Permit or Deny) to the PEP.
* **Enforce Decision:**
    * **If PDP decision is Permit:** Proceed to execute the API request logic.
    * **If PDP decision is Deny:** Reject the request with a `403 Forbidden` status code.

**Error Handling:**
* Consistently return standard HTTP status codes:
    * `401 Unauthorized`: Invalid, missing, or expired token (Authentication failure at PEP). Include `WWW-Authenticate` header challenges where appropriate.
    * `403 Forbidden`: Valid token, but insufficient permissions according to the central Policy Authorizer (Authorization failure).

**Logging and Tracking:**
* Log relevant details for all incoming requests (both success and failure), including timestamp, source IP, requested resource, authentication outcome, authorization decision (from PDP), and final status code. Include non-sensitive identifiers like `sub` or `client_id` for traceability. Avoid logging the full token or sensitive claims/credentials.
* For public endpoints, implement anonymous logging or use optional tokens for tracking if provided.

### Argument

This integrated process, leveraging OAuth 2.0, JWT standards, and Zero Trust principles with TSID as the Identity Provider and a central Policy Manager, addresses both user-driven and machine-to-machine interactions. By clearly defining the responsibilities and procedures for the Caller, Census/Policy Management, and the Called Service (acting as PEP interacting with a central PDP), organizations can ensure secure, consistent, and manageable access control for their APIs. **This separation of concerns allows different teams with specialized knowledge (identity management, policy definition, service development, security operations) to manage their respective areas effectively, enhancing overall security posture and agility compared to approaches where all responsibilities are concentrated in one place.** Secure handling of credentials, robust token validation, and well-defined, centrally decided policy enforcement are crucial for maintaining security.

### Implications

* Enhanced security through robust token validation.
* Scalability due to the decentralized enforcement of policies.
* Dependency on the availability of TSID and Policy Management tools.

## Related

### Related Artifacts

* TSID’s developer portal documentation.
* Policy Manager configuration guidelines.

### Related Principles

* Zero Trust security model.
* Separation of concerns.
* Least privilege access.
