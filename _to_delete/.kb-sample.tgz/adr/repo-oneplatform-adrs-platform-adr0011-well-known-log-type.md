---
source_id: "adr:repo-oneplatform-adrs-platform-adr0011-well-known-log-type"
source_type: adr
unit_kind: documentation
source_url: "https://biosphere.teamsystem.com/oneplatform/adrs/-/blob/150a898bbe81fef6bc526ad99cb6e2f10ba15047/Platform/ADR0011_well_known_log_type.md"
title: ADR0011 Well-known log type
authority: binding
version_hash: "sha256:fcc3b4ea9d6a8091dab6376cc59e4982657dd448256913a1379da07f4072715b"
body_hash: "sha256:f2034606a63f2c25053d018c89e99552db01c70d7665bced4061a0c3628e1820"
lang: en
source_langs: [en]
last_modified: "2025-02-08"
fetched_at: "2026-07-23"
ingested_from: "git-md-connector:oneplatform/adrs"
index_status: verified
delivered_at: "2026-07-29T22:11:01Z"
raw_origin: raw/repo/oneplatform/adrs/Platform/ADR0011_well_known_log_type.md
taxonomy_origins: "authority=convention_default, lang=measured, last_modified=document, source_type=index_entry, source_url=index_entry, title=measured, unit_kind=producer_admission"
---
<!-- confluence-page-id: 804422321 -->
<!-- confluence-space-key: CTO -->

# ADR0011 Well-known log type

### Status

**Deprecated - as of 2026-05-22. See [ADR0020 OpenTelemetry Semantic Attributes for Platform Context](ADR0020_opentelemetry_semantic_attributes.md).**

This ADR is kept as historical documentation for services that still emit the legacy JSON log schema during migration.

## Summary

This ADR describes how well know log format for OnePlatform Application.

### Issue

The current JSON log format for OnePlatform Application needs to be updated to include additional fields to enhance traceability and debugging capabilities.

- The actual fields `app_name`, `app_version`, `action`, `workspace_id`, `item_id`, `manager_id`, `request_id` and `error_code` are required and had been remapped to the new format to provide a more comprehensive context in logs.

- The lack of these fields limits the ability to effectively correlate events and debugging operations within the platform.

- This decision will replace the previous ADR on the JSON log format.

### Decision

The updated logs will be written to stdout and shipped to HELK via beats. Logs will be validated by HELK according to the defined structure using [index template](https://www.elastic.co/guide/en/elasticsearch/reference/current/index-templates.html).

The updated mandatory log format is the following:

| FIELD NAME                   | TYPE    | EXAMPLE                                                                             | REQUIREMENTS   | SOURCE (when you are server)                                  |
|------------------------------|---------|-------------------------------------------------------------------------------------|----------------|---------------------------------------------------------------|
| timestamp                    | date    | 2016-05-23T08:05:34.853Z                                                            | mandatory      |                                                               |
| client.ip                    | ip      |                                                                                     | mandatory      |                                                               |
| client.hostname              | text    |                                                                                     | mandatory      |                                                               |
| **client.name**              | keyword | service name                                                                        | mandatory      | http\_header.x-app-name                                       |
| **client.version**           | keyword | 1.0, 1.1, 2.0, ...                                                                  | mandatory      | http\_header.x-app-version                                    |
| server.ip                    | ip      |                                                                                     | mandatory      |                                                               |
| server.hostname              | text    |                                                                                     | mandatory      |                                                               |
| business\_unit               | keyword | digital, enterprise, tspaas, studio                                                 | mandatory      |                                                               |
| app.name                     | keyword | service name                                                                        | mandatory      |                                                               |
| app.version                  | keyword | 1.0, 1.1, 2.0, ...                                                                  | mandatory      |                                                               |
| app.stack                    | keyword | java, node, python, ...                                                             | mandatory      |                                                               |
| customer.id                  | keyword | C.F./P.IVA                                                                          | mandatory      |                                                               |
| customer.ts\_id              | keyword | ts\_id code                                                                         | mandatory      | JWT\_token.sub                                                |
| **customer.workspace\_id**   | keyword | workspace\_id code                                                                  | mandatory      | http\_header.x-workspace-id validated against business\_logic |
| **customer.item\_id**        | keyword | item\_id code                                                                       | mandatory      | http\_header.x-item-id validated against business\_logic      |
| **customer.manager\_id**     | keyword | manager\_id code                                                                    | mandatory      | http\_header.x-manager-id validated against business\_logic   |
| correlation.id               | keyword | uuid attached to a full transaction or event chain, correlating multiple request.id | mandatory      | http\_header.x-correlation-id                                 |
| **request.id**               | keyword | cuid/uuid identifying a single request                                              | mandatory      | http\_header.x-request-id                                     |
| log.retention                | integer | 15, 30, 60, 180                                                                     | mandatory      |                                                               |
| log.level                    | keyword | info, error, debug                                                                  | mandatory      |                                                               |
| environment                  | keyword | dev, test, prod                                                                     | mandatory      |                                                               |
| user                         | text    | tech user or user id                                                                | mandatory      | JWT\_token.sub                                                |
| cloud.provider               | keyword | az, aws, gcp                                                                        | filled by beat |                                                               |
| cloud.region                 | keyword | westeurope, eu-west-1                                                               | filled by beat |                                                               |
| cloud.service                | keyword | aks, ec2, ecs                                                                       | filled by beat |                                                               |
| cloud.instance.id            | keyword | instance uuid                                                                       | filled by beat |                                                               |
| **event.action**             | keyword | name of the event/command/method                                                    | mandatory      |                                                               |
| event.message                | text    | NO base64, documenti                                                                | mandatory      |                                                               |
| event.duration               | long    | duration of the event in nanoseconds                                                | mandatory      |                                                               |
| http.response.status\_code   | long    | 200, 400, 500, ...                                                                  | mandatory      |                                                               |
| http.request.method          | keyword | get, post, put, ...                                                                 | mandatory      |                                                               |
| http.request.bytes           | long    | total size in bytes of the request                                                  | mandatory      |                                                               |
| **http.request.user\_agent** | text    |                                                                                     | mandatory      |                                                               |
| error.type                   | keyword | java.lang.NullPointerException                                                      | mandatory      |                                                               |
| **error.code**               | keyword | 403.1, error.general-ledger.v1.missing-exchange-rate, ...                           | mandatory      |                                                               |
| error.message                | text    |                                                                                     | mandatory      |                                                               |
| error.stack\_trace           | keyword |                                                                                     | mandatory      |                                                               |
| retention.status             | boolean | true, false(default)                                                                | mandatory      |                                                               |
| retention.period             | keyword | a = keep forever ,b = six moths, c = 1 year , d = 10 years                          | mandatory      |                                                               |    

if retention.status is true |
| tags | keyword | | mandatory |

## Details

### Assumptions

- No deprecation of previous fields is required.

### Positions

Pros:

- Improved traceability and event correlation by customer support.
- Enhanced debugging capabilities with additional contextual information.

Cons:

- Effort required to update log generators and Elasticsearch mappings.
- Temporary coexistence of old and new formats may cause discrepancies during the transition.

### Argument

Those fields are already in use but with inconsistent naming and formatting. This decision aims to standardize the log format across all services.

### Implications

- **Development** Teams: Update logging mechanisms to include new fields.
- **DevOps** Teams: Modify Elasticsearch templates and monitor the transition to the new format.
- **Documentation**: Revise all related technical guides.

## Related

### Related Decisions

This ADR update the previous decision ADR0005_well-known-log-type defining the JSON log format for OnePlatform Application.
This ADR is superseded by [ADR0020 OpenTelemetry Semantic Attributes for Platform Context](ADR0020_opentelemetry_semantic_attributes.md).
